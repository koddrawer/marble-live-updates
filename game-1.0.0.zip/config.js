// =====================================================================
//  CẤU HÌNH GAME — sửa file này để đổi LUẬT CHƠI, CHỮ HIỂN THỊ, QUÀ
//  (Màu sắc, font, kích thước giao diện nằm ở theme.css)
//  Sửa xong chỉ cần F5 / Refresh trang game.
// =====================================================================
window.GAME_CONFIG = {

  // ---------- THỜI GIAN (giây) ----------
  timing: {
    lobby: 25,            // thời gian gom người chơi
    lobbyMinPlayers: 1,   // hết giờ mà chưa đủ số này thì chờ thêm
    startCountdown: 5,    // đếm ngược 5..1 trước khi thả bi
    raceMax: 75,          // quá thời gian này mà chưa tới boss -> vào boss luôn
    bossMax: 35,          // thời gian tối đa đánh boss, hết giờ = boss thắng
    finishMax: 10,        // sau khi hạ boss, thời gian chờ bi về đích
    result: 10,           // màn kết quả + "NEXT RACE IN ..."
  },

  // ---------- NGƯỜI CHƠI ----------
  players: {
    max: 200,                 // tối đa bi mỗi vòng
    joinOnComment: true,      // comment bất kỳ = tham gia
    joinOnLike: true,         // thả tim = tham gia
    joinOnFollow: true,
    joinOnGift: true,
    joinKeywords: [],         // để trống = mọi comment. Ví dụ: ['me', 'join', 'vào']
    queueForNextRace: true,   // comment lúc đang đua -> tự vào vòng sau
    ballRadius: 20,           // bán kính bi (px, trên khung 1080x1920)
    showNames: true,          // hiện tên trên bi
  },

  // ---------- HYPE METER (thả tim làm đầy) ----------
  hype: {
    perLike: 0.25,    // % mỗi lượt tim
    perFollow: 8,     // % mỗi follow
    perShare: 6,      // % mỗi share
    perDiamond: 1,    // % mỗi kim cương quà
    perComment: 0,    // % mỗi comment
    // Thứ tự sự kiện khi đầy 100%. Có sẵn: meteor, hurricane, antigravity, earthquake
    events: ['meteor', 'hurricane', 'antigravity', 'earthquake'],
    bossDamage: 15,   // đầy Hype trong lúc đánh boss = trừ boss bấy nhiêu máu
  },

  // ---------- BOSS ----------
  boss: {
    enabled: true,                       // false = về đích thẳng không có boss
    keywords: ['bonk', 'đánh', 'danh'],  // comment chứa từ này = tấn công
    hpBase: 40,              // máu boss cơ bản
    hpPerPlayer: 1.2,        // + máu theo số người chơi (đông người -> boss trâu hơn)
    damagePerBonk: 1,        // sát thương mỗi comment bonk
    userCooldown: 0.25,      // giây giữa 2 lần bonk của cùng 1 người
    chatHp: 100,             // máu phe chat
    attackEvery: 1.1,        // giây giữa các đòn boss
    attackDamage: 5,         // mỗi đòn boss trừ máu phe chat
    attackKillsBall: true,   // đòn boss xoá luôn 1 viên bi
  },

  // ---------- QUÀ TẶNG ----------
  // Tìm theo tên trước (byName), không có thì theo số kim cương (tiers, lấy mức cao nhất đạt được)
  // action: 'boost' (đẩy bi lao xuống) | 'big' (bi to ra) | 'shield' (miễn nhiễm thiên thạch & đòn boss) | 'none'
  gifts: {
    byName: {
      'Rose':     { action: 'boost',  bossDamage: 5,   hype: 5 },
      'TikTok':   { action: 'boost',  bossDamage: 5,   hype: 5 },
      'Finger Heart': { action: 'big', bossDamage: 10, hype: 10 },
    },
    tiers: [
      { minDiamonds: 1,   action: 'boost',  bossDamage: 5,   hype: 5 },
      { minDiamonds: 5,   action: 'big',    bossDamage: 15,  hype: 10 },
      { minDiamonds: 30,  action: 'shield', bossDamage: 40,  hype: 30 },
      { minDiamonds: 100, action: 'shield', bossDamage: 100, hype: 100 },
    ],
    multiplyByCount: true,   // tặng combo x10 -> sát thương/hype x10
  },

  // ---------- ĐƯỜNG ĐUA ----------
  // Ghép các đoạn từ trên xuống. Có sẵn: pegs, spinners, bouncers, zigzag, seesaw, hammers, funnel, slats
  // height = chiều cao đoạn (px). Thêm/bớt/đổi thứ tự tuỳ ý.
  course: {
    shuffle: true,     // xáo trộn thứ tự mỗi vòng (funnel cuối luôn giữ nguyên)
    sections: [
      { type: 'pegs',     height: 1300 },
      { type: 'spinners', height: 1300 },
      { type: 'bouncers', height: 1100 },
      { type: 'slats',    height: 1200 },
      { type: 'hammers',  height: 1200 },
      { type: 'seesaw',   height: 1400 },
      { type: 'zigzag',   height: 1700 },
    ],
    finalFunnel: true,
    gravity: 1.0,
  },

  // ---------- NHÀ VÔ ĐỊCH VÒNG TRƯỚC ----------
  champion: {
    enabled: true,       // thẻ champion bay trên đường đua làm chướng ngại
    radius: 105,
    shockwaveEvery: 5,   // giây giữa các lần phát sóng đẩy bi
  },

  // ---------- HÌNH ẢNH (đặt file vào thư mục public/assets) ----------
  // Để '' nếu không dùng -> game tự vẽ
  assets: {
    background: '',      // ví dụ 'assets/bg.png' (nền khu đua, 1080 rộng)
    bossBackground: '',  // nền khu boss
    boss: '',            // ảnh boss (png trong suốt, vuông)
    logo: '',            // logo góc màn hình
  },

  // ---------- ÂM THANH (file trong public/assets, để '' nếu không dùng) ----------
  sounds: {
    volume: 0.6,
    start: '', hype: '', bonk: '', bossHit: '', win: '', lose: '', join: '',
  },

  // ---------- CHỮ HIỂN THỊ (đổi ngôn ngữ ở đây) ----------
  texts: {
    lobbyTitle: 'FOLLOW TO JOIN',
    lobbySub: 'Comment hoặc thả tim để vào đua!',
    racers: 'người chơi',
    howTitle: 'HOW TO PLAY',
    howSub: 'Chat điều khiển cuộc đua',
    how1Title: 'Comment', how1Tag: 'BẤT KỲ', how1Btn: 'VÀO ĐUA',
    how2Title: 'Thả tim', how2Tag: 'LÀM ĐẦY', how2Btn: 'HYPE',
    how3Title: 'Follow / Share', how3Tag: 'BOOST LỚN', how3Btn: '+ HYPE',
    start: 'START',
    hypeLabel: 'HYPE',
    maxHype: 'MAX HYPE!',
    hypeBy: 'CHAT kích hoạt bằng HYPE',
    events: {
      meteor: 'METEOR STORM',
      hurricane: 'HURRICANE',
      antigravity: 'ANTI-GRAVITY',
      earthquake: 'EARTHQUAKE',
    },
    bossChat: 'CHAT',
    bossName: 'BOSS',
    bossType: 'GÕ',
    bossKeyword: 'BONK',
    bossAttack: 'ĐỂ TẤN CÔNG',
    bossGate: 'HẠ BOSS ĐỂ QUA',
    bonk: 'BONK!',
    chatWins: 'CHAT THẮNG!',
    chatWinsSub: 'Cổng đã mở — về đích nhanh nhất!',
    bossWins: 'THE BOSS WINS!',
    bossWinsSub: 'Không ai thắng vòng này — lần sau hạ nó nhé!',
    winner: 'WINNER',
    wins: 'WIN',
    noWinner: 'KHÔNG CÓ NGƯỜI THẮNG',
    nextRace: 'NEXT RACE IN',
    previousChampion: 'PREVIOUS CHAMPION',
    beatThem: 'beat them!',
    giftBoost: 'BOOST!', giftBig: 'BI KHỔNG LỒ!', giftShield: 'KHIÊN!',
    waitingPlayers: 'Đang chờ người chơi...',
  },
};
