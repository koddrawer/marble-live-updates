// =====================================================================
//  Marble Live — lõi game (vật lý, pha chơi, vẽ).
//  Thường KHÔNG cần sửa file này: luật chơi ở config.js, giao diện ở theme.css
// =====================================================================
(() => {
'use strict';
const C = window.GAME_CONFIG;
const T = C.texts;
const APP = window.marble || null;   // cầu nối với app desktop (preload)
function deepMerge(dst, src) {
  for (const k in src) {
    const v = src[k];
    if (v && typeof v === 'object' && !Array.isArray(v) && !v.__replace) { if (!dst[k] || typeof dst[k] !== 'object') dst[k] = {}; deepMerge(dst[k], v); }
    else if (v && v.__replace) { const c = { ...v }; delete c.__replace; dst[k] = c; }   // thay thế toàn bộ (vd danh sách quà theo tên)
    else dst[k] = v;
  }
  return dst;
}
const DEFAULT_CONFIG = JSON.parse(JSON.stringify(C));
if (APP) {
  const init = APP.init();
  if (init.config) deepMerge(C, init.config);
  if (init.theme) for (const [k, v] of Object.entries(init.theme)) if (v) document.documentElement.style.setProperty('--' + k, v);
}
const W = 1080, H = 1920, WALL = 40;
const { Engine, Bodies, Body, Composite } = Matter;
const $ = s => document.querySelector(s);
const TEST = /[?&]test\b/.test(location.search);

// ---------------- Khung hình co giãn theo cửa sổ ----------------
const wrap = $('#wrap');
function fit() {
  const s = Math.min(innerWidth / W, innerHeight / H);
  wrap.style.transform = `translate(${-W * s / 2}px, ${-H * s / 2}px) scale(${s})`;
}
addEventListener('resize', fit); fit();

// ---------------- Màu lấy từ theme.css ----------------
const COL = {};
function loadColors() {
  const cs = getComputedStyle(document.documentElement);
  for (const n of ['bg','bg-dots','wall','wall-edge','peg','peg-edge','spinner','spinner-hub','bouncer','slat','hammer',
    'seesaw','ramp','ramp-edge','funnel','wood','boss-bg','boss-bg-2','boss-color','boss-barrier','laser','bonk-shot','finish',
    'ball-border','ball-shield','ball-boost','name-color','name-stroke','name-size','primary','accent-2','good','font'])
    COL[n] = cs.getPropertyValue('--' + n).trim();
}
loadColors();

// ---------------- Chữ tĩnh trong HUD ----------------
function applyTexts() {
  document.querySelectorAll('[data-t]').forEach(el => el.textContent = T[el.dataset.t] ?? '');
  $('#lobby .l-title').textContent = T.lobbyTitle;
  $('#lobby .l-sub').textContent = T.lobbySub;
  $('#howto h2').textContent = T.howTitle;
  $('#howto p').textContent = T.howSub;
}
applyTexts();

// ---------------- Lưu trữ (số trận thắng, champion) ----------------
const store = {
  get(k, d) { try { const v = localStorage.getItem('marble.' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('marble.' + k, JSON.stringify(v)); } catch {} },
};
let wins = store.get('wins', {});
let champion = store.get('champion', null);

// ---------------- Ảnh ----------------
function loadImg(src) {
  if (!src) return null;
  const img = new Image(); img.src = src; img.onerror = () => { img._bad = true; };
  return img;
}
const IMG = {};
function loadAssets() {
  IMG.bg = loadImg(C.assets.background); IMG.bossBg = loadImg(C.assets.bossBackground); IMG.boss = loadImg(C.assets.boss);
  if (C.assets.logo) { $('#logo').src = C.assets.logo; $('#logo').classList.remove('hidden'); } else $('#logo').classList.add('hidden');
}
loadAssets();
const imgOk = i => i && i.complete && i.naturalWidth > 0 && !i._bad;

// ---------------- Âm thanh ----------------
const SND = {};
function loadSounds() {
  for (const k in SND) delete SND[k];
  for (const [k, v] of Object.entries(C.sounds)) if (v && k !== 'volume') { SND[k] = new Audio(v); SND[k].volume = C.sounds.volume ?? 0.6; }
}
loadSounds();
function play(k) { const a = SND[k]; if (!a) return; try { const c = a.cloneNode(); c.volume = a.volume; c.play().catch(() => {}); } catch {} }

// ---------------- Avatar / sprite bi ----------------
const avatarImgs = new Map();
function hue(str) { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619) >>> 0; return h % 360; }
function fallbackColor(name) { return `hsl(${hue(name)},65%,55%)`; }
function makeSprite(p) {
  const S = 72, cv = document.createElement('canvas'); cv.width = cv.height = S;
  const g = cv.getContext('2d');
  const draw = img => {
    g.clearRect(0, 0, S, S);
    g.save(); g.beginPath(); g.arc(S / 2, S / 2, S / 2 - 3, 0, Math.PI * 2); g.clip();
    if (img) g.drawImage(img, 0, 0, S, S);
    else {
      g.fillStyle = fallbackColor(p.name); g.fillRect(0, 0, S, S);
      g.fillStyle = '#fff'; g.font = `800 34px ${COL.font}`; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText((p.nick || p.name || '?').trim().charAt(0).toUpperCase(), S / 2, S / 2 + 2);
    }
    g.restore();
    g.lineWidth = 4; g.strokeStyle = COL['ball-border']; g.beginPath(); g.arc(S / 2, S / 2, S / 2 - 2.5, 0, Math.PI * 2); g.stroke();
  };
  draw(null);
  if (p.avatar) {
    let img = avatarImgs.get(p.avatar);
    if (!img) { img = new Image(); img.referrerPolicy = 'no-referrer'; img.src = p.avatar; avatarImgs.set(p.avatar, img); }
    if (img.complete && img.naturalWidth) draw(img);
    else img.addEventListener('load', () => draw(img), { once: true });
  }
  return cv;
}
function avatarEl(user, cls = '') {
  if (user.avatar) { const i = document.createElement('img'); i.src = user.avatar; i.referrerPolicy = 'no-referrer'; i.className = cls; return i; }
  const d = document.createElement('div'); d.className = 'avatar-fallback ' + cls;
  d.style.cssText = `background:${fallbackColor(user.name)};display:grid;place-items:center;color:#fff;font-weight:800;font-size:150%`;
  d.textContent = (user.nick || user.name || '?').charAt(0).toUpperCase(); return d;
}

// =====================================================================
//  VẬT LÝ & ĐƯỜNG ĐUA
// =====================================================================
const engine = Engine.create();
engine.positionIterations = 8; engine.velocityIterations = 6;
const radius = () => C.players.ballRadius;
let bodies = [];       // vật cản để vẽ
let kinematic = [];    // vật cản chuyển động
let cage = null;       // lồng xuất phát
let geo = {};          // toạ độ quan trọng
let simT = 0;

function add(b, kind, color, extra = {}) {
  Object.assign(b, { kind, color }, extra);
  Composite.add(engine.world, b); bodies.push(b); return b;
}
const CAT_OBS = 0x0001, CAT_ARENA = 0x0002, CAT_BALL = 0x0004;
const stat = { isStatic: true, friction: 0.02, restitution: 0.4 };
const arena = { category: CAT_ARENA, mask: 0xFFFF };
function bar(x, y, len, th, angle, kind, color, opts = {}) {
  return add(Bodies.rectangle(x, y, len, th, { ...stat, angle, chamfer: { radius: th / 2 - 0.5 }, ...opts }), kind, color);
}
function peg(x, y, r, color = 'peg') { return add(Bodies.circle(x, y, r, { ...stat, restitution: 0.55 }), 'peg', color); }
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const L = WALL, Rr = W - WALL, IW = Rr - L;

const SECTIONS = {
  pegs(y0, h) {
    const sx = 120, sy = 115; let row = 0;
    for (let y = y0 + 80; y < y0 + h - 60; y += sy, row++) {
      const off = row % 2 ? sx / 2 : 0;
      for (let x = L + 60 + off; x < Rr - 40; x += sx) peg(x, y, 13);
    }
    for (let i = 0; i < 3; i++) bar(i % 2 ? Rr - 90 : L + 90, y0 + rnd(200, h - 200), 200, 18, i % 2 ? -0.5 : 0.5, 'wood', 'wood');
  },
  spinners(y0, h) {
    let row = 0;
    for (let y = y0 + 140; y < y0 + h - 100; y += 270, row++) {
      const n = row % 2 ? 3 : 4, gap = IW / n;
      for (let i = 0; i < n; i++) {
        const b = bar(L + gap * (i + 0.5), y, Math.min(gap * 0.9, 210), 20, rnd(0, 3), 'spinner', 'spinner');
        b.spin = (i + row) % 2 ? 0.035 : -0.035; kinematic.push(b);
      }
    }
  },
  bouncers(y0, h) {
    let row = 0;
    for (let y = y0 + 150; y < y0 + h - 80; y += 230, row++) {
      const n = 2 + (row % 2);
      for (let i = 0; i < n; i++) {
        const x = L + IW * (i + 0.5) / n + rnd(-40, 40);
        add(Bodies.rectangle(x, y, 150, 18, { ...stat, restitution: 1.15, chamfer: { radius: 8 }, angle: rnd(-0.15, 0.15) }), 'bouncer', 'bouncer');
      }
      for (let i = 0; i < 4; i++) peg(L + IW * (i + 0.5) / 4 + (row % 2 ? 60 : -60), y + 115, 12);
    }
  },
  slats(y0, h) {
    let row = 0;
    for (let y = y0 + 110; y < y0 + h - 80; y += 150, row++) {
      const off = row % 2 ? 100 : 0;
      for (let x = L + 90 + off; x < Rr - 60; x += 200) bar(x, y, 120, 18, row % 2 ? 0.35 : -0.35, 'slat', 'slat');
    }
  },
  hammers(y0, h) {
    let i = 0;
    for (let y = y0 + 120; y < y0 + h - 300; y += 380, i++) {
      for (const px of (i % 2 ? [L + 260, Rr - 260] : [W / 2])) {
        const arm = Bodies.rectangle(px, y + 140, 22, 280, { chamfer: { radius: 10 } });
        const head = Bodies.rectangle(px, y + 290, 150, 60, { chamfer: { radius: 14 } });
        const b = Body.create({ parts: [arm, head], ...stat, restitution: 0.6 });
        add(b, 'hammer', 'hammer');
        b.pivot = { x: px, y }; b.off0 = { x: b.position.x - px, y: b.position.y - y };
        b.swing = { amp: 1.0, speed: 1.6 + Math.random() * 0.6, phase: Math.random() * 6 };
        kinematic.push(b);
      }
      peg(L + 60, y + 330, 14); peg(Rr - 60, y + 330, 14);
    }
  },
  seesaw(y0, h) {
    let row = 0;
    for (let y = y0 + 180; y < y0 + h - 100; y += 330, row++) {
      const cx = row % 2 ? L + IW * 0.36 : L + IW * 0.64;
      const b = bar(cx, y, 560, 22, 0, 'seesaw', 'seesaw');
      b.rock = { amp: 0.38, speed: 1.2 + Math.random() * 0.5, phase: Math.random() * 6 };
      kinematic.push(b);
      peg(row % 2 ? Rr - 90 : L + 90, y + 120, 14);
    }
  },
  zigzag(y0, h) {
    let i = 0; const len = IW * 0.74, ang = 0.3;
    for (let y = y0 + 150; y < y0 + h - 100; y += 260, i++) {
      const left = i % 2 === 0;
      const cx = left ? L + len / 2 * Math.cos(ang) : Rr - len / 2 * Math.cos(ang);
      bar(cx, y, len, 30, left ? ang : -ang, 'ramp', 'ramp', { friction: 0 });
    }
  },
  funnel(y0, h) {
    const gap = 170, half = (IW - gap) / 2, ang = 0.42;
    const len = half / Math.cos(ang);
    bar(L + half / 2, y0 + h / 2, len, 26, ang, 'funnel', 'funnel', { friction: 0.001 });
    bar(Rr - half / 2, y0 + h / 2, len, 26, -ang, 'funnel', 'funnel', { friction: 0.001 });
  },
};

function buildWorld() {
  Composite.clear(engine.world, false);
  bodies = []; kinematic = []; simT = 0;
  engine.gravity.y = C.course.gravity;

  // Lồng xuất phát
  const cageR = Math.max(240, Math.min(470, Math.sqrt(C.players.max * radius() * radius() * 2.4)));
  const cx = W / 2, cy = 130 + cageR;
  const segs = [], N = 48;
  for (let i = 0; i < N; i++) {
    const a = i / N * Math.PI * 2;
    const s = Bodies.rectangle(cx + Math.cos(a) * cageR, cy + Math.sin(a) * cageR, cageR * 2 * Math.PI / N + 6, 16, { ...stat, angle: a + Math.PI / 2 });
    s.baseA = a; add(s, 'cage', 'accent-2'); segs.push(s);
  }
  cage = { cx, cy, r: cageR, segs, rot: 0, open: false };

  // Ghép các đoạn đua
  let y = cy + cageR + 160;
  const courseTop = y;
  let secs = C.course.sections.slice();
  if (C.course.shuffle) secs.sort(() => Math.random() - 0.5);
  for (const s of secs) {
    const fn = SECTIONS[s.type];
    if (!fn) { console.warn('Không có loại đoạn đua:', s.type); continue; }
    fn(y, s.height); y += s.height;
  }
  if (C.course.finalFunnel) { SECTIONS.funnel(y, 500); y += 500; }

  // Khu boss
  const barrierY = y + 260;
  const bossY = barrierY + 520, finishY = barrierY + 790, floorY = barrierY + 1100;
  geo = { courseTop, barrierY, bossY, finishY, floorY, bossR: 140, camMax: barrierY - 620 };
  geo.barrier = C.boss.enabled ? add(Bodies.rectangle(W / 2, barrierY, IW, 24, { ...stat, restitution: 0.1, friction: 0.3, collisionFilter: arena }), 'barrier', 'boss-barrier') : null;
  geo.bossBody = C.boss.enabled ? add(Bodies.circle(W / 2, bossY, geo.bossR, { ...stat, collisionFilter: arena }), 'boss', 'boss-color') : null;
  add(Bodies.rectangle(W / 2, floorY, W, 60, { ...stat, restitution: 0.1, collisionFilter: arena }), 'floor', 'boss-bg-2');

  // Tường 2 bên + trần
  const totalH = floorY + 100;
  add(Bodies.rectangle(WALL / 2, totalH / 2 - 200, WALL, totalH + 400, { ...stat, restitution: 0.2, collisionFilter: arena }), 'wall', 'wall');
  add(Bodies.rectangle(W - WALL / 2, totalH / 2 - 200, WALL, totalH + 400, { ...stat, restitution: 0.2, collisionFilter: arena }), 'wall', 'wall');
  add(Bodies.rectangle(W / 2, -220, W, 40, stat), 'wall', 'wall');
}

function stepKinematic(dt) {
  simT += dt;
  if (cage && !cage.open) {
    cage.rot += 0.6 * dt;
    for (const s of cage.segs) {
      const a = s.baseA + cage.rot;
      Body.setPosition(s, { x: cage.cx + Math.cos(a) * cage.r, y: cage.cy + Math.sin(a) * cage.r }, true);
      Body.setAngle(s, a + Math.PI / 2, true);
    }
  }
  for (const b of kinematic) {
    if (b.spin) Body.setAngle(b, b.angle + b.spin * dt * 60, true);
    else if (b.rock) Body.setAngle(b, Math.sin(simT * b.rock.speed + b.rock.phase) * b.rock.amp, true);
    else if (b.swing) {
      const th = Math.sin(simT * b.swing.speed + b.swing.phase) * b.swing.amp;
      const c = Math.cos(th), s = Math.sin(th);
      Body.setPosition(b, { x: b.pivot.x + b.off0.x * c - b.off0.y * s, y: b.pivot.y + b.off0.x * s + b.off0.y * c }, true);
      Body.setAngle(b, th, true);
    } else if (b.move) b.move(b, dt);
  }
}

function openCage() {
  if (!cage || cage.open) return;
  cage.open = true;
  for (const s of cage.segs) {
    const a = ((s.baseA + cage.rot) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    if (a > Math.PI * 0.22 && a < Math.PI * 0.78) { Composite.remove(engine.world, s); s.removed = true; }
  }
  bodies = bodies.filter(b => !b.removed);
}

// =====================================================================
//  TRẠNG THÁI GAME
// =====================================================================
const players = new Map();   // id -> player
const queue = new Map();     // người comment khi đang đua -> vòng sau
const S = {
  phase: 'lobby', t: 0, timeLeft: 0, camY: 0, hype: 0, hypeIdx: 0, raceTime: 0,
  boss: null, effects: [], particles: [], texts: [], shots: [], lasers: [], crosshairs: [],
  shake: 0, gravityTimer: 0, wind: 0, quake: 0, winner: null, champ: null,
};

function alive() { const a = []; for (const p of players.values()) if (p.body && !p.dead) a.push(p); return a; }

function addPlayer(u) {
  if (players.has(u.id) || players.size >= C.players.max) return null;
  const p = { id: u.id, name: u.name || u.id, nick: u.nick || u.name, avatar: u.avatar || '', r: radius(), dead: false, still: 0 };
  p.sprite = makeSprite(p);
  players.set(p.id, p);
  spawnBall(p);
  if (S.phase === 'lobby') lobbyAdd(p);
  play('join');
  return p;
}
function spawnBall(p) {
  const a = Math.random() * Math.PI * 2, d = Math.random() * (cage.r - radius() * 2 - 20);
  p.body = Bodies.circle(cage.cx + Math.cos(a) * d, cage.cy + Math.sin(a) * d, p.r, {
    restitution: 0.45, friction: 0.005, frictionAir: 0.004, density: 0.002, label: 'ball',
    collisionFilter: { category: CAT_BALL, mask: 0xFFFF },
  });
  p.body.player = p;
  Body.setVelocity(p.body, { x: rnd(-4, 4), y: rnd(-4, 4) });
  Composite.add(engine.world, p.body);
}
function killBall(p, pop = true) {
  if (!p.body || p.dead) return;
  p.dead = true;
  if (pop) burst(p.body.position.x, p.body.position.y, COL.laser, 18);
  Composite.remove(engine.world, p.body);
}

function tryJoin(u) {
  if (!u || !u.id) return;
  if (players.has(u.id)) return;
  if (S.phase === 'lobby' || S.phase === 'start') addPlayer(u);
  else if (C.players.queueForNextRace && !queue.has(u.id)) queue.set(u.id, u);
}

// ---------------- Chuyển pha ----------------
const ui = {
  lobby: $('#lobby'), howto: $('#howto'), count: $('#count'), top3: $('#top3'), timer: $('#timer'),
  hype: $('#hype'), bossHud: $('#bossHud'), result: $('#result'), banner: $('#banner'), toasts: $('#toasts'), status: $('#status'),
};
function show(...els) { for (const k of ['lobby','howto','count','top3','timer','hype','bossHud','result']) ui[k].classList.toggle('hidden', !els.includes(k)); }

function setPhase(ph) {
  S.phase = ph; S.t = 0;
  if (ph === 'lobby') {
    buildWorld();
    for (const p of players.values()) if (p.body) Composite.remove(engine.world, p.body);
    players.clear();
    S.camY = 0; S.boss = null; S.winner = null; S.raceTime = 0;
    S.effects = []; S.particles = []; S.texts = []; S.shots = []; S.lasers = []; S.crosshairs = [];
    S.gravityTimer = 0; S.wind = 0; S.quake = 0; engine.gravity.y = C.course.gravity;
    $('#lobby .l-grid').innerHTML = '';
    S.timeLeft = C.timing.lobby;
    show('lobby');
    for (const u of queue.values()) addPlayer(u);
    queue.clear();
  } else if (ph === 'start') {
    S.timeLeft = C.timing.startCountdown; show('howto', 'count'); S.lastCount = -1;
  } else if (ph === 'race') {
    openCage(); play('start');
    show('top3', 'timer', 'hype');
    S.champ = (C.champion.enabled && champion) ? makeChampionBumper() : null;
  } else if (ph === 'boss') {
    removeChampion();
    const n = players.size;
    const hp = Math.round(C.boss.hpBase + C.boss.hpPerPlayer * n);
    S.boss = { hp, max: hp, chat: C.boss.chatHp, chatMax: C.boss.chatHp, nextAttack: 2, flash: 0, scale: 1, lastBonk: new Map(), dead: false };
    show('bossHud', 'hype'); ui.hype.style.top = 'calc(var(--hud-top) + 590px)';
    // bi còn ở xa: xuyên qua vật cản, rơi thẳng xuống khu boss
    for (const p of alive()) if (p.body.position.y < geo.barrierY - 220) {
      p.raining = true; p.body.collisionFilter.mask = CAT_ARENA | CAT_BALL;
      Body.setPosition(p.body, { x: p.body.position.x, y: Math.max(p.body.position.y, geo.camMax - 300 - Math.random() * 600) });
      Body.setVelocity(p.body, { x: rnd(-2, 2), y: 18 });
    }
    updateBossHud();
  } else if (ph === 'finish') {
    show('top3', 'timer'); ui.hype.style.top = '';
  } else if (ph === 'bossWin') {
    show(); ui.hype.style.top = ''; play('lose');
  } else if (ph === 'result') {
    S.timeLeft = C.timing.result; showResult();
  }
}

// ---------------- Lobby ----------------
function lobbyAdd(p) {
  const grid = $('#lobby .l-grid');
  const d = document.createElement('div'); d.className = 'p';
  d.appendChild(avatarEl(p)); const sp = document.createElement('span'); sp.textContent = '@' + p.name; d.appendChild(sp);
  grid.prepend(d);
  while (grid.children.length > 16) grid.lastChild.remove();
}
function updateLobby() {
  const n = players.size;
  $('#lobby .l-num').textContent = `${n} / ${C.players.max} ${T.racers}`;
  $('#lobby .l-bar div').style.width = (n / C.players.max * 100) + '%';
  $('#lobby .l-timer').textContent = Math.max(0, Math.ceil(S.timeLeft));
  $('#lobby .l-sub').textContent = (S.timeLeft <= 0 && n < C.timing.lobbyMinPlayers) ? T.waitingPlayers : T.lobbySub;
}

// ---------------- Champion bay trên đường đua ----------------
function makeChampionBumper() {
  const r = C.champion.radius;
  const b = add(Bodies.circle(W / 2, S.camY + H * 0.62, r, { ...stat, restitution: 1.0 }), 'champion', 'primary');
  b.move = (b) => {
    const x = W / 2 + Math.sin(simT * 0.7) * (IW / 2 - r - 10);
    const y = Math.min(S.camY + H * 0.62 + Math.sin(simT * 1.3) * 120, geo.barrierY - 400);
    Body.setPosition(b, { x, y }, true);
  };
  kinematic.push(b);
  const sprite = makeSprite(champion);
  return { body: b, sprite, nextWave: C.champion.shockwaveEvery, user: champion };
}
function removeChampion() {
  if (!S.champ) return;
  Composite.remove(engine.world, S.champ.body);
  bodies = bodies.filter(b => b !== S.champ.body); kinematic = kinematic.filter(b => b !== S.champ.body);
  S.champ = null;
}

// ---------------- HYPE ----------------
function addHype(v) {
  if (v <= 0) return;
  S.hype = Math.min(100, S.hype + v);
  if (S.hype >= 100 && (S.phase === 'race' || S.phase === 'boss')) triggerHype();
}
function nextEventName() { const ev = C.hype.events; return ev.length ? ev[S.hypeIdx % ev.length] : null; }
function triggerHype() {
  S.hype = 0; play('hype');
  if (S.phase === 'boss') {
    banner(T.maxHype, `-${C.hype.bossDamage} ${T.bossName}`);
    hitBoss(C.hype.bossDamage, null, T.maxHype);
    return;
  }
  const ev = nextEventName(); if (!ev) return; S.hypeIdx++;
  banner(T.hypeBy, `HYPE! ${T.events[ev] || ev}`);
  EVENTS[ev]?.();
}
const inView = p => p.body.position.y > S.camY + 150 && p.body.position.y < S.camY + H - 250;
const EVENTS = {
  meteor() {
    const cands = alive().filter(inView).sort(() => Math.random() - 0.5).slice(0, 10);
    for (const p of cands) S.crosshairs.push({ p, t: 1.1 });
  },
  hurricane() { S.wind = 3.5; },
  antigravity() { S.gravityTimer = 1.4; engine.gravity.y = -0.7 * C.course.gravity; },
  earthquake() { S.quake = 2.5; },
};
function explode(x, y, radius = 150, power = 16) {
  S.effects.push({ type: 'boom', x, y, t: 0, life: 0.5, r: radius });
  burst(x, y, '#ffb347', 22); S.shake = Math.max(S.shake, 14);
  for (const p of alive()) {
    if (p.shield) continue;
    const dx = p.body.position.x - x, dy = p.body.position.y - y, d = Math.hypot(dx, dy);
    if (d < radius && d > 0.1) {
      const f = power * (1 - d / radius);
      Body.setVelocity(p.body, { x: p.body.velocity.x + dx / d * f, y: p.body.velocity.y + dy / d * f - 4 });
    }
  }
}

// ---------------- BOSS ----------------
function isBonk(text) { const t = text.toLowerCase(); return C.boss.keywords.some(k => t.includes(k.toLowerCase())); }
function bonk(u, dmg, label, ignoreCooldown) {
  const B = S.boss; if (!B || B.dead || S.phase !== 'boss') return;
  const now = performance.now() / 1000;
  if (!ignoreCooldown) {
    const last = B.lastBonk.get(u.id) || 0;
    if (now - last < C.boss.userCooldown) return;
    B.lastBonk.set(u.id, now);
  }
  const p = players.get(u.id);
  const from = (p && p.body && !p.dead) ? { x: p.body.position.x, y: p.body.position.y } : { x: rnd(L + 60, Rr - 60), y: geo.barrierY - 40 };
  S.shots.push({ x: from.x, y: from.y, sx: from.x, sy: from.y, t: 0, life: 0.35, dmg, name: u.name, label });
}
function hitBoss(dmg, name, label) {
  const B = S.boss; if (!B || B.dead) return;
  B.hp = Math.max(0, B.hp - dmg); B.flash = 0.15; S.shake = Math.max(S.shake, 5);
  play('bonk');
  S.texts.push({ x: W / 2 + rnd(-160, 160), y: geo.bossY - geo.bossR - 60 + rnd(-30, 30), text: name ? `${name} ${label || T.bonk}` : (label || T.bonk), t: 0, life: 1.1, color: COL['accent-2'], size: 30 });
  updateBossHud();
  if (B.hp <= 0) bossDefeated();
}
function bossAttack() {
  const B = S.boss;
  const targets = alive().filter(p => !p.shield && p.body.position.y < geo.barrierY && p.body.position.y > S.camY + 250);
  const tgt = targets.length ? pick(targets) : null;
  const to = tgt ? { x: tgt.body.position.x, y: tgt.body.position.y } : { x: rnd(L + 60, Rr - 60), y: geo.barrierY };
  S.lasers.push({ x: to.x, y: to.y, t: 0, life: 0.3, tgt });
  B.chat = Math.max(0, B.chat - C.boss.attackDamage);
  play('bossHit');
  updateBossHud();
}
function updateBossHud() {
  const B = S.boss; if (!B) return;
  $('#bossHud .bar.chat div').style.width = (B.chat / B.chatMax * 100) + '%';
  $('#bossHud .bar.chat span').textContent = Math.ceil(B.chat);
  $('#bossHud .bar.boss div').style.width = (B.hp / B.max * 100) + '%';
  $('#bossHud .bar.boss span').textContent = Math.ceil(B.hp);
}
function bossDefeated() {
  const B = S.boss; B.dead = true;
  explode(W / 2, geo.bossY, 260, 10);
  for (let i = 0; i < 4; i++) burst(W / 2 + rnd(-100, 100), geo.bossY + rnd(-100, 100), COL['boss-color'], 30);
  if (geo.barrier) { Composite.remove(engine.world, geo.barrier); bodies = bodies.filter(b => b !== geo.barrier); geo.barrier = null; }
  if (geo.bossBody) { Composite.remove(engine.world, geo.bossBody); bodies = bodies.filter(b => b !== geo.bossBody); geo.bossBody = null; }
  banner(T.chatWinsSub, T.chatWins, 2.2);
  play('win');
  setPhase('finish');
}

// ---------------- Hiệu ứng ----------------
function burst(x, y, color, n = 14) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, s = rnd(2, 9);
    S.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, t: 0, life: rnd(0.4, 0.9), color, size: rnd(4, 9) });
  }
}
let bannerTimer = null;
function banner(small, big, secs = 2) {
  ui.banner.querySelector('.b-small').textContent = small || '';
  ui.banner.querySelector('.b-big').textContent = big || '';
  ui.banner.classList.add('show');
  clearTimeout(bannerTimer); bannerTimer = setTimeout(() => ui.banner.classList.remove('show'), secs * 1000);
}
function toast(user, html) {
  const d = document.createElement('div'); d.className = 'toast';
  if (user) d.appendChild(avatarEl(user));
  const s = document.createElement('span'); s.innerHTML = html; d.appendChild(s);
  ui.toasts.appendChild(d);
  while (ui.toasts.children.length > 4) ui.toasts.firstChild.remove();
  setTimeout(() => d.remove(), 4000);
}
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ---------------- Quà ----------------
function giftRule(g) {
  if (C.gifts.byName[g.name]) return C.gifts.byName[g.name];
  let r = null;
  for (const t of C.gifts.tiers) if ((g.diamonds || 0) >= t.minDiamonds) r = t;
  return r;
}
function applyGift(u, g) {
  const rule = giftRule(g) || { action: 'none', bossDamage: 0, hype: (g.diamonds || 1) * C.hype.perDiamond };
  const mult = C.gifts.multiplyByCount ? (g.count || 1) : 1;
  if (C.players.joinOnGift) tryJoin(u);
  addHype((rule.hype ?? (g.diamonds || 1) * C.hype.perDiamond) * mult);
  if (S.phase === 'boss' && rule.bossDamage) bonk(u, rule.bossDamage * mult, `${g.name} x${g.count || 1}`, true);
  const p = players.get(u.id);
  let label = '';
  if (p && p.body && !p.dead && ['start', 'race', 'boss', 'finish'].includes(S.phase)) {
    if (rule.action === 'boost') { p.boost = 2.5; Body.setVelocity(p.body, { x: p.body.velocity.x * 0.3, y: 20 }); label = T.giftBoost; }
    else if (rule.action === 'big' && !p.big) { p.big = true; Body.scale(p.body, 1.6, 1.6); p.r *= 1.6; label = T.giftBig; }
    else if (rule.action === 'shield') { p.shield = true; label = T.giftShield; }
  }
  toast(u, `<b>@${esc(u.name)}</b> ${esc(g.name)} x${g.count || 1} ${label ? '→ <b>' + esc(label) + '</b>' : ''}`);
}

// =====================================================================
//  SỰ KIỆN TỪ TIKTOK
// =====================================================================
function handle(ev) {
  const u = ev.user;
  switch (ev.type) {
    case 'chat': {
      const text = ev.text || '';
      if (S.phase === 'boss' && isBonk(text)) bonk(u, C.boss.damagePerBonk);
      if (C.players.joinOnComment) {
        const kw = C.players.joinKeywords;
        if (!kw.length || kw.some(k => text.toLowerCase().includes(k.toLowerCase()))) tryJoin(u);
      }
      addHype(C.hype.perComment);
      break;
    }
    case 'like': addHype((ev.count || 1) * C.hype.perLike); if (C.players.joinOnLike) tryJoin(u); break;
    case 'follow': addHype(C.hype.perFollow); if (C.players.joinOnFollow) tryJoin(u); toast(u, `<b>@${esc(u.name)}</b> followed! +HYPE`); break;
    case 'share': addHype(C.hype.perShare); toast(u, `<b>@${esc(u.name)}</b> shared! +HYPE`); break;
    case 'gift': applyGift(u, ev.gift); break;
    case 'status':
      ui.status.textContent = ev.text; ui.status.className = 'hide-when-connected ' + ev.state; break;
  }
}

function connectWS() {
  if (location.protocol === 'file:') { ui.status.textContent = 'Mở qua http://localhost (chạy server.js)'; return; }
  const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  ws.onmessage = e => { try { handle(JSON.parse(e.data)); } catch (err) { console.error(err); } };
  ws.onclose = () => { ui.status.textContent = 'Mất kết nối server — thử lại...'; ui.status.className = ''; setTimeout(connectWS, 2000); };
}
if (!APP) connectWS();

// =====================================================================
//  VÒNG LẶP
// =====================================================================
const STEP = 1 / 120;
let acc = 0, last = performance.now(), uiTimer = 0;

function physicsStep() {
  stepKinematic(STEP);
  // Gió / động đất / chống kẹt / boost
  for (const p of alive()) {
    const b = p.body, v = b.velocity;
    let vx = v.x, vy = v.y;
    if (S.wind > 0 && !p.shield) vx += Math.sin(simT * 2.2 + b.position.y * 0.004) * 0.9;
    if (p.boost > 0) vy = Math.max(vy, 9);
    const sp = Math.hypot(vx, vy);
    if (sp > 24) { vx *= 24 / sp; vy *= 24 / sp; }
    if (vx !== v.x || vy !== v.y) Body.setVelocity(b, { x: vx, y: vy });
  }
  Engine.update(engine, STEP * 1000);
}

function update(dt) {
  S.t += dt;
  const ph = S.phase;

  // ---- logic theo pha ----
  if (ph === 'lobby') {
    S.timeLeft -= dt;
    if (players.size >= C.players.max) S.timeLeft = Math.min(S.timeLeft, 0);
    if (S.timeLeft <= 0) {
      S.timeLeft = 0;
      if (players.size >= Math.max(1, C.timing.lobbyMinPlayers)) setPhase('start');
    }
  } else if (ph === 'start') {
    S.timeLeft -= dt;
    const n = Math.ceil(S.timeLeft);
    if (n !== S.lastCount) { S.lastCount = n; ui.count.textContent = n > 0 ? n : T.start; ui.count.classList.remove('tick'); void ui.count.offsetWidth; ui.count.classList.add('tick'); }
    if (S.timeLeft <= 0) setPhase('race');
  } else if (ph === 'race') {
    S.raceTime += dt;
    const lead = leader();
    if (C.boss.enabled && lead && lead.body.position.y > geo.barrierY - 160) setPhase('boss');
    else if (!C.boss.enabled && lead && lead.body.position.y > geo.finishY) finishWith(lead);
    else if (C.boss.enabled && S.raceTime > C.timing.raceMax) setPhase('boss');
    else if (!alive().length) setPhase('result');
  } else if (ph === 'boss') {
    S.raceTime += dt;
    const B = S.boss;
    B.nextAttack -= dt;
    if (B.nextAttack <= 0 && !B.dead) { B.nextAttack = C.boss.attackEvery; bossAttack(); }
    if (!B.dead && (B.chat <= 0 || S.t > C.timing.bossMax || !alive().length)) setPhase('bossWin');
  } else if (ph === 'finish') {
    S.raceTime += dt;
    const lead = leader();
    if (lead && lead.body.position.y > geo.finishY) finishWith(lead);
    else if (S.t > C.timing.finishMax || !alive().length) { S.winner = null; setPhase('result'); }
  } else if (ph === 'bossWin') {
    // boss hút toàn bộ bi
    S.boss.scale = Math.min(1.35, S.boss.scale + dt * 0.4);
    for (const p of alive()) {
      const b = p.body, dx = W / 2 - b.position.x, dy = geo.bossY - b.position.y, d = Math.hypot(dx, dy);
      if (d < geo.bossR * 1.1) { killBall(p, false); continue; }
      b.collisionFilter.mask = 0;
      Body.setVelocity(b, { x: dx / d * Math.min(30, 6 + S.t * 14), y: dy / d * Math.min(30, 6 + S.t * 14) });
    }
    if (S.t > 2.5) { S.winner = null; setPhase('result'); }
  } else if (ph === 'result') {
    S.timeLeft -= dt;
    $('#result .r-next').textContent = `${T.nextRace} ${Math.max(0, Math.ceil(S.timeLeft))}`;
    if (S.timeLeft <= 0) setPhase('lobby');
  }

  if (S.hype >= 100 && (ph === 'race' || ph === 'boss')) triggerHype();

  // ---- hiệu ứng có thời hạn ----
  if (S.gravityTimer > 0) { S.gravityTimer -= dt; if (S.gravityTimer <= 0) engine.gravity.y = C.course.gravity; }
  if (S.wind > 0) S.wind -= dt;
  if (S.quake > 0) {
    S.quake -= dt; S.shake = Math.max(S.shake, 10);
    if (Math.random() < dt * 8) for (const p of alive()) if (!p.shield) Body.setVelocity(p.body, { x: p.body.velocity.x + rnd(-7, 7), y: p.body.velocity.y - rnd(2, 8) });
  }
  for (const p of alive()) {
    if (p.raining && p.body.position.y > geo.barrierY - 220) { p.raining = false; p.body.collisionFilter.mask = 0xFFFF; }
    if (p.boost > 0) p.boost -= dt;
    // chống kẹt: đứng yên quá 4 giây trong lúc đua thì hích nhẹ
    if (ph === 'race' || ph === 'finish') {
      const sp = Math.hypot(p.body.velocity.x, p.body.velocity.y);
      p.still = sp < 0.4 ? p.still + dt : 0;
      if (p.still > 4) { p.still = 0; Body.setVelocity(p.body, { x: rnd(-6, 6), y: -6 }); }
    }
    if (p.body.position.y > geo.floorY + 200 || p.body.position.x < -100 || p.body.position.x > W + 100) killBall(p, false);
  }
  for (const c of S.crosshairs) { c.t -= dt; if (c.t <= 0 && !c.done) { c.done = true; if (c.p.body) explode(c.p.body.position.x, c.p.body.position.y); } }
  S.crosshairs = S.crosshairs.filter(c => !c.done);
  for (const s of S.shots) {
    s.t += dt; const k = Math.min(1, s.t / s.life);
    s.x = s.sx + (W / 2 - s.sx) * k; s.y = s.sy + (geo.bossY - s.sy) * k - Math.sin(k * Math.PI) * 120;
    if (k >= 1 && !s.done) { s.done = true; hitBoss(s.dmg, s.name, s.label); burst(s.x, s.y, COL['bonk-shot'], 8); }
  }
  S.shots = S.shots.filter(s => !s.done);
  for (const l of S.lasers) { l.t += dt; if (l.t >= l.life && !l.done) { l.done = true; if (l.tgt && C.boss.attackKillsBall) killBall(l.tgt); else burst(l.x, l.y, COL.laser, 8); } }
  S.lasers = S.lasers.filter(l => l.t < l.life + 0.15);
  for (const q of S.particles) { q.t += dt; q.x += q.vx; q.y += q.vy; q.vy += 0.3; }
  S.particles = S.particles.filter(q => q.t < q.life);
  for (const x of S.texts) { x.t += dt; x.y -= 40 * dt; }
  S.texts = S.texts.filter(x => x.t < x.life);
  for (const e of S.effects) e.t += dt;
  S.effects = S.effects.filter(e => e.t < e.life);
  if (S.boss) S.boss.flash = Math.max(0, S.boss.flash - dt);
  S.shake *= 0.88;

  // champion phát sóng
  if (S.champ) {
    S.champ.nextWave -= dt;
    if (S.champ.nextWave <= 0) {
      S.champ.nextWave = C.champion.shockwaveEvery;
      const { x, y } = S.champ.body.position;
      S.effects.push({ type: 'wave', x, y, t: 0, life: 0.8, r: 360 });
      for (const p of alive()) {
        const dx = p.body.position.x - x, dy = p.body.position.y - y, d = Math.hypot(dx, dy);
        if (d < 360 && d > 1 && !p.shield) Body.setVelocity(p.body, { x: p.body.velocity.x + dx / d * 11, y: p.body.velocity.y + dy / d * 11 });
      }
    }
  }

  // ---- camera ----
  let target = 0;
  if (ph === 'race' || ph === 'finish') {
    const lead = leader();
    if (lead) target = lead.body.position.y - H * 0.42;
    if (ph === 'finish') target = Math.max(target, geo.camMax);
  } else if (ph === 'boss' || ph === 'bossWin') target = geo.camMax;
  else if (ph === 'result') target = S.camY;
  target = Math.max(0, Math.min(target, geo.camMax));
  S.camY += (target - S.camY) * Math.min(1, dt * 4);

  // ---- HUD (10 lần/giây) ----
  uiTimer -= dt;
  if (uiTimer <= 0) { uiTimer = 0.1; updateHud(); }
}

function leader() {
  let best = null;
  for (const p of alive()) if (!best || p.body.position.y > best.body.position.y) best = p;
  return best;
}
function finishWith(p) {
  S.winner = p;
  wins[p.id] = (wins[p.id] || 0) + 1; store.set('wins', wins);
  champion = { id: p.id, name: p.name, nick: p.nick, avatar: p.avatar, wins: wins[p.id] };
  store.set('champion', champion);
  burst(p.body.position.x, p.body.position.y, COL['accent-2'], 40);
  play('win');
  setPhase('result');
}
function showResult() {
  const r = ui.result, img = r.querySelector('.r-avatar');
  show('result');
  r.className = S.winner ? 'win' : 'lose';
  if (S.winner) {
    r.querySelector('.r-title').textContent = T.winner;
    r.querySelector('.r-sub').textContent = '';
    img.src = S.winner.avatar || S.winner.sprite.toDataURL(); img.classList.remove('hidden');
    r.querySelector('.r-name').textContent = '@' + S.winner.name;
    r.querySelector('.r-wins').textContent = `${wins[S.winner.id]} ${T.wins}`;
  } else {
    const lostToBoss = !!S.boss && !S.boss.dead;
    r.querySelector('.r-title').textContent = lostToBoss ? T.bossWins : T.noWinner;
    r.querySelector('.r-sub').textContent = lostToBoss ? T.bossWinsSub : '';
    img.classList.add('hidden'); r.querySelector('.r-name').textContent = ''; r.querySelector('.r-wins').textContent = '';
  }
}

let lastTop = '';
function updateHud() {
  const ph = S.phase;
  if (ph === 'lobby') updateLobby();
  if (ph === 'race' || ph === 'finish') {
    const top = alive().sort((a, b) => b.body.position.y - a.body.position.y).slice(0, 3);
    const key = top.map(p => p.id).join('|');
    if (key !== lastTop) {
      lastTop = key; ui.top3.innerHTML = '';
      top.forEach((p, i) => {
        const row = document.createElement('div'); row.className = 'top-row';
        row.innerHTML = `<div class="top-rank">${i + 1}</div>`;
        row.appendChild(avatarEl(p));
        const n = document.createElement('div'); n.className = 'top-name'; n.textContent = '@' + p.name; row.appendChild(n);
        ui.top3.appendChild(row);
      });
    }
    const s = Math.floor(S.raceTime);
    ui.timer.textContent = `⏱ ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  }
  const ev = nextEventName();
  ui.hype.querySelector('.hype-label').textContent = S.phase === 'boss' ? `${T.hypeLabel} > MEGA ${T.bossKeyword}` : `${T.hypeLabel} > ${(T.events[ev] || ev || '').toUpperCase()}`;
  ui.hype.querySelector('.hype-fill').style.width = S.hype + '%';
  ui.hype.querySelector('.hype-pct').textContent = S.hype >= 100 ? T.maxHype : Math.floor(S.hype) + '%';
  ui.hype.classList.toggle('full', S.hype >= 100);
}

// =====================================================================
//  VẼ
// =====================================================================
const cv = $('#game'), ctx = cv.getContext('2d');

function drawBody(b) {
  const parts = b.parts.length > 1 ? b.parts.slice(1) : [b];
  ctx.fillStyle = COL[b.color] || b.color || '#888';
  for (const part of parts) {
    if (b.kind === 'peg' || (part.circleRadius && b.kind !== 'champion' && b.kind !== 'boss')) {
      ctx.beginPath(); ctx.arc(part.position.x, part.position.y, part.circleRadius, 0, Math.PI * 2); ctx.fill();
      if (b.kind === 'peg') { ctx.lineWidth = 3; ctx.strokeStyle = COL['peg-edge']; ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.beginPath(); ctx.arc(part.position.x - 4, part.position.y - 4, part.circleRadius * 0.35, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = COL[b.color]; }
      continue;
    }
    const v = part.vertices;
    ctx.beginPath(); ctx.moveTo(v[0].x, v[0].y);
    for (let i = 1; i < v.length; i++) ctx.lineTo(v[i].x, v[i].y);
    ctx.closePath(); ctx.fill();
    if (b.kind === 'ramp') { ctx.lineWidth = 4; ctx.strokeStyle = COL['ramp-edge']; ctx.stroke(); }
  }
  if (b.kind === 'spinner' || b.kind === 'seesaw') {
    ctx.fillStyle = COL['spinner-hub']; ctx.beginPath(); ctx.arc(b.position.x, b.position.y, 11, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(b.position.x, b.position.y, 4, 0, Math.PI * 2); ctx.fill();
  }
  if (b.kind === 'hammer') {
    ctx.fillStyle = COL['spinner-hub']; ctx.beginPath(); ctx.arc(b.pivot.x, b.pivot.y, 14, 0, Math.PI * 2); ctx.fill();
  }
  if (b.kind === 'bouncer') {
    ctx.save(); ctx.translate(b.position.x, b.position.y); ctx.rotate(b.angle);
    ctx.strokeStyle = 'rgba(255,255,255,.8)'; ctx.lineWidth = 3;
    for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(i * 45 - 12, 24); ctx.lineTo(i * 45, 12); ctx.lineTo(i * 45 + 12, 24); ctx.stroke(); }
    ctx.restore();
  }
}

function drawBackground(y0) {
  const bossTop = geo.barrierY - 420;
  // khu đua
  if (y0 < bossTop) {
    ctx.fillStyle = COL.bg; ctx.fillRect(0, y0, W, Math.min(H, bossTop - y0));
    if (imgOk(IMG.bg)) {
      const ih = IMG.bg.naturalHeight * (W / IMG.bg.naturalWidth);
      for (let y = Math.floor(y0 / ih) * ih; y < Math.min(y0 + H, bossTop); y += ih) ctx.drawImage(IMG.bg, 0, y, W, ih);
    } else {
      ctx.fillStyle = COL['bg-dots'];
      for (let y = Math.floor(y0 / 90) * 90; y < Math.min(y0 + H, bossTop); y += 90)
        for (let x = (y / 90) % 2 ? 45 : 0; x < W; x += 90) { ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill(); }
    }
  }
  // khu boss
  if (y0 + H > bossTop) {
    const g = ctx.createLinearGradient(0, bossTop, 0, geo.floorY);
    g.addColorStop(0, COL.bg); g.addColorStop(0.18, COL['boss-bg-2']); g.addColorStop(1, COL['boss-bg']);
    ctx.fillStyle = g; ctx.fillRect(0, Math.max(y0, bossTop), W, H);
    if (imgOk(IMG.bossBg)) { ctx.globalAlpha = 0.9; ctx.drawImage(IMG.bossBg, 0, geo.camMax, W, H); ctx.globalAlpha = 1; }
  }
}

function drawBoss() {
  if (!C.boss.enabled) return;
  const B = S.boss;
  if (B && B.dead) return;
  const r = geo.bossR * (B ? B.scale : 1);
  const sx = (B && B.flash > 0) ? rnd(-6, 6) : 0;
  ctx.save(); ctx.translate(W / 2 + sx, geo.bossY);
  // hào quang
  const pulse = 1 + Math.sin(S.t * 5) * 0.05;
  ctx.fillStyle = 'rgba(255,60,40,.18)'; ctx.beginPath(); ctx.arc(0, 0, r * 1.35 * pulse, 0, Math.PI * 2); ctx.fill();
  if (imgOk(IMG.boss)) ctx.drawImage(IMG.boss, -r, -r, r * 2, r * 2);
  else {
    ctx.fillStyle = COL['boss-color'];
    // sừng
    ctx.beginPath(); ctx.moveTo(-r * 0.75, -r * 0.5); ctx.lineTo(-r * 0.95, -r * 1.15); ctx.lineTo(-r * 0.3, -r * 0.85); ctx.fill();
    ctx.beginPath(); ctx.moveTo(r * 0.75, -r * 0.5); ctx.lineTo(r * 0.95, -r * 1.15); ctx.lineTo(r * 0.3, -r * 0.85); ctx.fill();
    ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 8; ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.stroke();
    // mắt
    const happy = S.phase === 'bossWin' || S.phase === 'result';
    ctx.fillStyle = '#ffd23f';
    if (happy) { ctx.lineWidth = 12; ctx.strokeStyle = '#ffd23f'; for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(s * r * 0.35, -r * 0.12, r * 0.16, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); } }
    else for (const s of [-1, 1]) {
      ctx.beginPath(); ctx.ellipse(s * r * 0.35, -r * 0.15, r * 0.17, r * 0.2, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#2a0d10'; ctx.beginPath(); ctx.arc(s * r * 0.33, -r * 0.1, r * 0.08, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#ffd23f';
    }
    // miệng răng cưa
    ctx.fillStyle = '#2a0d10'; ctx.beginPath(); ctx.ellipse(0, r * 0.35, r * 0.5, happy ? r * 0.32 : r * 0.18, 0, 0, Math.PI); ctx.fill();
    ctx.fillStyle = '#fff'; const n = 7;
    for (let i = 0; i < n; i++) { const x = -r * 0.45 + i * r * 0.9 / (n - 1); ctx.beginPath(); ctx.moveTo(x - 9, r * 0.35); ctx.lineTo(x + 9, r * 0.35); ctx.lineTo(x, r * 0.35 + 18); ctx.fill(); }
  }
  if (B && B.flash > 0) { ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); }
  // vương miện khi thắng
  if (S.phase === 'bossWin' || (S.phase === 'result' && !S.winner && B)) {
    ctx.fillStyle = COL['accent-2']; ctx.beginPath();
    ctx.moveTo(-r * 0.5, -r * 0.95); ctx.lineTo(-r * 0.55, -r * 1.4); ctx.lineTo(-r * 0.25, -r * 1.15); ctx.lineTo(0, -r * 1.5);
    ctx.lineTo(r * 0.25, -r * 1.15); ctx.lineTo(r * 0.55, -r * 1.4); ctx.lineTo(r * 0.5, -r * 0.95); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
}

function drawBall(p) {
  const b = p.body, x = b.position.x, y = b.position.y, r = p.r;
  if (p.boost > 0) { ctx.fillStyle = 'rgba(255,210,63,.45)'; ctx.beginPath(); ctx.arc(x, y - 8, r * 1.7, 0, Math.PI * 2); ctx.fill(); }
  ctx.save(); ctx.translate(x, y); ctx.rotate(b.angle);
  ctx.drawImage(p.sprite, -r, -r, r * 2, r * 2);
  ctx.restore();
  if (p.shield) { ctx.lineWidth = 4; ctx.strokeStyle = COL['ball-shield']; ctx.beginPath(); ctx.arc(x, y, r + 6 + Math.sin(S.t * 6) * 2, 0, Math.PI * 2); ctx.stroke(); }
}
function drawNames(list) {
  ctx.font = `700 ${COL['name-size'] || '15px'} ${COL.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
  ctx.lineWidth = 4; ctx.strokeStyle = COL['name-stroke']; ctx.fillStyle = COL['name-color'];
  for (const p of list) {
    const x = p.body.position.x, y = p.body.position.y - p.r - 3, t = '@' + (p.name.length > 14 ? p.name.slice(0, 13) + '…' : p.name);
    ctx.strokeText(t, x, y); ctx.fillText(t, x, y);
  }
}

function render() {
  const sx = S.shake > 0.5 ? rnd(-S.shake, S.shake) : 0, sy = S.shake > 0.5 ? rnd(-S.shake, S.shake) : 0;
  const y0 = S.camY;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.save(); ctx.translate(sx, -y0 + sy);
  drawBackground(y0);

  // vạch đích
  if (geo.finishY < y0 + H && (!C.boss.enabled || !geo.barrier)) {
    const sq = 30;
    for (let x = L, i = 0; x < Rr; x += sq, i++) { ctx.fillStyle = i % 2 ? '#222' : COL.finish; ctx.fillRect(x, geo.finishY - sq / 2, sq, sq / 2); ctx.fillStyle = i % 2 ? COL.finish : '#222'; ctx.fillRect(x, geo.finishY, sq, sq / 2); }
  }

  // vật cản
  const top = y0 - 300, bot = y0 + H + 300;
  for (const b of bodies) {
    if (b.kind === 'champion' || b.kind === 'boss' || b.kind === 'wall') continue;
    if (b.bounds.max.y < top || b.bounds.min.y > bot) continue;
    if (b.kind === 'barrier') {
      ctx.save(); ctx.shadowColor = COL['boss-barrier']; ctx.shadowBlur = 25; drawBody(b); ctx.restore();
      ctx.font = `800 30px ${COL.font}`; ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText(T.bossGate, W / 2, b.position.y + 22);
      continue;
    }
    drawBody(b);
  }
  // tường
  ctx.fillStyle = COL.wall; ctx.fillRect(0, y0 - 50, WALL, H + 100); ctx.fillRect(W - WALL, y0 - 50, WALL, H + 100);
  ctx.fillStyle = COL['wall-edge']; ctx.fillRect(WALL - 6, y0 - 50, 6, H + 100); ctx.fillRect(W - WALL, y0 - 50, 6, H + 100);

  drawBoss();

  // bi
  const vis = [];
  for (const p of players.values()) {
    if (!p.body || p.dead) continue;
    const y = p.body.position.y; if (y < top || y > bot) continue;
    drawBall(p); vis.push(p);
  }
  if (C.players.showNames && S.phase !== 'lobby') drawNames(vis.length > 120 ? vis.slice(0, 120) : vis);

  // champion
  if (S.champ) {
    const { x, y } = S.champ.body.position, r = C.champion.radius;
    ctx.fillStyle = COL.primary; ctx.beginPath(); ctx.arc(x, y, r + 10, 0, Math.PI * 2); ctx.fill();
    ctx.drawImage(S.champ.sprite, x - r, y - r, r * 2, r * 2);
    ctx.fillStyle = COL['accent-2']; ctx.beginPath();
    ctx.moveTo(x - 50, y - r + 4); ctx.lineTo(x - 56, y - r - 44); ctx.lineTo(x - 24, y - r - 18); ctx.lineTo(x, y - r - 54);
    ctx.lineTo(x + 24, y - r - 18); ctx.lineTo(x + 56, y - r - 44); ctx.lineTo(x + 50, y - r + 4); ctx.closePath(); ctx.fill();
    ctx.fillStyle = COL.primary; ctx.beginPath(); ctx.roundRect(x - 170, y + r + 2, 340, 82, 20); ctx.fill();
    ctx.fillStyle = COL['accent-2']; ctx.font = `800 24px ${COL.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText(T.previousChampion, x, y + r + 8);
    ctx.fillStyle = '#fff'; ctx.font = `800 28px ${COL.font}`;
    ctx.fillText('@' + S.champ.user.name, x, y + r + 34);
  }

  // hiệu ứng
  for (const e of S.effects) {
    const k = e.t / e.life;
    if (e.type === 'boom') { ctx.fillStyle = `rgba(255,170,60,${0.6 * (1 - k)})`; ctx.beginPath(); ctx.arc(e.x, e.y, e.r * (0.3 + k), 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = `rgba(255,240,180,${0.8 * (1 - k)})`; ctx.beginPath(); ctx.arc(e.x, e.y, e.r * 0.5 * (0.3 + k), 0, Math.PI * 2); ctx.fill(); }
    if (e.type === 'wave') { ctx.lineWidth = 10 * (1 - k); ctx.strokeStyle = `rgba(160,80,220,${1 - k})`; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(e.x, e.y, e.r * k * (1 - i * 0.2), 0, Math.PI * 2); ctx.stroke(); } }
  }
  for (const c of S.crosshairs) {
    if (!c.p.body || c.p.dead) continue;
    const { x, y } = c.p.body.position, r = 34 + c.t * 20;
    ctx.strokeStyle = COL.laser; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x - r - 12, y); ctx.lineTo(x + r + 12, y); ctx.moveTo(x, y - r - 12); ctx.lineTo(x, y + r + 12); ctx.stroke();
  }
  for (const s of S.shots) {
    ctx.fillStyle = COL['bonk-shot']; ctx.shadowColor = COL['bonk-shot']; ctx.shadowBlur = 15;
    ctx.beginPath(); ctx.arc(s.x, s.y, s.dmg > 5 ? 14 : 8, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
  }
  for (const l of S.lasers) {
    const a = 1 - Math.max(0, l.t - l.life) / 0.15;
    ctx.strokeStyle = COL.laser; ctx.globalAlpha = a; ctx.lineWidth = 8; ctx.shadowColor = COL.laser; ctx.shadowBlur = 20;
    ctx.beginPath(); ctx.moveTo(W / 2, geo.bossY - geo.bossR * 0.6); ctx.lineTo(l.x, l.y); ctx.stroke();
    ctx.shadowBlur = 0; ctx.globalAlpha = 1;
  }
  for (const q of S.particles) { ctx.globalAlpha = 1 - q.t / q.life; ctx.fillStyle = q.color; ctx.fillRect(q.x - q.size / 2, q.y - q.size / 2, q.size, q.size); }
  ctx.globalAlpha = 1;
  for (const x of S.texts) {
    ctx.globalAlpha = 1 - x.t / x.life; ctx.font = `800 ${x.size}px ${COL.font}`; ctx.textAlign = 'center';
    ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.strokeText(x.text, x.x, x.y); ctx.fillStyle = x.color; ctx.fillText(x.text, x.x, x.y);
  }
  ctx.globalAlpha = 1;
  ctx.restore();

  // gió (toàn màn hình)
  if (S.wind > 0) {
    ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 4;
    for (let i = 0; i < 18; i++) {
      const y = (i * 113 + S.t * 400) % H, x = ((i * 257 + S.t * 900) % (W + 400)) - 200, dir = Math.sin(simT * 2.2 + (y + S.camY) * 0.004) > 0 ? 1 : -1;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 160 * dir, y); ctx.stroke();
    }
  }
  // mini-map tiến độ (trong tường phải)
  if (S.phase === 'race' || S.phase === 'finish') {
    const mx = W - WALL / 2, mt = 420, mb = 1500, span = geo.barrierY - geo.courseTop;
    ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.fillRect(mx - 5, mt, 10, mb - mt);
    const list = alive().sort((a, b) => b.body.position.y - a.body.position.y).slice(0, 25);
    for (const p of list.reverse()) {
      const k = Math.max(0, Math.min(1, (p.body.position.y - geo.courseTop) / span));
      ctx.drawImage(p.sprite, mx - 13, mt + k * (mb - mt) - 13, 26, 26);
    }
  }
}

let fpsNow = 60;
function frame(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  fpsNow = fpsNow * 0.95 + (dt > 0 ? 1 / dt : 60) * 0.05;
  acc += dt;
  let steps = 0;
  while (acc >= STEP && steps < 8) { physicsStep(); acc -= STEP; steps++; }
  if (steps >= 8) acc = 0;
  update(dt);
  render();
  requestAnimationFrame(frame);
}

// =====================================================================
//  CHẾ ĐỘ TEST  (mở http://localhost:8080/?test)
// =====================================================================
let botN = 0;
function bot() { botN++; const n = pick(['minh', 'lan', 'tuan', 'hoa', 'khoa', 'linh', 'nam', 'thu', 'duc', 'vy', 'an', 'bao']) + '_' + Math.floor(Math.random() * 9999); return { id: 'bot' + botN + n, name: n, nick: n, avatar: '' }; }
const bots = [];
function botUser() { if (!bots.length || Math.random() < 0.3) bots.push(bot()); return pick(bots); }
const anyUser = () => { const pl = alive(); return pl.length ? pick(pl) : botUser(); };
let autoBots = null;
// Lệnh điều khiển (bảng điều khiển của app gửi tới, hoặc bảng ?test)
const COMMANDS = {
  addPlayers(n = 1) { for (let i = 0; i < n; i++) { const u = bot(); bots.push(u); handle({ type: 'chat', user: u, text: 'me' }); } },
  likes(n = 40) { handle({ type: 'like', user: botUser(), count: n }); },
  follow() { handle({ type: 'follow', user: botUser() }); },
  share() { handle({ type: 'share', user: botUser() }); },
  hypeFull() { addHype(100); },
  gift(diamonds = 1, name = 'Rose') { handle({ type: 'gift', user: anyUser(), gift: { name, diamonds, count: 1 } }); },
  bonk(n = 20) { for (let i = 0; i < n; i++) handle({ type: 'chat', user: anyUser(), text: (C.boss.keywords[0] || 'bonk') }); },
  skip() {
    if (S.phase === 'lobby' || S.phase === 'start' || S.phase === 'result') S.timeLeft = 0;
    else if (S.phase === 'race') setPhase(C.boss.enabled ? 'boss' : 'result');
    else if (S.phase === 'boss') hitBoss(9999);
    else if (S.phase === 'finish') S.t = 9999;
  },
  restart() { setPhase('lobby'); },
  autoBots(on) {
    if (autoBots) { clearInterval(autoBots); autoBots = null; }
    if (!on) return;
    autoBots = setInterval(() => {
      const pl = alive();
      if (S.phase === 'lobby' && Math.random() < 0.8) handle({ type: 'chat', user: bot(), text: 'me' });
      if (Math.random() < 0.5) handle({ type: 'like', user: botUser(), count: Math.ceil(Math.random() * 15) });
      if (S.phase === 'boss') for (let i = 0; i < 3; i++) if (pl.length && Math.random() < 0.7) handle({ type: 'chat', user: pick(pl), text: C.boss.keywords[0] || 'bonk' });
      if (Math.random() < 0.01) handle({ type: 'follow', user: botUser() });
      if (Math.random() < 0.01 && pl.length) handle({ type: 'gift', user: pick(pl), gift: { name: 'Rose', diamonds: 1, count: 1 } });
    }, 150);
  },
  resetWins() { wins = {}; champion = null; store.set('wins', wins); store.set('champion', null); },
};

// Áp dụng cấu hình mới ngay lập tức (không cần tải lại)
function applyConfig(full) {
  const fresh = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  deepMerge(fresh, full || {});
  for (const k of Object.keys(C)) delete C[k];
  Object.assign(C, fresh);
  // giữ tham chiếu T
  for (const k of Object.keys(T)) delete T[k];
  Object.assign(T, C.texts); C.texts = T;
  applyTexts(); loadAssets(); loadSounds();
}
const THEME_VARS = ['font','primary','primary-dark','accent','accent-2','good','panel','panel-text','bg','bg-dots','wall','wall-edge','peg','peg-edge',
  'spinner','spinner-hub','bouncer','slat','hammer','seesaw','ramp','ramp-edge','funnel','wood','boss-bg','boss-bg-2','boss-color','boss-barrier',
  'laser','bonk-shot','finish','ball-border','ball-shield','ball-boost','name-color','name-stroke','name-size','radius','hud-top'];
function applyTheme(vars) {
  const root = document.documentElement;
  for (const n of THEME_VARS) root.style.removeProperty('--' + n);
  for (const [k, v] of Object.entries(vars || {})) if (v) root.style.setProperty('--' + k, v);
  loadColors();
}
function themeDefaults() {
  const root = document.documentElement, saved = root.getAttribute('style');
  root.removeAttribute('style');
  const cs = getComputedStyle(root), out = {};
  for (const n of THEME_VARS) out[n] = cs.getPropertyValue('--' + n).trim();
  if (saved) root.setAttribute('style', saved);
  return out;
}

function setupTest() {
  const p = document.createElement('div'); p.id = 'testPanel';
  const btn = (label, fn) => { const b = document.createElement('button'); b.textContent = label; b.onclick = fn; p.appendChild(b); };
  p.innerHTML = '<b>🧪 TEST MODE</b>';
  btn('+1 người', () => COMMANDS.addPlayers(1));
  btn('+30 người', () => COMMANDS.addPlayers(30));
  btn('Tim x40', () => COMMANDS.likes(40));
  btn('Follow', COMMANDS.follow);
  btn('Share', COMMANDS.share);
  btn('Hype đầy', COMMANDS.hypeFull);
  btn('Quà Rose', () => COMMANDS.gift(1, 'Rose'));
  btn('Quà 10💎', () => COMMANDS.gift(10, 'Hand Heart'));
  btn('Quà 100💎', () => COMMANDS.gift(100, 'Big Gift'));
  btn('Bonk x20', () => COMMANDS.bonk(20));
  btn('Bỏ qua pha', COMMANDS.skip);
  btn('Bot tự chơi', e => { const on = !autoBots; COMMANDS.autoBots(on); e.target.textContent = on ? 'Tắt bot' : 'Bot tự chơi'; });
  document.body.appendChild(p);
}
if (TEST && !APP) setupTest();

window.MarbleGame = { handle, setPhase, S, players, COMMANDS, applyConfig, applyTheme };

// ---------- Kết nối với app desktop ----------
if (APP) {
  APP.on('tiktok', ev => handle(ev));
  APP.on('status', ev => handle(ev));
  APP.on('command', ({ name, args }) => { try { COMMANDS[name]?.(...(args || [])); } catch (e) { console.error(e); } });
  APP.on('config', full => applyConfig(full));
  APP.on('theme', vars => applyTheme(vars));
  APP.send('theme-defaults', themeDefaults());
  APP.send('config-defaults', DEFAULT_CONFIG);
  setInterval(() => {
    const B = S.boss;
    APP.send('state', {
      phase: S.phase, players: players.size, alive: alive().length, queue: queue.size, hype: Math.floor(S.hype),
      timeLeft: Math.max(0, Math.ceil(S.timeLeft)), raceTime: Math.floor(S.raceTime),
      boss: B ? { hp: Math.ceil(B.hp), max: B.max, chat: Math.ceil(B.chat), dead: B.dead } : null,
      champion: champion ? champion.name : null, fps: Math.round(fpsNow),
    });
  }, 500);
}

setPhase('lobby');
requestAnimationFrame(frame);
})();
