// =====================================================================
//  Bảng điều khiển — mọi thay đổi gửi sang cửa sổ game ngay lập tức
// =====================================================================
const $ = s => document.querySelector(s);
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
const clone = o => JSON.parse(JSON.stringify(o ?? null));
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);

let ALL = {}, defaults = null, overrides = {}, themeDef = null, themeOv = {}, settings = {};

// ---------- tiện ích đường dẫn "a.b.c" ----------
const getP = (o, p) => p.split('.').reduce((x, k) => (x == null ? undefined : x[k]), o);
const hasP = (o, p) => getP(o, p) !== undefined;
function setP(o, p, v) { const ks = p.split('.'); let x = o; ks.slice(0, -1).forEach(k => { if (typeof x[k] !== 'object' || x[k] === null || Array.isArray(x[k])) x[k] = {}; x = x[k]; }); x[ks.at(-1)] = v; }
function delP(o, p) {
  const ks = p.split('.'); const stack = [o]; let x = o;
  for (const k of ks.slice(0, -1)) { x = x?.[k]; if (!x) return; stack.push(x); }
  delete x[ks.at(-1)];
  for (let i = ks.length - 2; i >= 0; i--) if (Object.keys(stack[i + 1]).length === 0) delete stack[i][ks[i]];
}
const eff = p => hasP(overrides, p) ? getP(overrides, p) : getP(defaults, p);

let cfgTimer = null;
function setCfg(p, v) {
  const d = getP(defaults, p);
  if (eq(v, d)) delP(overrides, p); else setP(overrides, p, clone(v));
  document.querySelectorAll(`[data-path="${p}"]`).forEach(r => r.classList.toggle('changed', hasP(overrides, p)));
  clearTimeout(cfgTimer); cfgTimer = setTimeout(() => api.call('setConfig', overrides), 250);
}
let themeTimer = null;
function setTheme(name, v) {
  if (!v || v === themeDef[name]) delete themeOv[name]; else themeOv[name] = v;
  document.querySelectorAll(`[data-theme="${name}"]`).forEach(r => r.classList.toggle('changed', name in themeOv));
  clearTimeout(themeTimer); themeTimer = setTimeout(() => api.call('setTheme', themeOv), 150);
}
function toast(t) { const e = $('#toast'); e.textContent = tr(t); e.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => e.classList.remove('show'), 1800); }

// ---------- Tabs ----------
document.querySelectorAll('#tabs button').forEach(b => b.onclick = () => {
  document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('active', x === b));
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.id === 'tab-' + b.dataset.tab));
});

// =====================================================================
//  SCHEMA các thông số
// =====================================================================
const RULES = [
  { h: 'Thời gian chờ — để người xem kịp đọc (giây)' },
  { l: 'Chọn nhanh', t: 'presets' },
  { p: 'timing.lobby', l: 'Chờ người vào (lobby)', d: 'màn có bảng hướng dẫn lật trang', t: 'num', min: 5, max: 600 },
  { p: 'guide.slideSeconds', l: 'Mỗi trang hướng dẫn ở lobby hiện', d: 'có 3 trang: tham gia · quà · các tầng', t: 'num', min: 3, max: 30 },
  { p: 'timing.startCountdown', l: 'Màn "Cách chơi" trước khi thả bi', t: 'num', min: 3, max: 60 },
  { p: 'tower.transition', l: 'Giới thiệu mỗi tầng mới', d: 'màn có 3 bước chơi + quà ở tầng đó', t: 'num', min: 3, max: 60, step: 0.5 },
  { p: 'timing.clear', l: 'Dừng ở màn "Qua tầng"', t: 'num', min: 1, max: 30, step: 0.5 },
  { p: 'timing.result', l: 'Màn kết quả (nhà vô địch)', t: 'num', min: 3, max: 120 },
  { p: 'timing.lobbyMinPlayers', l: 'Số người tối thiểu để bắt đầu', t: 'num', min: 1, max: 200 },
  { h: 'Hướng dẫn trên màn hình' },
  { p: 'guide.guideBar', l: 'Hiện dòng quà khi đang chơi', d: 'tắt = chỉ hiện dòng việc cần làm', t: 'bool' },
  { p: 'guide.rotateSeconds', l: 'Đổi dòng hướng dẫn mỗi (giây)', d: 'xoay giữa việc cần làm ↔ bảng quà', t: 'num', min: 2, max: 30, step: 0.5 },
  { h: 'Giới hạn thời gian mỗi màn (giây)' },
  { p: 'timing.raceMax', l: 'Đua tối đa', d: 'quá giờ thì vào boss luôn', t: 'num', min: 10, max: 600 },
  { p: 'timing.bossMax', l: 'Đánh boss tối đa', t: 'num', min: 5, max: 300 },
  { p: 'timing.finishMax', l: 'Chờ về đích sau khi hạ boss (cổ điển)', t: 'num', min: 3, max: 60 },
  { h: 'Người chơi' },
  { p: 'players.max', l: 'Số bi tối đa', d: 'máy yếu nên để 100–150', t: 'num', min: 10, max: 400 },
  { p: 'players.ballRadius', l: 'Kích thước bi', d: 'áp dụng từ vòng sau', t: 'range', min: 10, max: 36, step: 1 },
  { p: 'players.joinOnComment', l: 'Comment để tham gia', t: 'bool' },
  { p: 'players.joinKeywords', l: 'Chỉ nhận comment chứa', d: 'cách nhau dấu phẩy, để trống = mọi comment', t: 'list' },
  { p: 'players.joinOnLike', l: 'Thả tim để tham gia', t: 'bool' },
  { p: 'players.joinOnFollow', l: 'Follow để tham gia', t: 'bool' },
  { p: 'players.joinOnGift', l: 'Tặng quà để tham gia', t: 'bool' },
  { p: 'players.queueForNextRace', l: 'Comment lúc đang đua → vào vòng sau', t: 'bool' },
  { p: 'players.showNames', l: 'Hiện tên trên bi', t: 'bool' },
  { h: 'Nhà vô địch vòng trước' },
  { p: 'champion.enabled', l: 'Bay trên đường đua làm chướng ngại', t: 'bool' },
  { p: 'champion.radius', l: 'Kích thước', t: 'range', min: 50, max: 180, step: 5 },
  { p: 'champion.shockwaveEvery', l: 'Phát sóng đẩy bi mỗi (giây)', t: 'num', min: 1, max: 60, step: 0.5 },
];
const BOSS = [
  { h: 'Boss' },
  { p: 'boss.enabled', l: 'Bật boss', d: 'tắt = về đích thẳng', t: 'bool' },
  { p: 'boss.keywords', l: 'Từ khoá tấn công', d: 'cách nhau dấu phẩy', t: 'list' },
  { p: 'texts.bossKeyword', l: 'Chữ hiện trên màn hình', t: 'text' },
  { p: 'boss.hpBase', l: 'Máu boss cơ bản', t: 'num', min: 1, max: 100000 },
  { p: 'boss.hpPerPlayer', l: 'Máu thêm mỗi người chơi', t: 'num', min: 0, max: 100, step: 0.1 },
  { p: 'boss.damagePerBonk', l: 'Sát thương mỗi comment', t: 'num', min: 0, max: 1000, step: 0.5 },
  { p: 'boss.userCooldown', l: 'Giãn cách bonk 1 người (giây)', t: 'num', min: 0, max: 10, step: 0.05 },
  { p: 'boss.chatHp', l: 'Máu phe chat', t: 'num', min: 1, max: 10000 },
  { p: 'boss.attackEvery', l: 'Boss đánh mỗi (giây)', t: 'num', min: 0.2, max: 20, step: 0.1 },
  { p: 'boss.attackDamage', l: 'Mỗi đòn trừ máu chat', t: 'num', min: 0, max: 1000, step: 0.5 },
  { p: 'boss.attackKillsBall', l: 'Đòn boss xoá 1 viên bi', t: 'bool' },
  { h: 'Hype meter' },
  { p: 'hype.perLike', l: '% mỗi lượt tim', t: 'num', min: 0, max: 100, step: 0.05 },
  { p: 'hype.perFollow', l: '% mỗi follow', t: 'num', min: 0, max: 100, step: 0.5 },
  { p: 'hype.perShare', l: '% mỗi share', t: 'num', min: 0, max: 100, step: 0.5 },
  { p: 'hype.perDiamond', l: '% mỗi kim cương (quà không có luật riêng)', t: 'num', min: 0, max: 100, step: 0.1 },
  { p: 'hype.perComment', l: '% mỗi comment', t: 'num', min: 0, max: 100, step: 0.05 },
  { p: 'hype.events', l: 'Sự kiện khi đầy (theo thứ tự)', t: 'chips', opts: ['meteor', 'hurricane', 'antigravity', 'earthquake'] },
  { p: 'hype.bossDamage', l: 'Đầy hype lúc đánh boss = trừ máu boss', t: 'num', min: 0, max: 10000 },
];
const COURSE = [
  { h: 'Vật lý' },
  { p: 'course.gravity', l: 'Trọng lực', d: 'cao = bi rơi nhanh, trận ngắn hơn', t: 'range', min: 0.3, max: 2.5, step: 0.05 },
  { p: 'course.shuffle', l: 'Xáo trộn thứ tự đoạn mỗi vòng', t: 'bool' },
  { p: 'course.finalFunnel', l: 'Phễu gom cuối đường', t: 'bool' },
];
const TOWER = [
  { h: 'Tháp nhiều tầng' },
  { p: 'tower.enabled', l: 'Bật chế độ tháp', d: 'tắt = cổ điển: hạ boss rồi về đích', t: 'bool' },
  { p: 'tower.middlePool', l: 'Các tầng giữa có thể xuất hiện', t: 'chips', opts: ['ice', 'fork', 'lava'], labels: o => defaults.texts?.floorNames?.[o] || o },
  { p: 'tower.middleCount', l: 'Số tầng giữa mỗi vòng (bốc ngẫu nhiên)', t: 'num', min: 0, max: 3 },
  { p: 'tower.dragon', l: 'Boss cuối Rồng Lửa', t: 'bool' },
  { p: 'tower.arena', l: 'Chung kết Đấu Trường', t: 'bool' },
  { p: 'tower.transition', l: 'Giới thiệu mỗi tầng (giây)', t: 'num', min: 1, max: 10, step: 0.5 },
  { h: 'Hang Băng' },
  { p: 'floors.ice.length', l: 'Chiều dài (px)', t: 'num', min: 1000, max: 10000, step: 100 },
  { p: 'floors.ice.icicleEvery', l: 'Cột băng rơi mỗi (giây)', d: 'nhỏ = khó hơn', t: 'num', min: 0.2, max: 5, step: 0.1 },
  { p: 'floors.ice.frozenMax', l: 'Bị đóng băng quá (giây) thì vỡ', t: 'num', min: 2, max: 30 },
  { p: 'floors.ice.keywords', l: 'Từ khoá phá băng', t: 'list' },
  { p: 'floors.ice.likesPerThaw', l: 'Số tim để phá 1 viên băng', t: 'num', min: 1, max: 1000 },
  { p: 'floors.ice.tail', l: 'Chờ bi chậm (giây) khi đã về một nửa', t: 'num', min: 3, max: 60 },
  { p: 'floors.ice.max', l: 'Thời gian tối đa', t: 'num', min: 10, max: 300 },
  { h: 'Ngã Ba' },
  { p: 'floors.fork.voteTime', l: 'Thời gian bình chọn (giây)', t: 'num', min: 3, max: 60 },
  { p: 'floors.fork.keywordsLeft', l: 'Từ khoá chọn TRÁI', t: 'list' },
  { p: 'floors.fork.keywordsRight', l: 'Từ khoá chọn PHẢI', t: 'list' },
  { p: 'floors.fork.timeLimit', l: 'Thời gian tối đa sau khi mở', t: 'num', min: 10, max: 300 },
  { p: 'floors.fork.saws', l: 'Số lưỡi cưa ở làn nguy hiểm', t: 'num', min: 0, max: 12 },
  { p: 'floors.fork.sawKillChance', l: 'Tỉ lệ lưỡi cưa loại bi', t: 'range', min: 0, max: 1, step: 0.05 },
  { h: 'Dung Nham Đuổi' },
  { p: 'floors.lava.length', l: 'Chiều dài (px)', t: 'num', min: 1500, max: 12000, step: 100 },
  { p: 'floors.lava.speed', l: 'Tốc độ dung nham (px/giây)', t: 'num', min: 50, max: 1000, step: 10 },
  { p: 'floors.lava.accel', l: 'Tăng tốc mỗi giây', t: 'num', min: 0, max: 100 },
  { p: 'floors.lava.slowPerLike', l: 'Mỗi tim/giây làm chậm', d: '0.008 = 0.8%', t: 'num', min: 0, max: 0.1, step: 0.001 },
  { p: 'floors.lava.slowMax', l: 'Làm chậm tối đa', t: 'range', min: 0, max: 0.9, step: 0.05 },
  { p: 'floors.lava.max', l: 'Thời gian tối đa', t: 'num', min: 10, max: 300 },
  { h: 'Rồng Lửa' },
  { p: 'floors.dragon.hpBase', l: 'Máu cơ bản', t: 'num', min: 1, max: 100000 },
  { p: 'floors.dragon.hpPerPlayer', l: 'Máu thêm mỗi người chơi', t: 'num', min: 0, max: 100, step: 0.1 },
  { p: 'floors.dragon.chatHp', l: 'Máu phe chat', t: 'num', min: 1, max: 10000 },
  { p: 'floors.dragon.shieldClosed', l: 'Khiên đóng (giây)', t: 'num', min: 0.5, max: 20, step: 0.5 },
  { p: 'floors.dragon.shieldOpen', l: 'Khiên mở (giây)', t: 'num', min: 0.5, max: 20, step: 0.5 },
  { p: 'floors.dragon.reflectDamage', l: 'Phản đòn khi đánh lúc khiên đóng', t: 'num', min: 0, max: 100, step: 0.5 },
  { p: 'floors.dragon.sweepEvery', l: 'Phun lửa mỗi (giây)', t: 'num', min: 1, max: 30, step: 0.5 },
  { p: 'floors.dragon.sweepKill', l: 'Mỗi lần phun loại tối đa', t: 'range', min: 0, max: 0.5, step: 0.01 },
  { p: 'floors.dragon.sweepDamage', l: 'Mỗi lần phun trừ máu chat', t: 'num', min: 0, max: 100 },
  { p: 'floors.dragon.max', l: 'Thời gian tối đa', t: 'num', min: 10, max: 300 },
  { h: 'Đấu Trường' },
  { p: 'floors.arena.time', l: 'Thời gian sàn co lại (giây)', t: 'num', min: 5, max: 300 },
  { p: 'floors.arena.startWidth', l: 'Độ rộng sàn ban đầu', t: 'num', min: 300, max: 1000, step: 10 },
  { p: 'floors.arena.minWidth', l: 'Độ rộng sàn nhỏ nhất', t: 'num', min: 60, max: 600, step: 10 },
  { p: 'floors.arena.shoveEvery', l: 'Sóng đẩy mỗi (giây)', t: 'num', min: 0.5, max: 20, step: 0.5 },
  { p: 'floors.arena.shovePower', l: 'Lực sóng đẩy', t: 'num', min: 0, max: 20, step: 0.5 },
  { h: 'Cân bằng & công bằng' },
  { p: 'balance.ghostDamage', l: 'Sát thương của bi đã chết (hồn ma)', t: 'range', min: 0, max: 1, step: 0.05 },
  { p: 'balance.luckyPerFloor', l: 'Bi may mắn mỗi tầng (khiên miễn phí)', d: 'chỉ chọn người chưa tặng quà', t: 'num', min: 0, max: 20 },
  { p: 'balance.catchUp', l: 'Đẩy nhẹ nhóm bi cuối', t: 'range', min: 0, max: 0.3, step: 0.01 },
  { p: 'balance.diminishing', l: 'Hiệu lực quà lặp lại trong 1 tầng', d: 'lần 1, lần 2, lần 3...', t: 'numlist' },
  { p: 'balance.adaptiveBoss', l: 'Boss tự cân bằng theo kết quả', t: 'bool' },
  { p: 'balance.roomEventSeconds', l: 'Thời gian sự kiện cả phòng (giây)', t: 'num', min: 1, max: 30 },
];
const EDGE_VI = { 'vi-VN-HoaiMyNeural': 'Hoài My (nữ)', 'vi-VN-NamMinhNeural': 'Nam Minh (nam)' };
const EDGE_EN = { 'en-US-AvaMultilingualNeural': 'Ava (female)', 'en-US-EmmaMultilingualNeural': 'Emma (female)', 'en-US-JennyNeural': 'Jenny (female)', 'en-US-AriaNeural': 'Aria (female)',
  'en-US-AndrewMultilingualNeural': 'Andrew (male)', 'en-US-BrianMultilingualNeural': 'Brian (male)', 'en-US-GuyNeural': 'Guy (male)', 'en-GB-SoniaNeural': 'Sonia (UK, female)', 'en-GB-RyanNeural': 'Ryan (UK, male)' };
const VOICE = [
  { h: 'Giọng đọc hướng dẫn & bình luận' },
  { p: 'voice.enabled', l: 'Bật giọng đọc', t: 'bool' },
  { p: 'voice.engine', l: 'Loại giọng', d: 'Giọng AI cần mạng; lỗi thì tự chuyển sang giọng Windows', t: 'select', opts: { auto: 'Tự động (AI → Windows)', edge: 'Chỉ giọng AI (Edge)', system: 'Chỉ giọng Windows' } },
  { p: 'voice.edgeVoice.vi', l: 'Giọng AI tiếng Việt', t: 'select', opts: EDGE_VI },
  { p: 'voice.edgeVoice.en', l: 'Giọng AI tiếng Anh', t: 'select', opts: EDGE_EN },
  { p: 'voice.volume', l: 'Âm lượng', t: 'range', min: 0, max: 1, step: 0.05 },
  { p: 'voice.rate', l: 'Tốc độ đọc', t: 'range', min: 0.7, max: 1.5, step: 0.05 },
  { h: 'Đọc những gì' },
  { p: 'voice.guide', l: 'Hướng dẫn cách chơi', d: 'lobby, màn cách chơi, đầu mỗi tầng, nhắc vào vòng mới', t: 'bool' },
  { p: 'voice.commentary', l: 'Bình luận trận đấu', d: 'dẫn đầu, sự kiện hype, máu boss, khiên rồng, đấu trường, nhà vô địch', t: 'bool' },
  { p: 'voice.gifts', l: 'Cảm ơn quà / follow / share', t: 'bool' },
  { p: 'voice.countdown', l: 'Đếm ngược "3, 2, 1, xuất phát"', t: 'bool' },
  { p: 'voice.giftMin', l: 'Chỉ cảm ơn quà từ (💎)', t: 'num', min: 1, max: 10000 },
  { p: 'voice.lobbyGuideEvery', l: 'Nhắc hướng dẫn ở lobby mỗi (giây)', t: 'num', min: 6, max: 120 },
  { p: 'voice.leaderEvery', l: 'Báo người dẫn đầu tối đa mỗi (giây)', t: 'num', min: 3, max: 60 },
  { p: 'voice.maxQueue', l: 'Số câu chờ tối đa', d: 'nhiều sự kiện cùng lúc: câu ít quan trọng sẽ bị bỏ', t: 'num', min: 1, max: 10 },
];
const ACTIONS = { boost: 'Boost', big: 'Bi khổng lồ', shield: 'Khiên', revive: 'Hồi sinh', none: 'Không' };
const ROOMS = { '': '—', goldRain: 'Mưa Vàng', mega: 'Thần Long' };
const SECTION_TYPES = { pegs: 'Cọc tròn', spinners: 'Thanh xoay', bouncers: 'Bệ nhún', slats: 'Thanh nghiêng', hammers: 'Búa đập', seesaw: 'Bập bênh', zigzag: 'Ramp zigzag', funnel: 'Phễu' };

// =====================================================================
//  VẼ FORM
// =====================================================================
function fieldRow(f) {
  const row = el('div', 'field'); row.dataset.path = f.p;
  row.appendChild(el('label', '', `${f.l}${f.d ? `<small>${f.d}</small>` : ''}`));
  const ctl = el('div', 'ctl'); row.appendChild(ctl);
  const v = f.p ? eff(f.p) : undefined;
  if (f.t === 'num') {
    const i = el('input'); i.type = 'number'; i.value = v; i.min = f.min ?? ''; i.max = f.max ?? ''; i.step = f.step || 1;
    i.onchange = () => { let n = Number(i.value); if (Number.isNaN(n)) n = getP(defaults, f.p); setCfg(f.p, n); };
    ctl.appendChild(i);
  } else if (f.t === 'range') {
    const i = el('input'); i.type = 'range'; i.min = f.min; i.max = f.max; i.step = f.step; i.value = v;
    const out = el('span', '', v); out.style.minWidth = '34px';
    i.oninput = () => { out.textContent = i.value; setCfg(f.p, Number(i.value)); };
    ctl.append(i, out);
  } else if (f.t === 'bool') {
    const lb = el('label', 'toggle'); const i = el('input'); i.type = 'checkbox'; i.checked = !!v;
    i.onchange = () => setCfg(f.p, i.checked); lb.append(i, el('span')); ctl.appendChild(lb);
  } else if (f.t === 'list') {
    const i = el('input'); i.type = 'text'; i.value = (v || []).join(', ');
    i.onchange = () => setCfg(f.p, i.value.split(',').map(s => s.trim()).filter(Boolean)); ctl.appendChild(i);
  } else if (f.t === 'presets') {
    const P = {
      'Nhanh': { 'timing.lobby': 25, 'guide.slideSeconds': 5, 'timing.startCountdown': 6, 'tower.transition': 5, 'timing.clear': 2.5, 'timing.result': 8 },
      'Vừa': { 'timing.lobby': 45, 'guide.slideSeconds': 8, 'timing.startCountdown': 10, 'tower.transition': 9, 'timing.clear': 4, 'timing.result': 12 },
      'Chậm': { 'timing.lobby': 60, 'guide.slideSeconds': 11, 'timing.startCountdown': 14, 'tower.transition': 13, 'timing.clear': 6, 'timing.result': 16 },
    };
    for (const [name, vals] of Object.entries(P)) {
      const b = el('button', 'small', tr(name));
      b.onclick = () => { for (const [k, v] of Object.entries(vals)) setCfg(k, v); renderForms(); toast(tr('Đã áp dụng') + ': ' + tr(name)); };
      ctl.appendChild(b);
    }
  } else if (f.t === 'numlist') {
    const i = el('input'); i.type = 'text'; i.value = (v || []).join(', ');
    i.onchange = () => { const a = i.value.split(',').map(s => Number(s.trim())).filter(n => !Number.isNaN(n)); setCfg(f.p, a.length ? a : getP(defaults, f.p)); }; ctl.appendChild(i);
  } else if (f.t === 'select') {
    const sel = el('select'); for (const [k, l] of Object.entries(f.opts)) { const o = el('option', '', l); o.value = k; sel.appendChild(o); } sel.value = v;
    sel.onchange = () => setCfg(f.p, sel.value); ctl.appendChild(sel);
  } else if (f.t === 'text') {
    const i = el('input'); i.type = 'text'; i.value = v ?? ''; i.placeholder = getP(defaults, f.p) ?? '';
    i.oninput = () => setCfg(f.p, i.value === '' ? getP(defaults, f.p) : i.value); ctl.appendChild(i);
  } else if (f.t === 'chips') {
    row.classList.add('wide'); const box = el('div', 'chips');
    const cur = new Set(v || []);
    for (const o of f.opts) {
      const c = el('span', 'chip' + (cur.has(o) ? ' on' : ''), f.labels ? f.labels(o) : (defaults.texts?.events?.[o] || o));
      c.onclick = () => { cur.has(o) ? cur.delete(o) : cur.add(o); c.classList.toggle('on'); setCfg(f.p, f.opts.filter(x => cur.has(x))); };
      box.appendChild(c);
    }
    ctl.appendChild(box);
  }
  row.classList.toggle('changed', !!f.p && hasP(overrides, f.p));
  return row;
}
function renderSchema(container, schema) {
  container.innerHTML = ''; let card = null;
  for (const f of schema) {
    if (f.h) { card = el('div', 'card'); card.appendChild(el('h3', '', f.h)); container.appendChild(card); continue; }
    card.appendChild(fieldRow(f));
  }
  return container;
}

function renderGifts() {
  const c = $('#tab-gifts'); c.innerHTML = '';
  renderSchema(c, [
    { h: 'Bảng quà nổi trên game' },
    { p: 'guide.giftWidget.enabled', l: 'Hiện bảng quà ở mọi màn', d: 'danh sách dọc, lấy từ các mức quà bên dưới', t: 'bool' },
    { p: 'guide.giftWidget.edit', l: 'Chế độ chỉnh vị trí / kích thước', d: 'bật rồi kéo bảng trên cửa sổ game; kéo góc vàng để đổi cỡ — NHỚ TẮT KHI LIVE', t: 'bool' },
    { p: 'guide.giftWidget.opacity', l: 'Độ đậm', t: 'range', min: 0.3, max: 1, step: 0.05 },
    { p: 'guide.giftWidget.showDesc', l: 'Hiện mô tả tác dụng', t: 'bool' },
    { p: 'guide.giftWidget.showRoom', l: 'Hiện hiệu ứng cả phòng', t: 'bool' },
  ]);
  { const card0 = c.lastElementChild; const b = el('button', 'small', '↺ Đặt lại vị trí bảng quà'); b.onclick = () => api.call('command', 'resetGiftWidget'); card0.appendChild(b); }
  renderSchema(c.appendChild(el('div')), [{ h: 'Chung' }, { p: 'gifts.multiplyByCount', l: 'Nhân theo số lượng combo (x10 → sát thương x10)', t: 'bool' }]);

  // --- Bậc theo kim cương ---
  const card = el('div', 'card');
  card.innerHTML = '<h3>Theo số kim cương</h3><p class="hint">Quà không có luật theo tên sẽ lấy bậc cao nhất đạt được. <b>Bản thân</b>: tác dụng lên bi người tặng (Hồi sinh: dùng khi bi đã chết, 1 lần/vòng). <b>Cả phòng</b>: Mưa Vàng = mọi bi có khiên vàng, phá băng, đóng băng dung nham · Thần Long = bỏ qua tầng hoặc boss mất 20% máu. <b>Phiếu</b>: sức nặng khi bình chọn ở Ngã Ba.</p>';
  const tb = el('div', 'gift-list');
  const tiers = clone(eff('gifts.tiers') || []);
  const saveTiers = () => setCfg('gifts.tiers', tiers.slice().sort((a, b) => a.minDiamonds - b.minDiamonds));
  tiers.forEach((t, i) => tb.appendChild(giftRow(t, () => saveTiers(), () => { tiers.splice(i, 1); saveTiers(); renderGifts(); }, 'minDiamonds')));
  card.appendChild(tb);
  const add = el('button', 'small', '+ Thêm bậc'); add.onclick = () => { tiers.push({ minDiamonds: 1, icon: '🎁', action: 'boost', room: '', bossDamage: 5, hype: 5, voteWeight: 1 }); saveTiers(); renderGifts(); };
  card.appendChild(add); c.appendChild(card);

  // --- Theo tên quà ---
  const card2 = el('div', 'card');
  card2.innerHTML = '<h3>Theo tên quà</h3><p class="hint">Gõ đúng tên quà tiếng Anh như TikTok gửi về (xem trong Nhật ký khi có người tặng), ví dụ <code>Rose</code>, <code>Finger Heart</code>.</p>';
  const tb2 = el('div', 'gift-list');
  const byName = clone(eff('gifts.byName') || {}); delete byName.__replace;
  const rows = Object.entries(byName).map(([name, r]) => ({ name, ...r }));
  const saveNames = () => { const o = { __replace: true }; rows.forEach(r => { if (r.name) o[r.name] = { icon: r.icon || '', action: r.action, room: r.room || '', bossDamage: r.bossDamage, hype: r.hype, voteWeight: r.voteWeight ?? 1 }; }); setCfg('gifts.byName', o); };
  rows.forEach((r, i) => tb2.appendChild(giftRow(r, saveNames, () => { rows.splice(i, 1); saveNames(); renderGifts(); }, 'name')));
  card2.appendChild(tb2);
  const add2 = el('button', 'small', '+ Thêm quà'); add2.onclick = () => { rows.push({ name: 'Ten Qua', icon: '🎁', action: 'boost', room: '', bossDamage: 5, hype: 5, voteWeight: 1 }); saveNames(); renderGifts(); };
  card2.appendChild(add2); c.appendChild(card2);
}
const isImgIcon = v => /^(https?:|file:|data:image|assets\/|\.?\/)|\.(png|jpe?g|webp|gif|svg)(\?.*)?$/i.test(String(v || '').trim());
function iconPreview(box, v) {
  box.innerHTML = '';
  if (!v) { box.textContent = '💎'; box.classList.add('empty'); return; }
  box.classList.remove('empty');
  if (isImgIcon(v)) { const im = el('img'); im.src = v; im.referrerPolicy = 'no-referrer'; box.appendChild(im); } else box.textContent = v;
}
function giftRow(obj, save, remove, keyField) {
  const card = el('div', 'gift-card');
  // dòng 1: icon + khoá
  const r1 = el('div', 'gc-row');
  const pv = el('div', 'gc-icon'); iconPreview(pv, obj.icon);
  const ic = el('input'); ic.type = 'text'; ic.className = 'gc-icon-input'; ic.value = isImgIcon(obj.icon) ? decodeURIComponent(String(obj.icon).split('/').pop()) : (obj.icon || ''); ic.placeholder = tr('emoji hoặc ảnh');
  ic.onchange = () => { obj.icon = ic.value.trim(); iconPreview(pv, obj.icon); save(); };
  const pick = el('button', 'small', '📁'); pick.title = tr('Chọn ảnh icon');
  pick.onclick = async () => { const u = await api.call('pickFile', 'image'); if (u) { obj.icon = u; ic.value = decodeURIComponent(u.split('/').pop()); iconPreview(pv, u); save(); } };
  const lbl = el('span', 'gc-lbl', keyField === 'name' ? tr('Tên quà') : tr('Từ 💎'));
  const k = el('input'); k.type = keyField === 'name' ? 'text' : 'number'; k.value = obj[keyField]; k.className = 'gc-key';
  k.onchange = () => { obj[keyField] = keyField === 'name' ? k.value.trim() : Number(k.value); save(); };
  const x = el('button', 'small', '✕'); x.title = tr('Xoá'); x.onclick = remove;
  r1.append(pv, ic, pick, lbl, k, x);
  // dòng 2: tác dụng
  const r2 = el('div', 'gc-row gc-grid');
  const field = (label, node) => { const w = el('label', 'gc-f'); w.appendChild(el('span', '', tr(label))); w.appendChild(node); return w; };
  const a = el('select'); for (const [v, l] of Object.entries(ACTIONS)) { const o = el('option', '', tr(l)); o.value = v; a.appendChild(o); } a.value = obj.action || 'none';
  a.onchange = () => { obj.action = a.value; save(); };
  const rm = el('select'); for (const [v, l] of Object.entries(ROOMS)) { const o = el('option', '', tr(l)); o.value = v; rm.appendChild(o); } rm.value = obj.room || '';
  rm.onchange = () => { obj.room = rm.value; save(); };
  const num = (key) => { const i = el('input'); i.type = 'number'; i.value = obj[key] ?? 0; i.onchange = () => { obj[key] = Number(i.value); save(); }; return i; };
  r2.append(field('Bản thân', a), field('Cả phòng', rm), field('Sát thương boss', num('bossDamage')), field('% Hype', num('hype')), field('Phiếu', num('voteWeight')));
  card.append(r1, r2);
  return card;
}

function renderCourse() {
  const c = $('#tab-course'); renderSchema(c, COURSE);
  const card = el('div', 'card');
  card.innerHTML = '<h3>Các đoạn đường đua (từ trên xuống)</h3><p class="hint">Áp dụng từ vòng sau. Chiều cao tính theo px trên khung 1080×1920 (1 màn hình ≈ 1900px).</p>';
  const secs = clone(eff('course.sections') || []);
  const save = () => setCfg('course.sections', secs);
  const tb = el('table'); tb.innerHTML = '<tr><th>Loại</th><th>Chiều cao</th><th></th></tr>';
  secs.forEach((s, i) => {
    const trow = el('tr');
    const sel = el('select'); for (const [v, l] of Object.entries(SECTION_TYPES)) { const o = el('option', '', tr(l)); o.value = v; sel.appendChild(o); } sel.value = s.type;
    sel.onchange = () => { s.type = sel.value; save(); };
    const hh = el('input'); hh.type = 'number'; hh.step = 100; hh.min = 300; hh.value = s.height; hh.onchange = () => { s.height = Number(hh.value); save(); };
    const btns = el('div', 'row'); btns.style.margin = 0;
    const up = el('button', 'small', '↑'); up.onclick = () => { if (i > 0) { [secs[i - 1], secs[i]] = [secs[i], secs[i - 1]]; save(); renderCourse(); } };
    const dn = el('button', 'small', '↓'); dn.onclick = () => { if (i < secs.length - 1) { [secs[i + 1], secs[i]] = [secs[i], secs[i + 1]]; save(); renderCourse(); } };
    const x = el('button', 'small', '✕'); x.onclick = () => { secs.splice(i, 1); save(); renderCourse(); };
    btns.append(up, dn, x);
    for (const n of [sel, hh, btns]) { const td = el('td'); td.appendChild(n); trow.appendChild(td); }
    tb.appendChild(trow);
  });
  card.appendChild(tb);
  const add = el('button', 'small', '+ Thêm đoạn'); add.onclick = () => { secs.push({ type: 'pegs', height: 1200 }); save(); renderCourse(); };
  const total = secs.reduce((a, s) => a + (s.height || 0), 0);
  card.append(add, el('div', 'sub', `${tr('Tổng chiều dài')} ≈ ${total}px (~${(total / 1900).toFixed(1)} ${tr('màn hình')})`));
  c.appendChild(card);
}

function renderTexts() {
  const schema = [{ h: 'Ngôn ngữ game' }, { p: 'language', l: 'Ngôn ngữ hiển thị trên game', t: 'select', opts: { vi: 'Tiếng Việt', en: 'English' } },
    { h: 'Chữ hiển thị trên game' }];
  const walk = (o, pre) => { for (const [k, v] of Object.entries(o)) { if (v && typeof v === 'object') walk(v, pre + k + '.'); else schema.push({ p: 'texts.' + pre + k, l: pre + k, t: 'text' }); } };
  walk(defaults.texts || {}, '');
  renderSchema($('#tab-texts'), schema);
}

const THEME_GROUPS = [
  ['Chung', { font: 'Font chữ', primary: 'Màu chủ đạo', 'primary-dark': 'Chủ đạo (đậm)', accent: 'Thanh hype', 'accent-2': 'Vàng nhấn / số đếm', good: 'Phe chat (xanh)', panel: 'Nền bảng', 'panel-text': 'Chữ trên bảng', radius: 'Bo góc', 'hud-top': 'Chừa phía trên (thanh TikTok)' }],
  ['Khu đua', { bg: 'Nền', 'bg-dots': 'Chấm nền', wall: 'Tường', 'wall-edge': 'Viền tường', peg: 'Cọc', 'peg-edge': 'Viền cọc', spinner: 'Thanh xoay', 'spinner-hub': 'Trục xoay', bouncer: 'Bệ nhún', slat: 'Thanh nghiêng', hammer: 'Búa', seesaw: 'Bập bênh', ramp: 'Ramp', 'ramp-edge': 'Viền ramp', funnel: 'Phễu', wood: 'Thanh gỗ' }],
  ['Khu boss', { 'boss-bg': 'Nền dưới', 'boss-bg-2': 'Nền trên', 'boss-color': 'Thân boss', 'boss-barrier': 'Cổng chặn', laser: 'Laser', 'bonk-shot': 'Đạn bonk', finish: 'Vạch đích' }],
  ['Các tầng', { 'ice-bg': 'Nền Hang Băng', ice: 'Băng', lava: 'Dung nham', 'lava-glow': 'Viền dung nham', saw: 'Lưỡi cưa', 'dragon-bg': 'Nền khu Rồng', 'dragon-color': 'Thân Rồng', 'dragon-shield': 'Khiên Rồng', 'arena-bg': 'Nền Đấu Trường', 'arena-floor': 'Sàn Đấu Trường' }],
  ['Bi', { 'ball-border': 'Viền bi', 'ball-shield': 'Khiên', 'ball-boost': 'Boost', 'name-color': 'Màu tên', 'name-stroke': 'Viền tên', 'name-size': 'Cỡ tên' }],
];
function renderLook() {
  const c = $('#tab-look'); c.innerHTML = '';
  if (!themeDef) { c.innerHTML = '<div class="card">Đang chờ cửa sổ game...</div>'; return; }
  for (const [title, vars] of THEME_GROUPS) {
    const card = el('div', 'card'); card.appendChild(el('h3', '', title));
    for (const [name, label] of Object.entries(vars)) {
      const row = el('div', 'field'); row.dataset.theme = name;
      row.appendChild(el('label', '', label + `<small>--${name}</small>`));
      const ctl = el('div', 'ctl'); row.appendChild(ctl);
      const val = themeOv[name] || themeDef[name] || '';
      const txt = el('input'); txt.type = 'text'; txt.value = val; txt.placeholder = themeDef[name] || '';
      if (/^#([0-9a-f]{3}){1,2}$/i.test(themeDef[name] || '')) {
        const col = el('input'); col.type = 'color'; col.value = /^#[0-9a-f]{6}$/i.test(val) ? val : '#000000';
        col.oninput = () => { txt.value = col.value; setTheme(name, col.value); };
        txt.onchange = () => { if (/^#[0-9a-f]{6}$/i.test(txt.value)) col.value = txt.value; setTheme(name, txt.value.trim()); };
        ctl.append(col, txt);
      } else {
        txt.onchange = () => setTheme(name, txt.value.trim());
        ctl.appendChild(txt);
      }
      row.classList.toggle('changed', name in themeOv);
      card.appendChild(row);
    }
    c.appendChild(card);
  }
  // Ảnh & âm thanh
  const assets = el('div', 'card'); assets.appendChild(el('h3', '', 'Hình ảnh'));
  for (const [k, l] of Object.entries({ background: 'Nền khu đua (rộng 1080)', bossBackground: 'Nền khu boss', boss: 'Ảnh boss Quỷ Đỏ (PNG vuông, nền trong)', dragon: 'Ảnh Rồng (PNG vuông, nền trong)', logo: 'Logo' })) assets.appendChild(assetRow('assets.' + k, l, 'image'));
  c.appendChild(assets);
  const snd = el('div', 'card'); snd.appendChild(el('h3', '', 'Âm thanh'));
  snd.appendChild(fieldRow({ p: 'sounds.volume', l: 'Âm lượng', t: 'range', min: 0, max: 1, step: 0.05 }));
  for (const [k, l] of Object.entries({ start: 'Bắt đầu đua', join: 'Có người vào', hype: 'Kích hoạt hype', bonk: 'Bonk trúng boss', bossHit: 'Boss đánh', win: 'Chiến thắng', lose: 'Boss thắng' })) snd.appendChild(assetRow('sounds.' + k, l, 'sound'));
  c.appendChild(snd);
}
function assetRow(p, label, kind) {
  const row = el('div', 'field'); row.dataset.path = p;
  row.appendChild(el('label', '', label));
  const ctl = el('div', 'ctl'); row.appendChild(ctl);
  const name = el('span', 'asset-name', decodeURIComponent((eff(p) || '— mặc định —').split('/').pop()));
  const pickB = el('button', 'small', 'Chọn'); pickB.onclick = async () => { const u = await api.call('pickFile', kind); if (u) { setCfg(p, u); name.textContent = decodeURIComponent(u.split('/').pop()); } };
  const clr = el('button', 'small', '✕'); clr.onclick = () => { setCfg(p, ''); name.textContent = '— mặc định —'; };
  ctl.append(name, pickB, clr);
  row.classList.toggle('changed', hasP(overrides, p));
  return row;
}

function renderForms() {
  if (!defaults) return;
  renderSchema($('#tab-rules'), RULES);
  renderSchema($('#tab-boss'), BOSS);
  renderSchema($('#tab-tower'), TOWER);
  { const vc = renderSchema($('#tab-voice'), VOICE); const card = vc.firstElementChild;
    const row = el('div', 'row wrap'); row.style.marginTop = '8px';
    const t = el('button', 'primary', '🔊 Nghe thử'); t.onclick = () => api.call('command', 'voiceTest');
    const st = el('button', '', '⏹ Dừng đọc'); st.onclick = () => api.call('command', 'voiceStop');
    row.append(t, st); card.appendChild(row);
    card.appendChild(el('div', 'sub', tr('Câu chữ của giọng đọc sửa ở tab Chữ (mục voice.*). Mỗi câu có thể có nhiều cách nói, cách nhau bằng dấu |')));
    card.appendChild(el('div', 'sub', '', '')).id = 'voiceState'; }
  renderGifts(); renderCourse(); renderTexts(); renderLook();
  translateDom(document.querySelector('main'));
}

// =====================================================================
//  ĐIỀU KHIỂN
// =====================================================================
const PHASES = { lobby: 'Chờ người', start: 'Đếm ngược', race: 'Đang đua', boss: 'Đánh Quỷ', finish: 'Về đích', bossWin: 'Boss thắng', result: 'Kết quả', clear: 'Qua tầng', transition: 'Lên tầng', ice: 'Hang Băng', fork: 'Ngã Ba', lava: 'Dung Nham', dragon: 'Đánh Rồng', arena: 'Đấu Trường' };
let lastState = {};
function showState(s) {
  if (!s || !s.phase) return;
  lastState = s;
  $('#stPhase').textContent = tr(PHASES[s.phase] || s.phase);
  $('#stPlayers').textContent = s.players; $('#stAlive').textContent = s.alive;
  $('#stTime').textContent = ['lobby', 'start', 'result'].includes(s.phase) ? s.timeLeft : s.raceTime;
  $('#stHype').style.width = s.hype + '%'; $('#stHypeTxt').textContent = s.hype + '%';
  const B = s.boss;
  $('#bossMeter').style.opacity = $('#chatMeter').style.opacity = B ? 1 : .35;
  $('#stBoss').style.width = B ? (B.hp / B.max * 100) + '%' : 0; $('#stBossTxt').textContent = B ? `${B.hp}/${B.max}` : '-';
  $('#stChat').style.width = B ? B.chat + '%' : 0; $('#stChatTxt').textContent = B ? B.chat : '-';
  const vs = $('#voiceState'); if (vs) vs.textContent = `${tr('Đang dùng')}: ${tr(({ edge: 'Giọng AI (Edge)', system: 'Giọng Windows', none: 'Chưa có giọng phù hợp', off: 'Đã tắt' })[s.voice] || '—')}${s.voiceBusy ? ' · 🔊' : ''}`;
  $('#stExtra').textContent = `${s.floors ? `${tr('Tầng')} ${s.floor}/${s.floors} · ${tr('Kỷ lục')} ${s.bestFloor} · ` : ''}${tr('Chờ vòng sau')}: ${s.queue} · Champion: ${s.champion ? '@' + s.champion : '—'} · ${s.fps} FPS`;
}
function showStatus(st) { lastStatus = st; $('#dot').className = 'dot ' + (st.state || ''); $('#statusText').textContent = trDyn(st.text); $('#statusText').title = trDyn(st.text); }
let lastStatus = {};
function addLog(line) { const l = $('#log'); l.textContent += line.replace(/^(\S+\s+)(.*)$/, (m, a, b) => a + trDyn(b)) + '\n'; if (l.textContent.length > 20000) l.textContent = l.textContent.slice(-15000); l.scrollTop = l.scrollHeight; }
function showUpdate(u) {
  const b = $('#upStatus'); b.textContent = trDyn(u.message || u.status);
  b.className = 'status-box ' + (u.status === 'error' ? 'error' : (u.status === 'applied' ? 'ok' : ''));
  $('#upApply').disabled = !u.pending;
  const A = u.app || {};
  const ab = $('#appStatus');
  ab.textContent = A.status && A.status !== 'none' ? trDyn(A.message || A.status) : `${tr('App đang chạy')}: ${ALL.appVersion || '?'} — ${tr('mới nhất')}`;
  ab.className = 'status-box ' + (A.status === 'error' ? 'error' : A.status === 'ready' ? 'ok' : '');
  $('#appMeter').style.display = A.status === 'downloading' ? '' : 'none';
  $('#appBar').style.width = (A.progress || 0) + '%'; $('#appPct').textContent = (A.progress || 0) + '%';
  $('#appInstall').style.display = A.status === 'ready' ? '' : 'none';
  $('#appOpen').style.display = A.status === 'manual' && A.url ? '' : 'none';
  $('#upInfo').textContent = `${tr('Game đang chạy')}: ${ALL.gameVersion || '?'}${u.remoteVersion ? ` · ${tr('Trên mạng')}: ` + u.remoteVersion : ''}${u.lastCheck ? ` · ${tr('Kiểm tra lúc')} ` + new Date(u.lastCheck).toLocaleTimeString() : ''}${u.notes ? `\n${tr('Ghi chú')}: ` + u.notes : ''}`;
}
function fillSettings() {
  $('#ttUser').value = settings.tiktokUsername || '';
  $('#autoConnect').checked = !!settings.autoConnect;
  $('#alwaysOnTop').checked = !!settings.window?.alwaysOnTop;
  $('#frameless').checked = !!settings.window?.frameless;
  $('#upUrl').value = settings.update?.url || '';
  $('#upInterval').value = settings.update?.intervalMin || 5;
  $('#upAuto').checked = !!settings.update?.autoApply;
  $('#upRemoteCfg').checked = !!settings.update?.acceptRemoteConfig;
  $('#upAutoApp').checked = settings.update?.autoAppUpdate !== false;
  $('#signKey').value = settings.signApiKey || '';
  $('#hwAccel').checked = settings.hardwareAcceleration !== false;
  $('#gameSize').textContent = `${tr('Hiện tại')}: ${settings.window?.gameWidth || 540} × ${Math.round((settings.window?.gameWidth || 540) * 16 / 9)}`;
}

// sự kiện nút
document.querySelectorAll('[data-cmd]').forEach(b => b.onclick = () => api.call('command', b.dataset.cmd, b.dataset.args ? JSON.parse(b.dataset.args) : []));
$('#autoBots').onchange = e => api.call('command', 'autoBots', [e.target.checked]);
$('#btnConnect').onclick = async () => { settings = await api.call('setSettings', { tiktokUsername: $('#ttUser').value.replace(/^@/, '').trim() }); api.call('connect'); };
$('#btnDisconnect').onclick = () => api.call('disconnect');
$('#ttUser').onkeydown = e => { if (e.key === 'Enter') $('#btnConnect').click(); };
$('#autoConnect').onchange = e => api.call('setSettings', { autoConnect: e.target.checked });
document.querySelectorAll('[data-size]').forEach(b => b.onclick = async () => { const r = await api.call('setGameSize', Number(b.dataset.size)); settings.window.gameWidth = Number(b.dataset.size); $('#gameSize').textContent = `${tr('Hiện tại')}: ${r.width} × ${r.height}${r.width < Number(b.dataset.size) ? tr(' (màn hình không đủ chỗ)') : ''}`; });
$('#alwaysOnTop').onchange = e => api.call('setAlwaysOnTop', e.target.checked);
$('#frameless').onchange = e => api.call('setFrameless', e.target.checked);
$('#btnShowGame').onclick = () => api.call('showGame');
$('#btnJump').onclick = () => api.call('command', 'jump', [$('#jumpFloor').value]);
document.querySelectorAll('[data-plang]').forEach(b => b.onclick = () => {
  setPanelLang(b.dataset.plang); api.call('setSettings', { panelLang: PANEL_LANG });
  document.querySelectorAll('[data-plang]').forEach(x => x.classList.toggle('on', x.dataset.plang === PANEL_LANG));
  renderForms(); showState(lastState); showUpdate(ALL.update || {}); fillSettings(); showStatus(lastStatus);
});
$('#btnReload').onclick = () => api.call('reloadGame');
// cập nhật
const saveUpdate = () => api.call('setSettings', { update: { url: $('#upUrl').value.trim(), intervalMin: Number($('#upInterval').value) || 5, autoApply: $('#upAuto').checked, acceptRemoteConfig: $('#upRemoteCfg').checked } });
['#upUrl', '#upInterval', '#upAuto', '#upRemoteCfg'].forEach(s => $(s).onchange = saveUpdate);
$('#upCheck').onclick = async () => { await saveUpdate(); showUpdate(await api.call('checkUpdate')); };
$('#upApply').onclick = () => api.call('applyUpdate');
$('#upAutoApp').onchange = e => api.call('setSettings', { update: { autoAppUpdate: e.target.checked } });
$('#appInstall').onclick = () => { if (confirm(tr('Cài app mới và khởi động lại ngay?'))) api.call('installApp'); };
$('#appOpen').onclick = () => { const u = (ALL.update || {}).app?.url; if (u) api.call('openUrl', u); };
$('#upRollback').onclick = () => { if (confirm(tr('Quay về bản game gốc đi kèm app?'))) api.call('rollback'); };
// cài đặt
$('#signKey').onchange = e => api.call('setSettings', { signApiKey: e.target.value.trim() });
$('#hwAccel').onchange = e => { api.call('setSettings', { hardwareAcceleration: e.target.checked }); toast('Khởi động lại app để áp dụng'); };
$('#btnRestart').onclick = () => api.call('restartApp');
$('#btnExport').onclick = async () => { if (await api.call('exportSettings')) toast('Đã xuất file'); };
$('#btnImport').onclick = async () => { if (await api.call('importSettings')) { const a = await api.call('getAll'); overrides = clone(a.settings.config) || {}; themeOv = clone(a.settings.theme) || {}; renderForms(); toast('Đã nhập thông số'); } };
$('#btnFolder').onclick = () => api.call('openFolder');
$('#btnResetWins').onclick = () => { if (confirm(tr('Xoá toàn bộ số trận thắng và champion?'))) { api.call('command', 'resetWins'); toast('Đã xoá'); } };
$('#btnResetAll').onclick = () => { if (confirm(tr('Đưa MỌI thông số và màu về mặc định?'))) { overrides = {}; themeOv = {}; api.call('resetAll'); renderForms(); toast('Đã khôi phục mặc định'); } };

// =====================================================================
//  KHỞI ĐỘNG
// =====================================================================
api.on('state', showState);
api.on('status', showStatus);
api.on('log', addLog);
api.on('event', addLog);
api.on('update', u => { ALL.update = u; showUpdate(u); });
api.on('version', v => { ALL.gameVersion = v; $('#ver').textContent = `app ${ALL.appVersion} · game ${v}`; showUpdate(ALL.update || {}); });
api.on('config-defaults', d => { defaults = d; renderForms(); });
api.on('theme-defaults', d => { themeDef = d; renderLook(); });
api.on('settings', s => { settings = s; overrides = clone(s.config) || {}; themeOv = clone(s.theme) || {}; fillSettings(); renderForms(); toast('Đã nhận thông số từ xa'); });

(async () => {
  ALL = await api.call('getAll');
  settings = ALL.settings; overrides = clone(settings.config) || {}; themeOv = clone(settings.theme) || {};
  if (ALL.configDefaults && Object.keys(ALL.configDefaults).length) defaults = ALL.configDefaults;
  if (ALL.themeDefaults && Object.keys(ALL.themeDefaults).length) themeDef = ALL.themeDefaults;
  $('#ver').textContent = `app ${ALL.appVersion} · game ${ALL.gameVersion}`;
  setPanelLang(settings.panelLang || 'vi');
  document.querySelectorAll('[data-plang]').forEach(x => x.classList.toggle('on', x.dataset.plang === PANEL_LANG));
  fillSettings(); showStatus(ALL.status); showState(ALL.gameState); showUpdate(ALL.update);
  (ALL.logs || []).forEach(addLog);
  renderForms();
})();
