// =====================================================================
//  Marble Live — lõi game (vật lý, tháp nhiều tầng, vẽ)
//  Luật chơi ở config.js · Chữ ở texts.js · Giao diện ở theme.css
// =====================================================================
(() => {
'use strict';
const C = window.GAME_CONFIG;
const APP = window.marble || null;   // cầu nối với app desktop (preload)
const clone = o => JSON.parse(JSON.stringify(o ?? null));
function deepMerge(dst, src) {
  for (const k in src) {
    const v = src[k];
    if (v && typeof v === 'object' && !Array.isArray(v) && !v.__replace) { if (!dst[k] || typeof dst[k] !== 'object' || Array.isArray(dst[k])) dst[k] = {}; deepMerge(dst[k], v); }
    else if (v && v.__replace) { const c = { ...v }; delete c.__replace; dst[k] = c; }
    else dst[k] = v;
  }
  return dst;
}
const DEFAULT_CONFIG = clone(C);
if (APP) {
  const init = APP.init();
  if (init.config) deepMerge(C, init.config);
  if (init.theme) for (const [k, v] of Object.entries(init.theme)) if (v) document.documentElement.style.setProperty('--' + k, v);
}
const W = 1080, H = 1920, WALL = 40;
const L = WALL, Rr = W - WALL, IW = Rr - L;
const { Engine, Bodies, Body, Composite, Events } = Matter;
const $ = s => document.querySelector(s);
const TEST = /[?&]test\b/.test(location.search);
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const shuffle = arr => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ---------------- Khung hình co giãn ----------------
const wrap = $('#wrap');
function fit() { const s = Math.min(innerWidth / W, innerHeight / H); wrap.style.transform = `translate(${-W * s / 2}px, ${-H * s / 2}px) scale(${s})`; }
addEventListener('resize', fit); fit();

// ---------------- Màu (theme.css) ----------------
const THEME_VARS = ['font','primary','primary-dark','accent','accent-2','good','panel','panel-text','bg','bg-dots','wall','wall-edge','peg','peg-edge',
  'spinner','spinner-hub','bouncer','slat','hammer','seesaw','ramp','ramp-edge','funnel','wood','boss-bg','boss-bg-2','boss-color','boss-barrier',
  'laser','bonk-shot','finish','ice-bg','ice','lava','lava-glow','saw','dragon-bg','dragon-color','dragon-shield','arena-bg','arena-floor',
  'ball-border','ball-shield','ball-boost','name-color','name-stroke','name-size','radius','hud-top'];
const COL = {};
function loadColors() { const cs = getComputedStyle(document.documentElement); for (const n of THEME_VARS) COL[n] = cs.getPropertyValue('--' + n).trim(); }
loadColors();

// ---------------- Ngôn ngữ ----------------
const T = {};
function langPack(lang) { const P = window.GAME_TEXTS || {}; return clone(P[lang] || P.vi || {}); }
function buildTexts() { for (const k of Object.keys(T)) delete T[k]; deepMerge(T, langPack(C.language)); deepMerge(T, C.texts || {}); }
buildTexts();
function applyTexts() {
  document.querySelectorAll('[data-t]').forEach(el => el.textContent = T[el.dataset.t] ?? '');
  $('#lobby .l-title').textContent = T.lobbyTitle;
  $('#lobby .l-sub').textContent = T.lobbySub;
  $('#howto h2').textContent = T.howTitle;
  $('#howto p').textContent = T.howSub;
  document.documentElement.lang = C.language || 'vi';
}
applyTexts();

// ---------------- Lưu trữ ----------------
const store = {
  get(k, d) { try { const v = localStorage.getItem('marble.' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('marble.' + k, JSON.stringify(v)); } catch {} },
};
let wins = store.get('wins', {});
let champion = store.get('champion', null);
let bestFloor = store.get('bestFloor', 0);
let difficulty = store.get('difficulty', { demon: 1, dragon: 1 });

// ---------------- Ảnh & âm thanh ----------------
function loadImg(src) { if (!src) return null; const img = new Image(); img.src = src; img.onerror = () => { img._bad = true; }; return img; }
const IMG = {};
function loadAssets() {
  const A = C.assets || {};
  IMG.bg = loadImg(A.background); IMG.bossBg = loadImg(A.bossBackground); IMG.boss = loadImg(A.boss); IMG.dragon = loadImg(A.dragon);
  if (A.logo) { $('#logo').src = A.logo; $('#logo').classList.remove('hidden'); } else $('#logo').classList.add('hidden');
}
loadAssets();
const imgOk = i => i && i.complete && i.naturalWidth > 0 && !i._bad;
const SND = {};
function loadSounds() {
  for (const k in SND) delete SND[k];
  for (const [k, v] of Object.entries(C.sounds || {})) if (v && k !== 'volume') { SND[k] = new Audio(v); SND[k].volume = C.sounds.volume ?? 0.6; }
}
loadSounds();
function play(k) { const a = SND[k]; if (!a) return; try { const c = a.cloneNode(); c.volume = a.volume; c.play().catch(() => {}); } catch {} }

// ---------------- Avatar ----------------
const avatarImgs = new Map();
function hue(str) { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619) >>> 0; return h % 360; }
function fallbackColor(name) { return `hsl(${hue(name || '?')},65%,55%)`; }
function makeSprite(p) {
  const S = 72, cv = document.createElement('canvas'); cv.width = cv.height = S;
  const g = cv.getContext('2d');
  const draw = img => {
    g.clearRect(0, 0, S, S);
    g.save(); g.beginPath(); g.arc(S / 2, S / 2, S / 2 - 3, 0, Math.PI * 2); g.clip();
    if (img) g.drawImage(img, 0, 0, S, S);
    else {
      g.fillStyle = fallbackColor(p.name); g.fillRect(0, 0, S, S);
      g.fillStyle = '#fff'; g.font = `800 34px ${COL.font}`; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText((p.nick || p.name || '?').trim().charAt(0).toUpperCase(), S / 2, S / 2 + 2);
    }
    g.restore();
    g.lineWidth = 4; g.strokeStyle = COL['ball-border']; g.beginPath(); g.arc(S / 2, S / 2, S / 2 - 2.5, 0, Math.PI * 2); g.stroke();
  };
  draw(null);
  if (p.avatar) {
    let img = avatarImgs.get(p.avatar);
    if (!img) { img = new Image(); img.referrerPolicy = 'no-referrer'; img.src = p.avatar; avatarImgs.set(p.avatar, img); }
    if (img.complete && img.naturalWidth) draw(img); else img.addEventListener('load', () => draw(img), { once: true });
  }
  return cv;
}
function avatarEl(user, cls = '') {
  if (user.avatar) { const i = document.createElement('img'); i.src = user.avatar; i.referrerPolicy = 'no-referrer'; i.className = cls; return i; }
  const d = document.createElement('div'); d.className = 'avatar-fallback ' + cls;
  d.style.cssText = `background:${fallbackColor(user.name)};display:grid;place-items:center;color:#fff;font-weight:800;font-size:150%`;
  d.textContent = (user.nick || user.name || '?').charAt(0).toUpperCase(); return d;
}

// =====================================================================
//  VẬT LÝ & XÂY DỰNG CÁC TẦNG
// =====================================================================
const engine = Engine.create();
engine.positionIterations = 8; engine.velocityIterations = 6;
const radius = () => C.players.ballRadius;
const CAT_OBS = 0x0001, CAT_ARENA = 0x0002, CAT_BALL = 0x0004;
const stat = { isStatic: true, friction: 0.02, restitution: 0.4 };
const arenaCat = { category: CAT_ARENA, mask: 0xFFFF };
let bodies = [], kinematic = [], cage = null, geo = {}, simT = 0;

function add(b, kind, color, extra = {}) { Object.assign(b, { kind, color }, extra); Composite.add(engine.world, b); bodies.push(b); return b; }
function removeBody(b) { if (!b) return; Composite.remove(engine.world, b); bodies = bodies.filter(x => x !== b); kinematic = kinematic.filter(x => x !== b); }
function bar(x, y, len, th, angle, kind, color, opts = {}) { return add(Bodies.rectangle(x, y, len, th, { ...stat, angle, chamfer: { radius: th / 2 - 0.5 }, ...opts }), kind, color); }
function peg(x, y, r, color = 'peg') { return add(Bodies.circle(x, y, r, { ...stat, restitution: 0.55 }), 'peg', color); }
function clearWorld() { Composite.clear(engine.world, false); bodies = []; kinematic = []; geo = {}; cage = null; }
function addWalls(totalH, top = -220) {
  add(Bodies.rectangle(WALL / 2, totalH / 2, WALL, totalH + 800, { ...stat, restitution: 0.2, collisionFilter: arenaCat }), 'wall', 'wall');
  add(Bodies.rectangle(W - WALL / 2, totalH / 2, WALL, totalH + 800, { ...stat, restitution: 0.2, collisionFilter: arenaCat }), 'wall', 'wall');
  add(Bodies.rectangle(W / 2, top, W, 40, { ...stat, collisionFilter: arenaCat }), 'wall', 'wall');
  geo.walls = true;
}
function addBucket(exitY) {
  geo.exitY = exitY;
  geo.floorY = exitY + 320;
  add(Bodies.rectangle(W / 2, geo.floorY, W, 60, { ...stat, restitution: 0.1, collisionFilter: arenaCat }), 'floor', 'wood');
  geo.camMax = geo.floorY + 80 - H;
}

// ---- Các đoạn chướng ngại (dùng chung cho nhiều tầng) ----
const SECTIONS = {
  pegs(y0, h, x0 = L, x1 = Rr, color = 'peg') {
    const sx = 120, sy = 115; let row = 0;
    for (let y = y0 + 80; y < y0 + h - 60; y += sy, row++) {
      const off = row % 2 ? sx / 2 : 0;
      for (let x = x0 + 60 + off; x < x1 - 40; x += sx) peg(x, y, 13, color);
    }
    if (x0 === L && x1 === Rr) for (let i = 0; i < 3; i++) bar(i % 2 ? Rr - 90 : L + 90, y0 + rnd(200, h - 200), 200, 18, i % 2 ? -0.5 : 0.5, 'wood', 'wood');
  },
  spinners(y0, h) {
    let row = 0;
    for (let y = y0 + 140; y < y0 + h - 100; y += 270, row++) {
      const n = row % 2 ? 3 : 4, gap = IW / n;
      for (let i = 0; i < n; i++) {
        const b = bar(L + gap * (i + 0.5), y, Math.min(gap * 0.9, 210), 20, rnd(0, 3), 'spinner', 'spinner');
        b.spin = (i + row) % 2 ? 0.035 : -0.035; kinematic.push(b);
      }
    }
  },
  bouncers(y0, h) {
    let row = 0;
    for (let y = y0 + 150; y < y0 + h - 80; y += 230, row++) {
      const n = 2 + (row % 2);
      for (let i = 0; i < n; i++) add(Bodies.rectangle(L + IW * (i + 0.5) / n + rnd(-40, 40), y, 150, 18, { ...stat, restitution: 1.15, chamfer: { radius: 8 }, angle: rnd(-0.15, 0.15) }), 'bouncer', 'bouncer');
      for (let i = 0; i < 4; i++) peg(L + IW * (i + 0.5) / 4 + (row % 2 ? 60 : -60), y + 115, 12);
    }
  },
  slats(y0, h) {
    let row = 0;
    for (let y = y0 + 110; y < y0 + h - 80; y += 150, row++) {
      const off = row % 2 ? 100 : 0;
      for (let x = L + 90 + off; x < Rr - 60; x += 200) bar(x, y, 120, 18, row % 2 ? 0.35 : -0.35, 'slat', 'slat');
    }
  },
  hammers(y0, h) {
    let i = 0;
    for (let y = y0 + 120; y < y0 + h - 300; y += 380, i++) {
      for (const px of (i % 2 ? [L + 260, Rr - 260] : [W / 2])) {
        const arm = Bodies.rectangle(px, y + 140, 22, 280, { chamfer: { radius: 10 } });
        const head = Bodies.rectangle(px, y + 290, 150, 60, { chamfer: { radius: 14 } });
        const b = Body.create({ parts: [arm, head], ...stat, restitution: 0.6 });
        add(b, 'hammer', 'hammer');
        b.pivot = { x: px, y }; b.off0 = { x: b.position.x - px, y: b.position.y - y };
        b.swing = { amp: 1.0, speed: 1.6 + Math.random() * 0.6, phase: Math.random() * 6 };
        kinematic.push(b);
      }
      peg(L + 60, y + 330, 14); peg(Rr - 60, y + 330, 14);
    }
  },
  seesaw(y0, h) {
    let row = 0;
    for (let y = y0 + 180; y < y0 + h - 100; y += 330, row++) {
      const b = bar(row % 2 ? L + IW * 0.36 : L + IW * 0.64, y, 560, 22, 0, 'seesaw', 'seesaw');
      b.rock = { amp: 0.38, speed: 1.2 + Math.random() * 0.5, phase: Math.random() * 6 };
      kinematic.push(b);
      peg(row % 2 ? Rr - 90 : L + 90, y + 120, 14);
    }
  },
  zigzag(y0, h, x0 = L, x1 = Rr, kind = 'ramp', color = 'ramp', ang = 0.3, gap = 260) {
    const w = x1 - x0, len = w * 0.74; let i = 0;
    for (let y = y0 + 150; y < y0 + h - 100; y += gap, i++) {
      const left = i % 2 === 0;
      const cx = left ? x0 + len / 2 * Math.cos(ang) : x1 - len / 2 * Math.cos(ang);
      bar(cx, y, len, 28, left ? ang : -ang, kind, color, { friction: 0 });
    }
  },
  funnel(y0, h, color = 'funnel') {
    const gap = 170, half = (IW - gap) / 2, ang = 0.42, len = half / Math.cos(ang);
    bar(L + half / 2, y0 + h / 2, len, 26, ang, 'funnel', color, { friction: 0.001 });
    bar(Rr - half / 2, y0 + h / 2, len, 26, -ang, 'funnel', color, { friction: 0.001 });
  },
};

// ---- Tầng 1: đường đua + Quỷ Đỏ ----
function buildRace() {
  clearWorld(); simT = 0; S.bg = 'race';
  engine.gravity.y = C.course.gravity;
  const cageR = Math.max(240, Math.min(470, Math.sqrt(C.players.max * radius() * radius() * 2.4)));
  const cx = W / 2, cy = 130 + cageR, segs = [], N = 48;
  for (let i = 0; i < N; i++) {
    const a = i / N * Math.PI * 2;
    const s = Bodies.rectangle(cx + Math.cos(a) * cageR, cy + Math.sin(a) * cageR, cageR * 2 * Math.PI / N + 6, 16, { ...stat, angle: a + Math.PI / 2 });
    s.baseA = a; add(s, 'cage', 'accent-2'); segs.push(s);
  }
  cage = { cx, cy, r: cageR, segs, rot: 0, open: false };
  let y = cy + cageR + 160;
  const courseTop = y;
  const secs = C.course.sections.slice();
  if (C.course.shuffle) shuffle(secs);
  for (const s of secs) { const fn = SECTIONS[s.type]; if (!fn) continue; fn(y, s.height); y += s.height; }
  if (C.course.finalFunnel) { SECTIONS.funnel(y, 500); y += 500; }
  const barrierY = y + 260;
  Object.assign(geo, { courseTop, barrierY, bossY: barrierY + 520, finishY: barrierY + 790, floorY: barrierY + 1100, bossR: 140, camMax: barrierY - 620, reviveY: barrierY - 520 });
  geo.barrier = C.boss.enabled ? add(Bodies.rectangle(W / 2, barrierY, IW, 24, { ...stat, restitution: 0.1, friction: 0.3, collisionFilter: arenaCat }), 'barrier', 'boss-barrier') : null;
  geo.bossBody = C.boss.enabled ? add(Bodies.circle(W / 2, geo.bossY, geo.bossR, { ...stat, collisionFilter: arenaCat }), 'boss', 'boss-color') : null;
  add(Bodies.rectangle(W / 2, geo.floorY, W, 60, { ...stat, restitution: 0.1, collisionFilter: arenaCat }), 'floor', 'boss-bg-2');
  addWalls(geo.floorY + 100);
}

// ---- Tầng: Hang Băng ----
function buildIce() {
  clearWorld(); S.bg = 'ice';
  const F = C.floors.ice;
  geo.pen = add(Bodies.rectangle(W / 2, 720, IW, 20, stat), 'pen', 'ice');
  let y = 900, i = 0;
  const end = 900 + F.length;
  while (y < end - 200) {
    const h = Math.min(650, end - y);
    if (i % 2 === 0) SECTIONS.zigzag(y, h, L, Rr, 'iceRamp', 'ice', 0.34, 250);
    else SECTIONS.pegs(y, h, L, Rr, 'ice');
    y += h; i++;
  }
  SECTIONS.funnel(y, 400, 'ice'); y += 400;
  addBucket(y + 160);
  addWalls(geo.floorY + 100);
  S.ice = { next: 1.5, icicles: [], tail: null, likes: 0 };
}

// ---- Tầng: Ngã Ba ----
function buildFork() {
  clearWorld(); S.bg = 'race';
  const F = C.floors.fork;
  geo.pen = add(Bodies.rectangle(W / 2, 720, IW, 20, stat), 'pen', 'wood');
  const top = 1000, len = 2000, mid = W / 2;
  geo.laneTop = top;
  add(Bodies.rectangle(mid, top + len / 2, 20, len, stat), 'divider', 'wall');
  const danger = Math.random() < 0.5 ? 'left' : 'right';
  const lanes = { left: [L, mid - 10], right: [mid + 10, Rr] };
  // làn nguy hiểm: cọc + lưỡi cưa
  const [dx0, dx1] = lanes[danger];
  SECTIONS.pegs(top, len, dx0, dx1);
  for (let k = 0; k < F.saws; k++) {
    const sy = top + 420 + k * (len - 650) / Math.max(1, F.saws - 1);
    const w = dx1 - dx0, c0 = dx0 + (k % 2 ? w * 0.45 : w * 0.08) + 24;
    const b = add(Bodies.circle(c0, sy, 24, { ...stat, isSensor: true }), 'saw', 'saw');
    b.range = [c0, c0 + w * 0.42]; b.speed = rnd(0.9, 1.5); b.phase = Math.random() * 6;
    b.move = (b) => { const t = (Math.sin(simT * b.speed + b.phase) + 1) / 2; Body.setPosition(b, { x: b.range[0] + (b.range[1] - b.range[0]) * t, y: b.position.y }, true); };
    kinematic.push(b);
  }
  // làn an toàn: zigzag hẹp
  const [sx0, sx1] = lanes[danger === 'left' ? 'right' : 'left'];
  SECTIONS.zigzag(top, len, sx0, sx1, 'ramp', 'ramp', 0.36, 190);
  addBucket(top + len + 120);
  addWalls(geo.floorY + 100);
  S.fork = { danger, voting: true, voteLeft: F.voteTime, votes: new Map(), chosen: null, t: 0, tail: null };
}
function openFork(side) {
  const f = S.fork; f.chosen = side; f.voting = false; f.t = 0;
  say('forkResult', { side: spokenLabel(side === 'left' ? T.left : T.right), lane: spokenLabel(side === f.danger ? T.laneFast : T.laneSafe) }, { prio: 2, ttl: 6 });
  removeBody(geo.pen); geo.pen = null;
  const toLeft = side === 'left';
  // ramp dẫn về làn được chọn + nắp đậy làn còn lại
  const span = IW / 2 + 60, ang = 0.36, len = span / Math.cos(ang);
  const cx = toLeft ? Rr - span / 2 : L + span / 2;
  bar(cx, 790 + Math.tan(ang) * span / 2, len, 22, toLeft ? -ang : ang, 'wood', 'wood', { friction: 0 });
  add(Bodies.rectangle(toLeft ? W * 0.75 : W * 0.25, geo.laneTop - 6, IW / 2, 18, stat), 'lid', 'wall');
}

// ---- Tầng: Dung Nham ----
function buildLava() {
  clearWorld(); S.bg = 'race';
  const F = C.floors.lava;
  geo.pen = add(Bodies.rectangle(W / 2, 720, IW, 20, stat), 'pen', 'wood');
  let y = 900;
  const pool = shuffle(['pegs', 'spinners', 'bouncers', 'slats', 'hammers', 'seesaw']);
  let i = 0;
  while (y < 900 + F.length - 300) { const h = Math.min(1300, 900 + F.length - y); SECTIONS[pool[i % pool.length]](y, h); y += h; i++; }
  SECTIONS.funnel(y, 450); y += 450;
  addBucket(y + 160);
  addWalls(geo.floorY + 100);
  S.lava = { y: 380, delay: 1.2, rate: 0, mult: 1, freeze: 0, t: 0 };
}

// ---- Tầng: Rồng Lửa ----
function buildDragon() {
  clearWorld(); S.bg = 'dragon';
  geo.barrierY = 640; geo.bossY = 1170; geo.bossR = 165; geo.camMax = 0; geo.floorY = 1850; geo.reviveY = 160;
  geo.barrier = add(Bodies.rectangle(W / 2, geo.barrierY, IW, 24, { ...stat, restitution: 0.1, friction: 0.3, collisionFilter: arenaCat }), 'barrier', 'boss-barrier');
  geo.bossBody = add(Bodies.circle(W / 2, geo.bossY, geo.bossR, { ...stat, collisionFilter: arenaCat }), 'dragon', 'dragon-color');
  add(Bodies.rectangle(W / 2, geo.floorY, W, 60, { ...stat, collisionFilter: arenaCat }), 'floor', 'boss-bg-2');
  addWalls(geo.floorY + 100);
}

// ---- Tầng: Đấu Trường ----
function buildArena() {
  clearWorld(); S.bg = 'arena';
  const F = C.floors.arena;
  geo.camMax = 0; geo.floorY = 1550; geo.walls = false;
  geo.platform = add(Bodies.rectangle(W / 2, 1180, F.startWidth, 40, { ...stat, friction: 0.05, restitution: 0.3, chamfer: { radius: 18 } }), 'platform', 'arena-floor');
  geo.platW = F.startWidth;
  geo.lips = [-1, 1].map(s => add(Bodies.rectangle(W / 2 + s * (F.startWidth / 2 + 10), 1000, 20, 380, stat), 'lid', 'wall'));
  S.arena = { t: 0, nextShove: F.shoveEvery, dir: 1 };
}

const FLOORS = {
  race:   { build: buildRace },
  ice:    { build: buildIce,    spawn: () => respawnSurvivors(170, L, Rr) },
  fork:   { build: buildFork,   spawn: () => respawnSurvivors(170, L, Rr) },
  lava:   { build: buildLava,   spawn: () => respawnSurvivors(170, L, Rr) },
  dragon: { build: buildDragon, spawn: () => respawnSurvivors(140, L, Rr) },
  arena:  { build: buildArena,  spawn: () => respawnSurvivors(150, W / 2 - C.floors.arena.startWidth / 2 + 10, W / 2 + C.floors.arena.startWidth / 2 - 10) },
};

function stepKinematic(dt) {
  simT += dt;
  if (cage && !cage.open) {
    cage.rot += 0.6 * dt;
    for (const s of cage.segs) {
      const a = s.baseA + cage.rot;
      Body.setPosition(s, { x: cage.cx + Math.cos(a) * cage.r, y: cage.cy + Math.sin(a) * cage.r }, true);
      Body.setAngle(s, a + Math.PI / 2, true);
    }
  }
  for (const b of kinematic) {
    if (b.spin) Body.setAngle(b, b.angle + b.spin * dt * 60, true);
    else if (b.rock) Body.setAngle(b, Math.sin(simT * b.rock.speed + b.rock.phase) * b.rock.amp, true);
    else if (b.swing) {
      const th = Math.sin(simT * b.swing.speed + b.swing.phase) * b.swing.amp, c = Math.cos(th), s = Math.sin(th);
      Body.setPosition(b, { x: b.pivot.x + b.off0.x * c - b.off0.y * s, y: b.pivot.y + b.off0.x * s + b.off0.y * c }, true);
      Body.setAngle(b, th, true);
    } else if (b.move) b.move(b, dt);
  }
}
function openCage() {
  if (!cage || cage.open) return;
  cage.open = true;
  for (const s of cage.segs) {
    const a = ((s.baseA + cage.rot) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    if (a > Math.PI * 0.22 && a < Math.PI * 0.78) removeBody(s);
  }
}

// Va chạm với lưỡi cưa
Events.on(engine, 'collisionStart', e => {
  for (const pr of e.pairs) {
    const a = pr.bodyA, b = pr.bodyB;
    const saw = a.kind === 'saw' ? a : b.kind === 'saw' ? b : null;
    const ball = a.player ? a : b.player ? b : null;
    if (saw && ball && !ball.player.dead) {
      const p = ball.player;
      p.sawHits = p.sawHits || new Set();
      if (p.sawHits.has(saw.id)) continue;   // mỗi lưỡi cưa chỉ tính 1 lần / viên bi
      p.sawHits.add(saw.id);
      if (Math.random() < (C.floors.fork.sawKillChance ?? 0.3)) hitKill(p);
      else { Body.setVelocity(ball, { x: (ball.position.x - saw.position.x) * 0.25, y: -6 }); burst(ball.position.x, ball.position.y, '#ffd23f', 6); }
    }
  }
});

// =====================================================================
//  TRẠNG THÁI
// =====================================================================
const players = new Map();
const queue = new Map();
const S = {
  phase: 'lobby', t: 0, timeLeft: 0, camY: 0, hype: 0, hypeIdx: 0, raceTime: 0, clock: 0, bg: 'race',
  plan: ['race'], floorIdx: 0, floorReached: 1,
  boss: null, effects: [], particles: [], texts: [], shots: [], lasers: [], crosshairs: [],
  shake: 0, gravityTimer: 0, wind: 0, quake: 0, winner: null, champ: null, failKind: null,
  dmg: new Map(), lastDead: null,
};
const alive = () => { const a = []; for (const p of players.values()) if (p.body && !p.dead) a.push(p); return a; };
const curFloor = () => S.plan[S.floorIdx] || 'race';

function createBody(p, x, y) {
  if (p.body) Composite.remove(engine.world, p.body);
  p.r = radius();
  p.body = Bodies.circle(x, y, p.r, { restitution: 0.45, friction: 0.005, frictionAir: 0.004, density: 0.002, label: 'ball', collisionFilter: { category: CAT_BALL, mask: 0xFFFF } });
  p.body.player = p;
  Composite.add(engine.world, p.body);
}
function resetFloorBuffs(p) { p.sawHits = null; p.big = false; p.shield = false; p.shieldUntil = 0; p.boost = 0; p.frozen = 0; p.uses = {}; p.lucky = false; p.assist = false; p.still = 0; p.raining = false; }

function addPlayer(u) {
  if (players.has(u.id) || players.size >= C.players.max) return null;
  const p = { id: u.id, name: u.name || u.id, nick: u.nick || u.name, avatar: u.avatar || '', dead: false, gifted: false, revived: false };
  resetFloorBuffs(p);
  p.sprite = makeSprite(p);
  players.set(p.id, p);
  const a = Math.random() * Math.PI * 2, d = Math.random() * (cage.r - radius() * 2 - 20);
  createBody(p, cage.cx + Math.cos(a) * d, cage.cy + Math.sin(a) * d);
  Body.setVelocity(p.body, { x: rnd(-4, 4), y: rnd(-4, 4) });
  if (S.phase === 'lobby') {
    lobbyAdd(p);
    if (VO.joinSaid < 3) { VO.joinSaid++; say('joinFirst', { name: speakName(p) }, { prio: 0, ttl: 6 }); }
    if ([10, 25, 50, 100, 150, 200].includes(players.size)) say('joinCount', { n: players.size }, { prio: 1, ttl: 8, replace: true });
  }
  play('join');
  return p;
}
function respawnSurvivors(yTop, x0, x1) {
  const list = shuffle(alive()), r = radius(), step = 2 * r + 6, per = Math.max(1, Math.floor((x1 - x0) / step));
  list.forEach((p, i) => {
    const row = Math.floor(i / per), col = i % per;
    resetFloorBuffs(p);
    createBody(p, x0 + r + 4 + col * step + (row % 2 ? r : 0), yTop + row * (2 * r + 4));
  });
}
function killBall(p, pop = true) {
  if (!p.body || p.dead) return;
  p.dead = true; S.lastDead = p;
  if (pop) burst(p.body.position.x, p.body.position.y, COL.laser, 16);
  Composite.remove(engine.world, p.body);
}
const isShielded = p => p.shield || p.shieldUntil > S.clock;
function hitShield(p) {
  if (p.shieldUntil > S.clock) { S.effects.push({ type: 'ring', x: p.body.position.x, y: p.body.position.y, t: 0, life: 0.4, r: p.r * 2.4, color: COL['accent-2'] }); return true; }
  if (p.shield) { p.shield = false; S.effects.push({ type: 'ring', x: p.body.position.x, y: p.body.position.y, t: 0, life: 0.4, r: p.r * 2.4, color: COL['ball-shield'] }); return true; }
  return false;
}
function hitKill(p) { if (p.dead) return false; if (hitShield(p)) return false; killBall(p); return true; }

function tryJoin(u) {
  if (!u || !u.id || players.has(u.id)) return;
  if (S.phase === 'lobby' || S.phase === 'start') addPlayer(u);
  else if (C.players.queueForNextRace && !queue.has(u.id)) queue.set(u.id, u);
}
function revive(p) {
  if (!p || !p.dead || p.revived) return false;
  const ph = S.phase;
  if (!['race', 'boss', 'ice', 'fork', 'lava', 'dragon', 'transition', 'clear'].includes(ph)) return false;
  const al = alive();
  const minY = al.length ? Math.min(...al.map(q => q.body.position.y)) : S.camY + 300;
  let y;
  if (ph === 'boss' || ph === 'dragon') y = geo.reviveY;
  else if (ph === 'transition' || (ph === 'fork' && S.fork?.voting)) y = 300;
  else if (ph === 'clear') y = minY - 60;
  else y = Math.max(minY - 90, S.camY + 120);
  if (ph === 'lava') y = Math.max(y, S.lava.y + 160);
  p.dead = false; p.revived = true; resetFloorBuffs(p);
  createBody(p, rnd(L + 60, Rr - 60), y);
  burst(p.body.position.x, p.body.position.y, COL.good, 24);
  return true;
}

// =====================================================================
//  HUD
// =====================================================================
const ui = {
  lobby: $('#lobby'), howto: $('#howto'), count: $('#count'), top3: $('#top3'), timer: $('#timer'), hype: $('#hype'),
  bossHud: $('#bossHud'), result: $('#result'), floorBadge: $('#floorBadge'), hint: $('#hint'), vote: $('#vote'), floorIntro: $('#floorIntro'),
  banner: $('#banner'), toasts: $('#toasts'), status: $('#status'),
};
const HUD_KEYS = ['lobby', 'howto', 'count', 'top3', 'timer', 'hype', 'bossHud', 'result', 'floorBadge', 'hint', 'vote', 'floorIntro'];
function show(...els) { for (const k of HUD_KEYS) ui[k].classList.toggle('hidden', !els.includes(k)); }
let lastHint = '';
function setHint(html, warn = false) { const k = html + warn; if (k === lastHint) return; lastHint = k; ui.hint.querySelector('.g-do').innerHTML = html; ui.hint.classList.toggle('warn', warn); }
function burst(x, y, color, n = 14) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, s = rnd(2, 9);
    S.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, t: 0, life: rnd(0.4, 0.9), color, size: rnd(4, 9) });
  }
}
let bannerTimer = null;
function banner(small, big, secs = 2) {
  ui.banner.querySelector('.b-small').textContent = small || '';
  ui.banner.querySelector('.b-big').textContent = big || '';
  ui.banner.classList.add('show');
  clearTimeout(bannerTimer); bannerTimer = setTimeout(() => ui.banner.classList.remove('show'), secs * 1000);
}
function toast(user, html) {
  const d = document.createElement('div'); d.className = 'toast';
  if (user) d.appendChild(avatarEl(user));
  const s = document.createElement('span'); s.innerHTML = html; d.appendChild(s);
  ui.toasts.appendChild(d);
  while (ui.toasts.children.length > 4) ui.toasts.firstChild.remove();
  setTimeout(() => d.remove(), 4000);
}
// ---------------- Hướng dẫn trên màn hình ----------------
const up = s => String(s || '').toUpperCase();
const sortedTiers = () => (C.gifts.tiers || []).slice().sort((a, b) => a.minDiamonds - b.minDiamonds);
// Icon quà: emoji / chữ, hoặc ảnh (đường dẫn file:, http(s):, assets/, data:)
const isImgIcon = v => /^(https?:|file:|data:image|assets\/|\.?\/)|\.(png|jpe?g|webp|gif|svg)(\?.*)?$/i.test(String(v || '').trim());
function giftIconHtml(icon, cls = 'gico') {
  const v = String(icon || '').trim();
  if (!v) return '';
  if (isImgIcon(v)) return `<img class="${cls}" src="${esc(v)}" referrerpolicy="no-referrer" alt="">`;
  return `<span class="${cls}">${esc(v)}</span>`;
}
const tierTag = t => `${giftIconHtml(t.icon)}${t.minDiamonds}💎`;
function giftSummary() { return sortedTiers().map(t => `${tierTag(t)} ${esc(T.act?.[t.action] || '')}${t.room ? ' + ' + esc(T.room?.[t.room] || t.room) : ''}`).join(' · '); }
function giftSummaryShort() { return '💎 ' + sortedTiers().map(t => `${giftIconHtml(t.icon)}<b>${t.minDiamonds}</b> ${esc(T.act?.[t.action] || '')}`).join(' · '); }
function dmgSummary() { return sortedTiers().filter(t => t.bossDamage).map(t => `${tierTag(t)}=${t.bossDamage}`).join(' · ') + ' ⚔'; }
// Chữ có chèn bảng quà: escape phần chữ rồi mới chèn HTML icon
function fmtHtml(str) {
  return esc(String(str || '')).replace(/\{giftsShort\}/g, giftSummaryShort()).replace(/\{gifts\}/g, giftSummary()).replace(/\{dmg\}/g, dmgSummary()).replace(/\{(\w+)\}/g, m => esc(fmt(m)));
}
// Từ khoá hiển thị/đọc: tiếng Anh thì ưu tiên từ khoá không dấu (fire, left...)
function kwFor(list, dflt) {
  const L = (list || []).filter(Boolean);
  if (C.language === 'en') return up(L.find(k => /^[a-z0-9 ]+$/i.test(k)) || L[0] || dflt);
  return up(L[0] || dflt);
}
function fmt(str) {
  const tiers = sortedTiers();
  const gold = tiers.find(t => t.room === 'goldRain');
  const map = {
    bonk: kwFor(C.boss.keywords, 'bonk'), fire: kwFor(C.floors.ice.keywords, 'fire'),
    left: kwFor(C.floors.fork.keywordsLeft, 'left'), right: kwFor(C.floors.fork.keywordsRight, 'right'),
    frozen: C.floors.ice.frozenMax, gifts: giftSummary(), dmg: dmgSummary(),
    maxVote: Math.max(1, ...tiers.map(t => t.voteWeight || 1)), goldMin: gold ? gold.minDiamonds : '—',
    sec: C.balance.roomEventSeconds, lucky: C.balance.luckyPerFloor, ghost: C.balance.ghostDamage, n: S.plan.length,
  };
  return String(str || '').replace(/\{(\w+)\}/g, (m, k) => map[k] ?? m);
}
function guideRows(spec) {
  return String(spec || '').split(';').filter(Boolean).map((r, i) => {
    const [ic, txt] = r.includes('|') ? r.split('|') : ['', r];
    return { ic, txt: fmt(txt), i };
  });
}
function buildLobbyGuide() {
  const box = $('#lobby .lg-slides'); if (!box) return;
  const joinRows = [['💬', T.gJ1, T.gJ1d], ['❤️', T.gJ2, T.gJ2d], ['➕', T.gJ3, T.gJ3d], ['🏆', T.gJ4, T.gJ4d]]
    .map(([i, t, d]) => `<div class="lg-row"><div class="lg-ic">${i}</div><div><div class="lg-t">${esc(t)}</div><div class="lg-d">${esc(d)}</div></div></div>`).join('');
  const giftRows = sortedTiers().map(t => `<div class="lg-gift"><div class="lg-dia${t.icon ? ' has-icon' : ''}">${giftIconHtml(t.icon, 'lg-icon')}<span>${t.minDiamonds}💎</span></div>
      <div>${t.action && t.action !== 'none' ? `<b>${esc(T.act?.[t.action] || t.action)}</b>${esc(fmt(T.actDesc?.[t.action] || ''))}` : '—'}</div>
      <div class="room">${t.room ? `<b>${esc(T.room?.[t.room] || t.room)}</b>${esc(fmt(T.roomDesc?.[t.room] || ''))}` : '—'}</div>
      <div class="dmg">${t.bossDamage ? '⚔' + t.bossDamage : ''}</div></div>`).join('');
  const floorRows = S.plan.map((f, i) => {
    const first = guideRows(T.floorGuide?.[f])[1] || guideRows(T.floorGuide?.[f])[0] || { txt: '' };
    return `<div class="lg-floor"><div class="lg-n">${i + 1}</div><div><div class="lg-t">${esc(T.floorNames?.[f] || f)}</div><div class="lg-d">${first.txt}</div></div></div>`;
  }).join('');
  const slides = [
    `<div class="lg-title">${esc(T.gJoinTitle)}</div>${joinRows}`,
    `<div class="lg-title">${esc(T.gGiftTitle)}</div><div class="lg-gift head"><div></div><div>${esc(T.gSelf)}</div><div>${esc(T.gRoom)}</div><div>${esc(T.gBoss)}</div></div>${giftRows}
      <div class="lg-note">${esc(T.gGiftNote)}</div>${C.balance.luckyPerFloor ? `<div class="lg-free">${esc(fmt(T.gGiftFree))}</div>` : ''}`,
  ];
  if (S.plan.length > 1) slides.push(`<div class="lg-title">${esc(fmt(T.gTowerTitle))}</div>${floorRows}`);
  box.innerHTML = slides.map((h, i) => `<div class="lg-slide${i === 0 ? ' on' : ''}">${h}</div>`).join('');
  $('#lobby .lg-dots').innerHTML = slides.map((_, i) => `<span class="${i === 0 ? 'on' : ''}"></span>`).join('');
  S.guideSlide = 0;
}
function rotateLobbyGuide() {
  const slides = document.querySelectorAll('#lobby .lg-slide'); if (!slides.length) return;
  const i = Math.floor(S.t / (C.guide?.slideSeconds || 6)) % slides.length;
  if (i === S.guideSlide) return;
  S.guideSlide = i;
  slides.forEach((e, k) => e.classList.toggle('on', k === i));
  document.querySelectorAll('#lobby .lg-dots span').forEach((e, k) => e.classList.toggle('on', k === i));
}
let lastGift = '';
function setGiftLine(html) { if (html === lastGift) return; lastGift = html; ui.hint.querySelector('.g-gift').innerHTML = C.guide?.guideBar === false ? '' : html; }
// ---------------- GIỌNG ĐỌC: hướng dẫn + bình luận (giọng AI Edge qua app, dự phòng giọng Windows) ----------------
const VO = { queue: [], cur: null, edgeOk: null, fails: 0, last: {}, reqs: new Map(), audio: null, engineUsed: 'none',
  giftBuf: [], giftTimer: null, lastLeader: null, joinSaid: 0, lobbyNext: 6, lobbyIdx: 0, soonSaid: false, cdSaid: false, arenaLast: 0, watch: null };
const VCAT = { guide: ['lobbyWelcome', 'lobbyGuide', 'lobbySoon', 'howTo', 'floor_', 'joinNext', 'test'], gifts: ['gift', 'goldRain', 'mega', 'follow', 'share'], countdown: ['countdown'] };
const vcfg = () => C.voice || {};
function vcat(key) { for (const [c, ks] of Object.entries(VCAT)) if (ks.some(k => key.startsWith(k))) return c; return 'commentary'; }
function speakName(u) {
  const n = String((u && (u.nick || u.name)) || '').replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim();
  return (n || (u && u.name) || '').slice(0, 24);
}
const spokenLabel = s => String(s || '').replace(/[•·!]/g, ',').replace(/\s*,\s*/g, ', ').replace(/(,\s*)+/g, ', ').replace(/^[,\s]+|[,\s]+$/g, '').toLowerCase();
function vtext(key, vars = {}) {
  const pool = String(T.voice?.[key] || '').split('|').map(x => x.trim()).filter(Boolean);
  if (!pool.length) return '';
  return fmt(pick(pool).replace(/\{(\w+)\}/g, (m, k) => vars[k] != null ? String(vars[k]) : m));
}
function say(key, vars = {}, o = {}) {
  const V = vcfg(); if (!V.enabled) return;
  if (V[vcat(key)] === false) return;
  if (o.cooldown && S.clock - (VO.last[key] ?? -999) < o.cooldown) return;
  const text = vtext(key, vars); if (!text) return;
  VO.last[key] = S.clock;
  const item = { key, text, prio: o.prio ?? 1, expire: S.clock + (o.ttl ?? 8) };
  if (o.replace) VO.queue = VO.queue.filter(q => q.key !== key);
  VO.queue.push(item);
  VO.queue.sort((a, b) => b.prio - a.prio);
  if (VO.queue.length > (V.maxQueue || 4)) VO.queue.length = V.maxQueue || 4;
  if (o.interrupt && VO.cur && VO.cur.prio < item.prio) stopSpeaking();
  pumpVoice();
}
function stopSpeaking() { try { VO.audio && VO.audio.pause(); } catch {} try { window.speechSynthesis && speechSynthesis.cancel(); } catch {} finishLine(); }
function finishLine() { clearTimeout(VO.watch); VO.cur = null; setTimeout(pumpVoice, 150); }
function pumpVoice() {
  if (VO.cur) return;
  while (VO.queue.length && VO.queue[0].expire < S.clock) VO.queue.shift();
  const item = VO.queue.shift(); if (!item) return;
  VO.cur = item;
  VO.watch = setTimeout(() => { if (VO.cur === item) stopSpeaking(); }, 20000);
  const eng = vcfg().engine || 'auto';
  if (eng !== 'system' && APP && VO.edgeOk !== false) speakEdge(item, eng); else speakSystem(item);
}
let ttsSeq = 0;
function speakEdge(item, eng) {
  const lang = C.language === 'en' ? 'en' : 'vi';
  const voice = vcfg().edgeVoice?.[lang] || (lang === 'en' ? 'en-US-AvaMultilingualNeural' : 'vi-VN-HoaiMyNeural');
  const id = 't' + (++ttsSeq);
  const to = setTimeout(() => onTts({ id, ok: false, error: 'timeout' }), 7000);
  VO.reqs.set(id, { item, eng, to });
  APP.send('tts', { id, text: item.text, voice, rate: vcfg().rate || 1 });
}
function onTts(r) {
  const q = VO.reqs.get(r.id); if (!q) return;
  VO.reqs.delete(r.id); clearTimeout(q.to);
  if (VO.cur !== q.item) return;
  if (!r.ok) {
    VO.fails++;
    if (VO.fails >= 2 && q.eng === 'auto') VO.edgeOk = false;   // AI lỗi liên tiếp -> dùng hẳn giọng Windows (thử lại khi đổi cấu hình)
    return q.eng === 'auto' ? speakSystem(q.item) : finishLine();
  }
  VO.fails = 0; VO.edgeOk = true; VO.engineUsed = 'edge';
  const a = VO.audio = new Audio('data:audio/mpeg;base64,' + r.b64);
  a.volume = clamp(vcfg().volume ?? 1, 0, 1);
  a.onended = a.onerror = () => { if (VO.cur === q.item) finishLine(); };
  a.play().catch(() => { if (VO.cur === q.item) finishLine(); });
}
function systemVoices() { try { return window.speechSynthesis ? speechSynthesis.getVoices() : []; } catch { return []; } }
function pickSystemVoice(lang) {
  const vs = systemVoices(), want = vcfg().systemVoice?.[lang];
  return (want && vs.find(v => v.name === want)) || vs.find(v => (v.lang || '').toLowerCase().startsWith(lang)) || null;
}
function speakSystem(item) {
  const lang = C.language === 'en' ? 'en' : 'vi';
  const v = window.speechSynthesis && pickSystemVoice(lang);
  if (!v) { VO.engineUsed = 'none'; return finishLine(); }   // máy chưa có giọng cho ngôn ngữ này
  VO.engineUsed = 'system';
  const u = new SpeechSynthesisUtterance(item.text);
  u.voice = v; u.lang = v.lang; u.rate = vcfg().rate || 1; u.volume = clamp(vcfg().volume ?? 1, 0, 1);
  u.onend = u.onerror = () => { if (VO.cur === item) finishLine(); };
  speechSynthesis.speak(u);
}
try { systemVoices(); if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => systemVoices(); } catch {}
function voiceGift(u, gift, effect) {
  const V = vcfg(); if (!V.enabled || V.gifts === false) return;
  VO.giftBuf.push({ name: speakName(u), gift, effect });
  clearTimeout(VO.giftTimer);
  VO.giftTimer = setTimeout(() => {
    const b = VO.giftBuf; VO.giftBuf = [];
    if (b.length === 1) {
      say('giftOne', { name: b[0].name, gift: b[0].gift }, { prio: 2, ttl: 12 });
      if (b[0].effect) say('giftEffect', { name: b[0].name, effect: b[0].effect }, { prio: 2, ttl: 12 });
    } else {
      const names = [...new Set(b.map(x => x.name))];
      const more = names.length > 3 ? (C.language === 'en' ? ` and ${names.length - 3} more` : ` và ${names.length - 3} người khác`) : '';
      say('giftMany', { names: names.slice(0, 3).join(', ') + more }, { prio: 2, ttl: 12 });
    }
  }, 1800);
}

// ---------------- Bảng quà nổi (kéo / đổi cỡ) ----------------
const GW_BASE = 300;
let gwLayout = store.get('giftWidget', null) || { x: W - GW_BASE * 1.15 - 24, y: 440, s: 1.15 };
const gwCfg = () => (C.guide && C.guide.giftWidget) || {};
function renderGiftWidget() {
  const el = $('#giftWidget'); if (!el) return;
  const G = gwCfg();
  el.querySelector('.gw-title').textContent = T.gwTitle || '🎁';
  el.querySelector('.gw-list').innerHTML = sortedTiers().map(t => `<div class="gw-row">
      <div class="gw-ic">${giftIconHtml(t.icon || '💎')}<span class="gw-dia">${t.minDiamonds}💎</span></div>
      <div class="gw-txt"><div class="gw-act">${esc(T.act?.[t.action] || '')}</div>
        ${G.showDesc !== false && T.actDesc?.[t.action] ? `<div class="gw-desc">${esc(fmt(T.actDesc[t.action]))}</div>` : ''}
        ${G.showRoom !== false && t.room ? `<span class="gw-room">✨ ${esc(T.room?.[t.room] || t.room)}</span>` : ''}</div></div>`).join('');
  el.querySelector('.gw-foot').textContent = G.showDesc !== false ? (T.gwFoot || '') : '';
  el.querySelector('.gw-tag').textContent = '✥ ' + (T.gwEdit || '');
  applyGiftWidgetLayout();
}
function applyGiftWidgetLayout() {
  const el = $('#giftWidget'); if (!el) return;
  const G = gwCfg();
  el.classList.toggle('hidden', G.enabled === false);
  el.classList.toggle('edit', !!G.edit);
  el.style.opacity = G.opacity ?? 0.95;
  const s = clamp(gwLayout.s || 1, 0.4, 3);
  const h = el.offsetHeight * s, w = GW_BASE * s;
  gwLayout.x = clamp(gwLayout.x, -w * 0.5, W - w * 0.5);
  gwLayout.y = clamp(gwLayout.y, 0, H - Math.min(h, 120));
  el.style.transform = `translate(${gwLayout.x}px, ${gwLayout.y}px) scale(${s})`;
}
(function setupGiftWidgetDrag() {
  const el = $('#giftWidget'); if (!el) return;
  let mode = null, sx = 0, sy = 0, start = null;
  const stageScale = () => wrap.getBoundingClientRect().width / W;
  el.addEventListener('pointerdown', e => {
    if (!gwCfg().edit) return;
    mode = e.target.classList.contains('gw-resize') ? 'resize' : 'move';
    sx = e.clientX; sy = e.clientY; start = { ...gwLayout };
    el.setPointerCapture(e.pointerId); e.preventDefault();
  });
  el.addEventListener('pointermove', e => {
    if (!mode) return;
    const k = stageScale(), dx = (e.clientX - sx) / k, dy = (e.clientY - sy) / k;
    if (mode === 'move') { gwLayout.x = start.x + dx; gwLayout.y = start.y + dy; }
    else gwLayout.s = clamp((GW_BASE * start.s + dx) / GW_BASE, 0.4, 3);
    applyGiftWidgetLayout();
  });
  const end = () => { if (mode) { mode = null; store.set('giftWidget', gwLayout); } };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
})();
function floorLabel() { return `${T.floor} <b>${S.floorIdx + 1}/${S.plan.length}</b> · ${T.floorNames?.[curFloor()] || ''}`; }

// =====================================================================
//  LUỒNG CHƠI
// =====================================================================
function planRound() {
  if (!C.tower.enabled) return ['race'];
  const pool = shuffle((C.tower.middlePool || []).filter(x => FLOORS[x] && !['race', 'dragon', 'arena'].includes(x)));
  const plan = ['race', ...pool.slice(0, clamp(C.tower.middleCount ?? 2, 0, pool.length))];
  if (C.tower.dragon) plan.push('dragon');
  if (C.tower.arena) plan.push('arena');
  return plan;
}

function setPhase(ph) {
  S.phase = ph; S.t = 0;
  ui.hype.style.top = '';
  const E = ENTER[ph]; if (E) E();
}
const ENTER = {
  lobby() {
    for (const p of players.values()) if (p.body) Composite.remove(engine.world, p.body);
    players.clear();
    S.plan = planRound(); S.floorIdx = 0; S.floorReached = 1;
    buildRace();
    Object.assign(S, { camY: 0, boss: null, winner: null, raceTime: 0, effects: [], particles: [], texts: [], shots: [], lasers: [], crosshairs: [],
      gravityTimer: 0, wind: 0, quake: 0, failKind: null, champ: null, lastDead: null });
    S.dmg = new Map(); engine.gravity.y = C.course.gravity;
    $('#lobby .l-grid').innerHTML = '';
    $('#lobby .l-record').textContent = bestFloor > 0 ? `🏆 ${T.record} ${bestFloor}` : '';
    S.timeLeft = C.timing.lobby;
    buildLobbyGuide();
    show('lobby');
    Object.assign(VO, { joinSaid: 0, lobbyNext: 7, lobbyIdx: 0, soonSaid: false, lastLeader: null, arenaLast: 0 });
    say('lobbyWelcome', {}, { prio: 1, ttl: 15 });
    for (const u of queue.values()) addPlayer(u);
    queue.clear();
  },
  start() {
    S.timeLeft = C.timing.startCountdown; show('howto', 'count'); S.lastCount = -1;
    VO.cdSaid = false; say('howTo', {}, { prio: 2, ttl: 10, interrupt: true });
    $('#howto .how-gift').innerHTML = `${esc(T.howGift)}: ${giftSummary()}`;
  },
  race() {
    openCage(); play('start');
    show('top3', 'timer', 'hype', 'floorBadge', 'hint');
    setHint(fmt(T.raceDo)); setGiftLine(fmtHtml(T.floorGift?.race));
    S.champ = (C.champion.enabled && champion) ? makeChampionBumper() : null;
    if (S.champ) say('champion', { name: speakName(champion) }, { prio: 0, ttl: 10 });
    giveLucky();
  },
  boss() {
    removeChampion();
    startBoss('demon');
    for (const p of alive()) if (p.body.position.y < geo.barrierY - 220) {
      p.raining = true; p.body.collisionFilter.mask = CAT_ARENA | CAT_BALL;
      Body.setPosition(p.body, { x: p.body.position.x, y: Math.max(p.body.position.y, geo.camMax - 300 - Math.random() * 600) });
      Body.setVelocity(p.body, { x: rnd(-2, 2), y: 18 });
    }
  },
  clear() {
    show('floorBadge');
    if (!S.clearTitle) say('floorClear', { n: alive().length }, { prio: 2, ttl: 6 });
    const title = S.clearTitle || String(T.floorCleared || '').replace('{n}', S.floorIdx + 1);
    S.clearTitle = null;
    banner(`${alive().length} ${T.moveOn || ''}`, title, C.timing.clear ?? 4);
  },
  transition() {
    S.floorIdx = Math.min(S.floorIdx, S.plan.length - 1);
    const st = curFloor();
    S.boss = null; S.crosshairs = []; S.shots = []; S.lasers = [];
    engine.gravity.y = C.course.gravity; S.gravityTimer = 0; S.wind = 0; S.quake = 0;
    FLOORS[st].build();
    FLOORS[st].spawn?.();
    S.camY = 0;
    S.floorReached = S.floorIdx + 1;
    if (S.floorReached > bestFloor) { bestFloor = S.floorReached; store.set('bestFloor', bestFloor); }
    say('floor_' + st, { floor: S.floorIdx + 1 }, { prio: 3, ttl: 12, interrupt: true });
    const fi = ui.floorIntro;
    fi.querySelector('.fi-floor').textContent = `${T.floor} ${S.floorIdx + 1}`;
    fi.querySelector('.fi-name').textContent = T.floorNames?.[st] || st;
    fi.querySelector('.fi-guide').innerHTML = guideRows(T.floorGuide?.[st]).map(r =>
      `<div class="fi-row" style="animation-delay:${0.25 + r.i * 0.35}s"><span class="n">${r.i + 1}</span><span class="i">${r.ic}</span><span>${r.txt}</span></div>`).join('');
    fi.querySelector('.fi-gift').innerHTML = fmtHtml(T.floorGift?.[st]);
    fi.querySelector('.fi-steps').innerHTML = S.plan.map((_, i) => `<span class="${i < S.floorIdx ? 'done' : i === S.floorIdx ? 'now' : ''}"></span>`).join('');
    show('floorIntro');
    S.timeLeft = C.tower.transition;
  },
  ice() { removeBody(geo.pen); geo.pen = null; show('top3', 'timer', 'hype', 'floorBadge', 'hint'); setGiftLine(fmtHtml(T.floorGift?.ice)); giveLucky(); },
  fork() { show('vote'); renderVote(); giveLucky(); },
  lava() { removeBody(geo.pen); geo.pen = null; show('top3', 'timer', 'hype', 'floorBadge', 'hint'); setGiftLine(fmtHtml(T.floorGift?.lava)); giveLucky(); },
  dragon() { startBoss('dragon'); giveLucky(); },
  arena() { say('arenaStart', {}, { prio: 2, ttl: 5 }); (geo.lips || []).forEach(removeBody); geo.lips = null; show('timer', 'hype', 'floorBadge', 'hint'); setGiftLine(fmtHtml(T.floorGift?.arena)); },
  finish() { show('top3', 'timer'); },
  bossWin() { show(); play('lose'); },
  result() { S.timeLeft = C.timing.result; showResult(); },
};

function floorClear() {
  if (S.floorIdx >= S.plan.length - 1) {
    // tầng cuối không phải đấu trường -> người gây nhiều sát thương nhất (còn sống) thắng
    const al = alive();
    const best = al.sort((a, b) => (S.dmg.get(b.id)?.dmg || 0) - (S.dmg.get(a.id)?.dmg || 0))[0];
    if (best) finishWith(best); else fail('wipe');
    return;
  }
  setPhase('clear');
}
function fail(kind) { S.winner = null; S.failKind = kind; setPhase('result'); }
function cutoff(yLine) {
  let n = 0;
  for (const p of alive()) if (p.body.position.y < yLine || p.frozen > 0) { killBall(p); n++; }
  if (n) S.texts.push({ x: W / 2, y: S.camY + 520, text: `-${n} ${T.tooSlow}`, t: 0, life: 2, color: '#fff', size: 34 });
  if (alive().length) floorClear(); else fail('wipe');
}

// ---------------- Lobby ----------------
function lobbyAdd(p) {
  const grid = $('#lobby .l-grid');
  const d = document.createElement('div'); d.className = 'p';
  d.appendChild(avatarEl(p)); const sp = document.createElement('span'); sp.textContent = '@' + p.name; d.appendChild(sp);
  grid.prepend(d);
  while (grid.children.length > 4) grid.lastChild.remove();
}
function updateLobby() {
  const n = players.size;
  $('#lobby .l-num').textContent = `${n} / ${C.players.max} ${T.racers}`;
  $('#lobby .l-bar div').style.width = (n / C.players.max * 100) + '%';
  $('#lobby .l-timer').textContent = Math.max(0, Math.ceil(S.timeLeft));
  $('#lobby .l-sub').textContent = (S.timeLeft <= 0 && n < C.timing.lobbyMinPlayers) ? T.waitingPlayers : T.lobbySub;
}

// ---------------- Bi may mắn ----------------
function giveLucky() {
  const n = C.balance.luckyPerFloor || 0; if (!n) return;
  const cands = shuffle(alive().filter(p => !p.gifted)).slice(0, n);
  if (!cands.length) return;
  for (const p of cands) { p.shield = true; p.lucky = true; }
  say('lucky', { names: cands.slice(0, 3).map(speakName).join(', ') }, { prio: 0, ttl: 8 });
  toast(null, `⭐ <b>${T.lucky}</b>: ${cands.map(p => '@' + esc(p.name)).join(', ')} — ${T.luckySub}`);
}

// ---------------- Champion bay trên đường đua ----------------
function makeChampionBumper() {
  const r = C.champion.radius;
  const b = add(Bodies.circle(W / 2, S.camY + H * 0.62, r, { ...stat, restitution: 1.0 }), 'champion', 'primary');
  b.move = (b) => {
    const x = W / 2 + Math.sin(simT * 0.7) * (IW / 2 - r - 10);
    const y = Math.min(S.camY + H * 0.62 + Math.sin(simT * 1.3) * 120, geo.barrierY - 400);
    Body.setPosition(b, { x, y }, true);
  };
  kinematic.push(b);
  return { body: b, sprite: makeSprite(champion), nextWave: C.champion.shockwaveEvery, user: champion };
}
function removeChampion() { if (S.champ) { removeBody(S.champ.body); S.champ = null; } }

// =====================================================================
//  HYPE
// =====================================================================
const HYPE_PHASES = ['race', 'boss', 'ice', 'lava', 'dragon'];   // đấu trường không có hype để công bằng
const canHype = () => S.t > 2 && (HYPE_PHASES.includes(S.phase) || (S.phase === 'fork' && S.fork && !S.fork.voting));
function addHype(v) { if (v > 0) { const before = S.hype; S.hype = Math.min(100, S.hype + v); if (before < 80 && S.hype >= 80 && S.hype < 100) say('hypeNear', {}, { prio: 0, ttl: 5, cooldown: 25 }); if (S.hype >= 100 && canHype()) triggerHype(); } }
function nextEventName() { const ev = C.hype.events; return ev.length ? ev[S.hypeIdx % ev.length] : null; }
function triggerHype() {
  S.hype = 0; play('hype');
  if (S.boss && !S.boss.dead) { say('megaBonk', {}, { prio: 2, ttl: 5 }); banner(T.maxHype, `-${C.hype.bossDamage} ${S.boss.type === 'dragon' ? T.dragonName : T.bossName}`); hitBoss(C.hype.bossDamage, null, T.maxHype); return; }
  if (S.phase === 'lava' && S.lava) {   // ở Dung Nham, hype cứu cả phòng: đóng băng dung nham
    S.lava.freeze = C.balance.roomEventSeconds; say('lavaFreeze', {}, { prio: 2, ttl: 5 });
    banner(T.hypeBy, `HYPE! ${T.lavaFrozen}`); return;
  }
  const ev = nextEventName(); if (!ev) return; S.hypeIdx++;
  banner(T.hypeBy, `HYPE! ${T.events[ev] || ev}`);
  EVENTS[ev]?.();
  say('hype_' + ev, {}, { prio: 2, ttl: 5, interrupt: true });
}
const inView = p => p.body.position.y > S.camY + 150 && p.body.position.y < S.camY + H - 250;
const EVENTS = {
  meteor() { for (const p of shuffle(alive().filter(inView)).slice(0, 10)) S.crosshairs.push({ p, t: 1.1 }); },
  hurricane() { S.wind = 3.5; },
  antigravity() { S.gravityTimer = 1.4; engine.gravity.y = -0.7 * C.course.gravity; },
  earthquake() { S.quake = 2.5; },
};
function explode(x, y, rad = 150, power = 16) {
  S.effects.push({ type: 'boom', x, y, t: 0, life: 0.5, r: rad });
  burst(x, y, '#ffb347', 22); S.shake = Math.max(S.shake, 14);
  for (const p of alive()) {
    if (isShielded(p) || p.frozen > 0) continue;
    const dx = p.body.position.x - x, dy = p.body.position.y - y, d = Math.hypot(dx, dy);
    if (d < rad && d > 0.1) { const f = power * (1 - d / rad); Body.setVelocity(p.body, { x: p.body.velocity.x + dx / d * f, y: p.body.velocity.y + dy / d * f - 4 }); }
  }
}

// =====================================================================
//  BOSS (Quỷ Đỏ & Rồng)
// =====================================================================
function startBoss(type) {
  if (type === 'demon') say('bossDemon', {}, { prio: 3, ttl: 8, interrupt: true });
  const n = players.size, D = type === 'dragon' ? C.floors.dragon : C.boss;
  const mult = C.balance.adaptiveBoss ? (difficulty[type] || 1) : 1;
  const hp = Math.max(5, Math.round((D.hpBase + D.hpPerPlayer * n) * mult));
  S.boss = { type, hp, max: hp, chat: D.chatHp, chatMax: D.chatHp, nextAttack: 2, flash: 0, scale: 1, lastBonk: new Map(), dead: false,
    shieldOpen: false, shieldT: type === 'dragon' ? C.floors.dragon.shieldClosed : 0, sweep: null, nextSweep: 3, reflected: new Set(), reflectSum: 0 };
  show('bossHud', 'hype'); ui.hype.style.top = 'calc(var(--hud-top) + 590px)';
  $('#bossHud .side:last-child').textContent = type === 'dragon' ? T.dragonName : T.bossName;
  $('#bossHud .gift').innerHTML = fmtHtml(type === 'dragon' ? T.floorGift?.dragon : T.bossGift);
  $('#bossHud .ghost').textContent = C.balance.ghostDamage > 0 ? fmt(T.ghostTip) : '';
  updateBossHud();
}
const isBonk = text => { const t = text.toLowerCase(); return C.boss.keywords.some(k => t.includes(k.toLowerCase())); };
const words = text => text.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
const hasWord = (text, list) => { const w = words(text); return (list || []).some(k => w.includes(String(k).toLowerCase())); };

function bonk(u, dmg, label, ignoreCooldown, pierce) {
  const B = S.boss; if (!B || B.dead || (S.phase !== 'boss' && S.phase !== 'dragon')) return;
  if (!ignoreCooldown) {
    const now = S.clock, last = B.lastBonk.get(u.id) || -99;
    if (now - last < C.boss.userCooldown) return;
    B.lastBonk.set(u.id, now);
  }
  const p = players.get(u.id);
  const ghost = p && p.dead;
  if (ghost) dmg *= C.balance.ghostDamage;
  const from = (p && p.body && !p.dead) ? { x: p.body.position.x, y: p.body.position.y } : { x: rnd(L + 60, Rr - 60), y: geo.barrierY - (ghost ? 300 : 40) };
  if (B.type === 'dragon' && !B.shieldOpen && !pierce) {
    if (!B.reflected.has(u.id) && B.reflectSum < B.chatMax * 0.06) {
      B.reflected.add(u.id); B.reflectSum += C.floors.dragon.reflectDamage;
      B.chat = Math.max(0, B.chat - C.floors.dragon.reflectDamage);
    }
    S.texts.push({ x: W / 2 + rnd(-200, 200), y: geo.bossY - geo.bossR - 40, text: T.blocked, t: 0, life: 0.8, color: COL['dragon-shield'], size: 28 });
    S.lasers.push({ x: from.x, y: from.y, t: 0, life: 0.2, color: COL['dragon-shield'] });
    updateBossHud(); return;
  }
  S.shots.push({ x: from.x, y: from.y, sx: from.x, sy: from.y, t: 0, life: 0.35, dmg, user: u, label, ghost });
}
function hitBoss(dmg, user, label) {
  const B = S.boss; if (!B || B.dead) return;
  const hpBefore = B.hp / B.max;
  B.hp = Math.max(0, B.hp - dmg); B.flash = 0.15;
  { const r = B.hp / B.max; if (hpBefore > 0.5 && r <= 0.5 && r > 0.2) say('boss50', {}, { prio: 1, ttl: 4 }); if (hpBefore > 0.2 && r <= 0.2 && r > 0) say('boss20', {}, { prio: 2, ttl: 4 }); } S.shake = Math.max(S.shake, 5);
  if (user) { const r = S.dmg.get(user.id) || { dmg: 0, user }; r.dmg += dmg; r.user = user; S.dmg.set(user.id, r); }
  play('bonk');
  S.texts.push({ x: W / 2 + rnd(-160, 160), y: geo.bossY - geo.bossR - 60 + rnd(-30, 30), text: user ? `${user.name} ${label || T.bonk}` : (label || T.bonk), t: 0, life: 1.1, color: COL['accent-2'], size: 30 });
  updateBossHud();
  if (B.hp <= 0) bossDefeated();
}
function adjustDifficulty(type, won) {
  if (!C.balance.adaptiveBoss) return;
  let d = difficulty[type] || 1;
  if (won) d *= (S.boss.chat / S.boss.chatMax > 0.6) ? 1.12 : 1.04; else d *= 0.85;
  difficulty[type] = clamp(d, 0.4, 3); store.set('difficulty', difficulty);
}
function bossDefeated() {
  const B = S.boss; B.dead = true;
  say(B.type === 'dragon' ? 'dragonDown' : 'bossDown', {}, { prio: 3, ttl: 8, interrupt: true });
  adjustDifficulty(B.type, true);
  explode(W / 2, geo.bossY, 260, 10);
  for (let i = 0; i < 4; i++) burst(W / 2 + rnd(-100, 100), geo.bossY + rnd(-100, 100), B.type === 'dragon' ? COL['dragon-color'] : COL['boss-color'], 30);
  removeBody(geo.barrier); geo.barrier = null; removeBody(geo.bossBody); geo.bossBody = null;
  play('win');
  if (B.type === 'demon' && S.plan.length <= 1) { banner(T.chatWinsClassic, T.chatWins, 2.2); setPhase('finish'); return; }
  S.clearTitle = B.type === 'dragon' ? T.dragonDown : T.chatWins;
  floorClear();
}
function bossLost() { adjustDifficulty(S.boss.type, false); say('bossWins', {}, { prio: 3, ttl: 8, interrupt: true }); setPhase('bossWin'); }
function bossAttack() {
  const B = S.boss;
  const targets = alive().filter(p => p.body.position.y < geo.barrierY && p.body.position.y > S.camY + 120);
  const bigs = targets.filter(p => p.big);
  const tgt = bigs.length && Math.random() < 0.5 ? pick(bigs) : (targets.length ? pick(targets) : null);
  const to = tgt ? { x: tgt.body.position.x, y: tgt.body.position.y } : { x: rnd(L + 60, Rr - 60), y: geo.barrierY };
  S.lasers.push({ x: to.x, y: to.y, t: 0, life: 0.3, tgt, kill: C.boss.attackKillsBall });
  B.chat = Math.max(0, B.chat - C.boss.attackDamage);
  if (B.chat / B.chatMax < 0.3) say('chatLow', {}, { prio: 2, ttl: 4, cooldown: 12 });
  play('bossHit'); updateBossHud();
}
function updateBossHud() {
  const B = S.boss; if (!B) return;
  $('#bossHud .bar.chat div').style.width = (B.chat / B.chatMax * 100) + '%';
  $('#bossHud .bar.chat span').textContent = Math.ceil(B.chat);
  $('#bossHud .bar.boss div').style.width = (B.hp / B.max * 100) + '%';
  $('#bossHud .bar.boss span').textContent = Math.ceil(B.hp);
  const cmd = $('#bossHud .cmd');
  if (B.type === 'dragon') {
    cmd.innerHTML = B.shieldOpen ? `🟢 <b>${esc(T.bossKeyword)}</b> ${esc(T.shieldOpen)}` : `🛡 ${esc(T.shieldClosed)}`;
    cmd.style.background = B.shieldOpen ? 'rgba(30,140,70,.85)' : 'rgba(30,60,140,.85)';
  } else { cmd.innerHTML = `${esc(T.bossType)}<b>${esc(T.bossKeyword)}</b>${esc(T.bossAttack)}`; cmd.style.background = ''; }
}

// ---------------- Ngã Ba: bình chọn ----------------
function addVote(u, side, weight) {
  const f = S.fork; if (!f || !f.voting) return;
  const cur = f.votes.get(u.id) || { side: null, w: 1 };
  if (side) cur.side = side;
  if (weight) cur.w += weight;
  if (cur.side) f.votes.set(u.id, cur);
}
function voteTotals() { let l = 0, r = 0; for (const v of S.fork.votes.values()) { if (v.side === 'left') l += v.w; else if (v.side === 'right') r += v.w; } return { l, r }; }
function renderVote() {
  const f = S.fork, { l, r } = voteTotals(), tot = l + r || 1;
  const V = ui.vote;
  V.querySelector('.v-title').textContent = T.voteTitle;
  V.querySelector('.v-time').textContent = f.voting ? `⏱ ${Math.ceil(f.voteLeft)}` : '';
  const [L1, R1] = V.querySelectorAll('.v-side');
  L1.querySelector('.v-name').textContent = '⬅ ' + T.left; R1.querySelector('.v-name').textContent = T.right + ' ➡';
  L1.querySelector('.v-lane').textContent = f.danger === 'left' ? T.laneFast : T.laneSafe;
  R1.querySelector('.v-lane').textContent = f.danger === 'right' ? T.laneFast : T.laneSafe;
  L1.querySelector('.v-pct').textContent = Math.round(l / tot * 100) + '%';
  R1.querySelector('.v-pct').textContent = Math.round(r / tot * 100) + '%';
  L1.classList.toggle('win', f.chosen === 'left'); R1.classList.toggle('win', f.chosen === 'right');
  V.querySelector('.v-hint').innerHTML = `${esc(T.voteHint)}<br>${fmtHtml(T.floorGift?.fork)}`;
}

// ---------------- Hang Băng ----------------
function freeze(p) { say('iceFrozen', {}, { prio: 1, ttl: 5, cooldown: 12 }); p.frozen = C.floors.ice.frozenMax; Body.setVelocity(p.body, { x: 0, y: 0 }); Body.setStatic(p.body, true); }
function thaw(p) {
  if (!p.frozen) return;
  p.frozen = 0; Body.setStatic(p.body, false); Body.setVelocity(p.body, { x: rnd(-2, 2), y: 3 });
  burst(p.body.position.x, p.body.position.y, '#ff9a3a', 14);
}
function thawOne(prefer) {
  if (prefer && prefer.frozen > 0) { thaw(prefer); return prefer; }
  const fr = alive().filter(p => p.frozen > 0).sort((a, b) => a.frozen - b.frozen)[0];
  if (fr) thaw(fr);
  return fr;
}

// ---------------- Sự kiện cả phòng ----------------
function roomEvent(kind, u) {
  if (kind === 'goldRain' || kind === 'mega') say(kind === 'goldRain' || S.phase === 'arena' ? 'goldRain' : 'mega', { name: speakName(u) }, { prio: 3, ttl: 8 });
  if (kind === 'goldRain' || (kind === 'mega' && S.phase === 'arena')) {
    for (const p of alive()) { p.shieldUntil = S.clock + C.balance.roomEventSeconds; if (p.frozen) thaw(p); }
    if (S.lava) S.lava.freeze = C.balance.roomEventSeconds;
    banner(`@${u.name} · ${T.goldRainSub}`, T.goldRain, 2.5);
    for (let i = 0; i < 40; i++) S.particles.push({ x: rnd(0, W), y: S.camY + rnd(-200, 200), vx: rnd(-1, 1), vy: rnd(4, 9), t: 0, life: rnd(1, 2), color: COL['accent-2'], size: rnd(6, 12) });
    return;
  }
  if (kind === 'mega') {
    if (['ice', 'fork', 'lava'].includes(S.phase)) { banner(`@${u.name} · ${T.megaSkip}`, T.mega, 3); floorClear(); }
    else if (S.boss && !S.boss.dead) { banner(`@${u.name} · ${T.megaBoss}`, T.mega, 3); hitBoss(Math.ceil(S.boss.max * 0.2), u, T.mega); }
    else if (S.phase === 'race' && C.boss.enabled) { banner(`@${u.name}`, T.mega, 3); setPhase('boss'); }
    else roomEvent('goldRain', u);
  }
}

// ---------------- Quà ----------------
function giftRule(g) {
  if (C.gifts.byName && C.gifts.byName[g.name]) return C.gifts.byName[g.name];
  let r = null;
  for (const t of C.gifts.tiers) if ((g.diamonds || 0) >= t.minDiamonds) r = t;
  return r;
}
function reviveThreshold() { const t = C.gifts.tiers.filter(x => x.action === 'revive').map(x => x.minDiamonds); return t.length ? Math.min(...t) : Infinity; }
function applyGift(u, g) {
  const rule = giftRule(g) || { action: 'none', room: '', bossDamage: 0, hype: (g.diamonds || 1) * C.hype.perDiamond, voteWeight: 1 };
  const count = g.count || 1, mult = C.gifts.multiplyByCount ? count : 1;
  if (C.players.joinOnGift) tryJoin(u);
  addHype((rule.hype ?? (g.diamonds || 1) * C.hype.perDiamond) * mult);
  const p = players.get(u.id);
  if (p) p.gifted = true;
  if (S.boss && !S.boss.dead && rule.bossDamage) bonk(u, rule.bossDamage * mult, `${g.name} x${count}`, true, true);
  if (S.fork && S.fork.voting && S.phase === 'fork') addVote(u, null, (rule.voteWeight || 1) * mult);
  const labels = [];
  if (p && p.dead) {
    if ((g.diamonds || 0) * count >= reviveThreshold() && revive(p)) labels.push(T.giftRevive);
  } else if (p && p.body && !['lobby', 'result', 'bossWin'].includes(S.phase)) {
    if (p.frozen > 0) { thaw(p); labels.push(T.giftThaw); }
    const uses = p.uses[rule.action] || 0;
    const dim = C.balance.diminishing || [1];
    const f = dim[Math.min(uses, dim.length - 1)];
    p.uses[rule.action] = uses + 1;
    if (rule.action === 'boost') { p.boost = 2.5 * f; Body.setVelocity(p.body, { x: p.body.velocity.x * 0.3, y: 8 + 14 * f }); labels.push(T.giftBoost); }
    else if (rule.action === 'big' && !p.big) { p.big = true; Body.scale(p.body, 1.5, 1.5); p.r *= 1.5; labels.push(T.giftBig); }
    else if ((rule.action === 'shield' || rule.action === 'revive') && !p.shield) { p.shield = true; labels.push(T.giftShield); }
  }
  if (rule.room) roomEvent(rule.room, u);
  if ((g.diamonds || 0) * count >= (vcfg().giftMin ?? 1)) voiceGift(u, g.name, labels.map(spokenLabel).filter(Boolean).join(', '));
  toast(u, `<b>@${esc(u.name)}</b> ${giftIconHtml(g.image || rule.icon)}${esc(g.name)} x${count}${labels.length ? ' → <b>' + labels.map(esc).join(' ') + '</b>' : ''}`);
}

// =====================================================================
//  SỰ KIỆN TỪ TIKTOK
// =====================================================================
function handle(ev) {
  const u = ev.user;
  switch (ev.type) {
    case 'chat': {
      const text = ev.text || '';
      if ((S.phase === 'boss' || S.phase === 'dragon') && isBonk(text)) bonk(u, C.boss.damagePerBonk);
      if (S.phase === 'ice' && hasWord(text, C.floors.ice.keywords)) {
        const t = thawOne(players.get(u.id));
        if (t) { S.texts.push({ x: t.body.position.x, y: t.body.position.y - 40, text: `🔥 ${u.name}`, t: 0, life: 1, color: '#ff9a3a', size: 24 }); say('iceThaw', { name: speakName(u) }, { prio: 0, ttl: 4, cooldown: 8 }); }
      }
      if (S.phase === 'fork' && S.fork?.voting) {
        if (hasWord(text, C.floors.fork.keywordsLeft)) addVote(u, 'left');
        else if (hasWord(text, C.floors.fork.keywordsRight)) addVote(u, 'right');
      }
      if (C.players.joinOnComment) {
        const kw = C.players.joinKeywords;
        if (!kw.length || kw.some(k => text.toLowerCase().includes(k.toLowerCase()))) tryJoin(u);
      }
      addHype(C.hype.perComment);
      break;
    }
    case 'like': {
      const n = ev.count || 1;
      addHype(n * C.hype.perLike);
      if (C.players.joinOnLike) tryJoin(u);
      if (S.phase === 'ice' && S.ice) { S.ice.likes += n; while (S.ice.likes >= C.floors.ice.likesPerThaw) { S.ice.likes -= C.floors.ice.likesPerThaw; thawOne(); } }
      if (S.phase === 'lava' && S.lava) S.lava.rate += n;
      break;
    }
    case 'follow': say('follow', { name: speakName(u) }, { prio: 0, ttl: 5, cooldown: 6 }); addHype(C.hype.perFollow); if (C.players.joinOnFollow) tryJoin(u); toast(u, `<b>@${esc(u.name)}</b> followed! +HYPE`); break;
    case 'share': say('share', { name: speakName(u) }, { prio: 0, ttl: 5, cooldown: 6 }); addHype(C.hype.perShare); toast(u, `<b>@${esc(u.name)}</b> shared! +HYPE`); break;
    case 'gift': applyGift(u, ev.gift); break;
    case 'status': ui.status.textContent = ev.text; ui.status.className = 'hide-when-connected ' + ev.state; break;
  }
}
function connectWS() {
  if (location.protocol === 'file:') return;
  const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  ws.onmessage = e => { try { handle(JSON.parse(e.data)); } catch (err) { console.error(err); } };
  ws.onclose = () => setTimeout(connectWS, 2000);
}
if (!APP) connectWS();

// =====================================================================
//  CẬP NHẬT THEO KHUNG HÌNH
// =====================================================================
const STEP = 1 / 120;
let acc = 0, last = performance.now(), uiTimer = 0, assistTimer = 0;
const RACE_LIKE = ['race', 'ice', 'lava', 'fork', 'finish'];

function physicsStep() {
  stepKinematic(STEP);
  for (const p of alive()) {
    const b = p.body; if (b.isStatic) continue;
    const v = b.velocity; let vx = v.x, vy = v.y;
    if (S.wind > 0 && !isShielded(p)) vx += Math.sin(simT * 2.2 + b.position.y * 0.004) * 0.9;
    if (p.boost > 0) vy = Math.max(vy, 9);
    if (p.assist && vy < 10) vy += C.balance.catchUp;
    const sp = Math.hypot(vx, vy);
    if (sp > 24) { vx *= 24 / sp; vy *= 24 / sp; }
    if (vx !== v.x || vy !== v.y) Body.setVelocity(b, { x: vx, y: vy });
  }
  Engine.update(engine, STEP * 1000);
}

const UPDATE = {
  lobby(dt) {
    S.timeLeft -= dt;
    if (players.size >= C.players.max) S.timeLeft = Math.min(S.timeLeft, 0);
    if (S.timeLeft <= 0) { S.timeLeft = 0; if (players.size >= Math.max(1, C.timing.lobbyMinPlayers)) setPhase('start'); }
    if (S.t > VO.lobbyNext) {
      VO.lobbyNext = S.t + (vcfg().lobbyGuideEvery || 18);
      const keys = S.plan.length > 1 ? ['lobbyGuide1', 'lobbyGuide2', 'lobbyGuide3'] : ['lobbyGuide1', 'lobbyGuide2'];
      say(keys[VO.lobbyIdx++ % keys.length], { n: S.plan.length }, { prio: 0, ttl: 12 });
    }
    if (!VO.soonSaid && S.timeLeft <= 10.5 && S.timeLeft > 8 && C.timing.lobby > 15) { VO.soonSaid = true; say('lobbySoon', {}, { prio: 1, ttl: 5 }); }
  },
  start(dt) {
    S.timeLeft -= dt;
    const n = Math.ceil(S.timeLeft);
    if (n !== S.lastCount) { S.lastCount = n; ui.count.textContent = n > 0 ? n : T.start; ui.count.classList.remove('tick'); void ui.count.offsetWidth; ui.count.classList.add('tick'); }
    if (!VO.cdSaid && S.timeLeft <= 3.6 && vcfg().countdown !== false) { VO.cdSaid = true; say('countdown', {}, { prio: 3, ttl: 4, interrupt: true }); }
    if (S.timeLeft <= 0) setPhase('race');
  },
  race(dt) {
    S.raceTime += dt;
    const lead = leader();
    if (lead && lead !== VO.lastLeader && S.t > 5) { VO.lastLeader = lead; say('leader', { name: speakName(lead) }, { prio: 1, ttl: 4, cooldown: vcfg().leaderEvery || 9, replace: true }); }
    if (C.boss.enabled && lead && lead.body.position.y > geo.barrierY - 160) setPhase('boss');
    else if (!C.boss.enabled && lead && lead.body.position.y > geo.finishY) finishWith(lead);
    else if (C.boss.enabled && S.t > C.timing.raceMax) setPhase('boss');
    else if (!alive().length) fail('wipe');
  },
  boss(dt) {
    S.raceTime += dt;
    const B = S.boss;
    B.nextAttack -= dt;
    if (B.nextAttack <= 0 && !B.dead) { B.nextAttack = C.boss.attackEvery; bossAttack(); }
    if (!B.dead && (B.chat <= 0 || S.t > C.timing.bossMax || !alive().length)) bossLost();
  },
  clear(dt) { S.raceTime += dt; if (S.t > (C.timing.clear ?? 4)) { S.floorIdx++; setPhase('transition'); } },
  transition(dt) {
    S.timeLeft -= dt;
    ui.floorIntro.querySelector('.fi-bar i').style.width = (100 * (1 - S.timeLeft / C.tower.transition)) + '%';
    if (S.timeLeft <= 0) { ui.floorIntro.classList.add('hidden'); setPhase(curFloor()); }
  },
  ice(dt) {
    S.raceTime += dt;
    const F = C.floors.ice, I = S.ice;
    setHint(fmt(T.iceDo));
    I.next -= dt;
    if (I.next <= 0) { I.next = F.icicleEvery * rnd(0.6, 1.4); I.icicles.push({ x: rnd(L + 40, Rr - 40), y: S.camY - 40, vy: 0 }); }
    for (const c of I.icicles) {
      c.vy += 1700 * dt; c.y += c.vy * dt;
      for (const p of alive()) {
        if (p.frozen > 0) continue;
        if (Math.hypot(p.body.position.x - c.x, p.body.position.y - c.y) < p.r + 14) {
          c.hit = true; burst(c.x, c.y, COL.ice, 10);
          if (!hitShield(p)) freeze(p);
          break;
        }
      }
    }
    I.icicles = I.icicles.filter(c => !c.hit && c.y < S.camY + H + 100);
    for (const p of alive()) if (p.frozen > 0) { p.frozen -= dt; if (p.frozen <= 0) { burst(p.body.position.x, p.body.position.y, COL.ice, 20); killBall(p, false); } }
    stageExit(dt, F.tail, F.max);
  },
  fork(dt) {
    const f = S.fork;
    if (f.voting) {
      f.voteLeft -= dt; renderVote();
      if (f.voteLeft <= 0) {
        const { l, r } = voteTotals();
        const side = l === r ? (Math.random() < 0.5 ? 'left' : 'right') : (l > r ? 'left' : 'right');
        openFork(side); renderVote();
        setTimeout(() => { if (S.phase === 'fork') show('top3', 'timer', 'hype', 'floorBadge', 'hint'); }, 1500);
        setHint(`${side === 'left' ? '⬅ ' + esc(T.left) : esc(T.right) + ' ➡'} · ${esc(side === f.danger ? T.laneFast : T.laneSafe)}`, side === f.danger);
        setGiftLine(fmtHtml(T.floorGift?.race));
      }
      return;
    }
    S.raceTime += dt; f.t += dt;
    stageExit(dt, 8, C.floors.fork.timeLimit, f.t);
  },
  lava(dt) {
    S.raceTime += dt;
    const F = C.floors.lava, V = S.lava;
    V.t += dt;
    if (V.delay > 0) V.delay -= dt;
    else {
      let sp = F.speed + F.accel * V.t;
      V.rate *= Math.exp(-dt);   // số tim/giây (trung bình trượt)
      V.mult = clamp(1 - V.rate * F.slowPerLike, 1 - F.slowMax, 1);
      sp *= V.mult;
      if (V.freeze > 0) { sp = 0; V.freeze -= dt; }
      V.y = Math.min(V.y + sp * dt, geo.exitY - 40);
    }
    const slowPct = Math.round((1 - (V.mult ?? 1)) * 100);
    if (slowPct >= 15 && !V.slowSaid) { V.slowSaid = true; say('lavaSlow', {}, { prio: 0, ttl: 4, cooldown: 15 }); } else if (slowPct < 5) V.slowSaid = false;
    setHint(V.freeze > 0 ? `❄ ${esc(T.lavaFrozen)}` : slowPct >= 5 ? `❤ ${esc(T.lavaSlow)} <b>-${slowPct}%</b>` : esc(T.lavaDo), slowPct < 5 && V.freeze <= 0);
    for (const p of alive()) {
      if (p.body.position.y - p.r < V.y) {
        if (hitShield(p)) { Body.setPosition(p.body, { x: p.body.position.x, y: V.y + p.r + 40 }); Body.setVelocity(p.body, { x: 0, y: 12 }); }
        else { burst(p.body.position.x, p.body.position.y, COL.lava, 18); killBall(p, false); }
      }
    }
    const al = alive();
    if (!al.length) return fail('wipe');
    if (al.every(p => p.body.position.y > geo.exitY) || V.y >= geo.exitY - 40 || S.t > F.max) cutoff(geo.exitY);
  },
  dragon(dt) {
    S.raceTime += dt;
    const B = S.boss, D = C.floors.dragon;
    if (B.dead) return;
    B.shieldT -= dt;
    if (B.shieldT <= 0) { B.shieldOpen = !B.shieldOpen; B.shieldT = B.shieldOpen ? D.shieldOpen : D.shieldClosed;
      if (B.shieldOpen) say('shieldOpen', {}, { prio: 3, ttl: 2.5, interrupt: true, replace: true }); else say('shieldClosed', {}, { prio: 2, ttl: 2, replace: true, cooldown: 10 }); B.reflected.clear(); B.reflectSum = 0; updateBossHud(); }
    B.nextSweep -= dt;
    if (!B.sweep && B.nextSweep <= 0) {
      const al = alive().filter(p => p.body.position.y < geo.barrierY);
      const y = al.length ? pick(al).body.position.y : geo.barrierY - 100;
      B.sweep = { y, h: 100, t: 0, warn: 1.0, fire: 0.6, done: false };
      say('sweep', {}, { prio: 1, ttl: 2, cooldown: 9 });
    }
    if (B.sweep) {
      const sw = B.sweep; sw.t += dt;
      if (sw.t > sw.warn && !sw.done) {
        sw.done = true; S.shake = 12; play('bossHit');
        const inBand = shuffle(alive().filter(p => Math.abs(p.body.position.y - sw.y) < sw.h / 2));
        const maxKill = Math.ceil(alive().length * D.sweepKill);
        let k = 0; for (const p of inBand) { if (k >= maxKill) break; if (hitKill(p)) k++; }
        B.chat = Math.max(0, B.chat - D.sweepDamage); updateBossHud();
      }
      if (sw.t > sw.warn + sw.fire) { B.sweep = null; B.nextSweep = D.sweepEvery; }
    }
    if (B.chat <= 0 || S.t > D.max || !alive().length) bossLost();
  },
  arena(dt) {
    S.raceTime += dt;
    const F = C.floors.arena, A = S.arena;
    A.t += dt;
    const targetW = F.startWidth + (F.minWidth - F.startWidth) * Math.min(1, A.t / F.time);
    if (Math.abs(targetW - geo.platW) > 2) { Body.scale(geo.platform, targetW / geo.platW, 1); geo.platW = targetW; }
    A.nextShove -= dt;
    if (A.nextShove <= 0) {
      A.nextShove = F.shoveEvery; A.dir *= -1; S.shake = 8;
      S.effects.push({ type: 'shove', dir: A.dir, t: 0, life: 0.6 });
      for (const p of alive()) if (!isShielded(p)) Body.setVelocity(p.body, { x: p.body.velocity.x + A.dir * rnd(0.5, 1) * F.shovePower, y: p.body.velocity.y - 3 });
    }
    const al = alive();
    setHint(`👑 ${esc(T.arenaHint)} · <b>${al.length}</b> ${esc(T.alive)}`);
    if ([10, 5, 3, 2].includes(al.length) && VO.arenaLast !== al.length) { VO.arenaLast = al.length; say('arenaLeft', { n: al.length }, { prio: 1, ttl: 3, replace: true }); }
    if (al.length <= 1) { const w = al[0] || S.lastDead; if (w) finishWith(w); else fail('wipe'); }
    else if (A.t > F.time + 15) finishWith(al.sort((a, b) => Math.abs(a.body.position.x - W / 2) - Math.abs(b.body.position.x - W / 2))[0]);
  },
  finish(dt) {
    S.raceTime += dt;
    const lead = leader();
    if (lead && lead.body.position.y > geo.finishY) finishWith(lead);
    else if (S.t > C.timing.finishMax || !alive().length) fail('wipe');
  },
  bossWin(dt) {
    S.boss.scale = Math.min(1.35, S.boss.scale + dt * 0.4);
    for (const p of alive()) {
      const b = p.body; if (b.isStatic) Body.setStatic(b, false);
      const dx = W / 2 - b.position.x, dy = geo.bossY - b.position.y, d = Math.hypot(dx, dy);
      if (d < geo.bossR * 1.1) { killBall(p, false); continue; }
      b.collisionFilter.mask = 0;
      const sp = Math.min(30, 6 + S.t * 14);
      Body.setVelocity(b, { x: dx / d * sp, y: dy / d * sp });
    }
    if (S.t > 2.5) fail('boss');
  },
  result(dt) {
    S.timeLeft -= dt;
    $('#result .r-next').textContent = `${T.nextRace} ${Math.max(0, Math.ceil(S.timeLeft))}`;
    if (S.timeLeft <= 0) setPhase('lobby');
  },
};
// điều kiện qua tầng chung cho Hang Băng / Ngã Ba
function stageExit(dt, tail, maxT, tNow = S.t) {
  const st = S[curFloor()] || {};
  const al = alive();
  if (!al.length) return fail('wipe');
  const arrived = al.filter(p => p.body.position.y > geo.exitY).length;
  if (arrived && st.firstIn == null) st.firstIn = tNow;
  // đồng hồ loại người chỉ chạy khi đã có một nửa số bi về đích (hoặc 25s sau viên đầu tiên)
  if (st.tail == null && st.firstIn != null && (arrived >= al.length * 0.5 || tNow - st.firstIn > 25)) st.tail = tail;
  if (st.tail != null) st.tail -= dt;
  const allIn = al.every(p => p.body.position.y > geo.exitY && !(p.frozen > 0));
  if (allIn || (st.tail != null && st.tail <= 0) || tNow > maxT) cutoff(geo.exitY);
}

function update(dt) {
  S.t += dt; S.clock += dt;
  const ph = S.phase;
  UPDATE[ph]?.(dt);
  if (S.hype >= 100 && canHype()) triggerHype();

  if (S.gravityTimer > 0) { S.gravityTimer -= dt; if (S.gravityTimer <= 0) engine.gravity.y = C.course.gravity; }
  if (S.wind > 0) S.wind -= dt;
  if (S.quake > 0) {
    S.quake -= dt; S.shake = Math.max(S.shake, 10);
    if (Math.random() < dt * 8) for (const p of alive()) if (!isShielded(p) && !p.frozen) Body.setVelocity(p.body, { x: p.body.velocity.x + rnd(-7, 7), y: p.body.velocity.y - rnd(2, 8) });
  }
  // đẩy nhẹ nhóm cuối
  assistTimer -= dt;
  if (assistTimer <= 0) {
    assistTimer = 0.5;
    const al = alive();
    const active = RACE_LIKE.includes(ph) && !(ph === 'fork' && S.fork?.voting) && C.balance.catchUp > 0;
    al.forEach(p => p.assist = false);
    if (active && al.length > 6) al.sort((a, b) => a.body.position.y - b.body.position.y).slice(0, Math.ceil(al.length * 0.15)).forEach(p => p.assist = true);
  }
  for (const p of alive()) {
    if (p.boost > 0) p.boost -= dt;
    if (p.raining && p.body.position.y > geo.barrierY - 220) { p.raining = false; p.body.collisionFilter.mask = 0xFFFF; }
    if (RACE_LIKE.includes(ph) && !p.frozen) {
      const sp = Math.hypot(p.body.velocity.x, p.body.velocity.y);
      p.still = sp < 0.4 ? p.still + dt : 0;
      if (p.still > 4) { p.still = 0; Body.setVelocity(p.body, { x: rnd(-6, 6), y: -6 }); }
    }
    const pos = p.body.position;
    if (pos.y > (geo.floorY ?? 99999) + 200 || pos.x < -80 || pos.x > W + 80) killBall(p, false);
  }
  for (const c of S.crosshairs) { c.t -= dt; if (c.t <= 0 && !c.done) { c.done = true; if (c.p.body && !c.p.dead) explode(c.p.body.position.x, c.p.body.position.y); } }
  S.crosshairs = S.crosshairs.filter(c => !c.done);
  for (const s of S.shots) {
    s.t += dt; const k = Math.min(1, s.t / s.life);
    s.x = s.sx + (W / 2 - s.sx) * k; s.y = s.sy + (geo.bossY - s.sy) * k - Math.sin(k * Math.PI) * 120;
    if (k >= 1 && !s.done) { s.done = true; hitBoss(s.dmg, s.user, s.label); burst(s.x, s.y, COL['bonk-shot'], 8); }
  }
  S.shots = S.shots.filter(s => !s.done);
  for (const l of S.lasers) { l.t += dt; if (l.t >= l.life && !l.done) { l.done = true; if (l.tgt && l.kill && !l.tgt.dead) hitKill(l.tgt); else burst(l.x, l.y, l.color || COL.laser, 8); } }
  S.lasers = S.lasers.filter(l => l.t < l.life + 0.15);
  for (const q of S.particles) { q.t += dt; q.x += q.vx; q.y += q.vy; q.vy += 0.3; }
  S.particles = S.particles.filter(q => q.t < q.life);
  for (const x of S.texts) { x.t += dt; x.y -= 40 * dt; }
  S.texts = S.texts.filter(x => x.t < x.life);
  for (const e of S.effects) e.t += dt;
  S.effects = S.effects.filter(e => e.t < e.life);
  if (S.boss) S.boss.flash = Math.max(0, S.boss.flash - dt);
  S.shake *= 0.88;

  if (S.champ) {
    S.champ.nextWave -= dt;
    if (S.champ.nextWave <= 0) {
      S.champ.nextWave = C.champion.shockwaveEvery;
      const { x, y } = S.champ.body.position;
      S.effects.push({ type: 'wave', x, y, t: 0, life: 0.8, r: 360 });
      for (const p of alive()) {
        const dx = p.body.position.x - x, dy = p.body.position.y - y, d = Math.hypot(dx, dy);
        if (d < 360 && d > 1 && !isShielded(p)) Body.setVelocity(p.body, { x: p.body.velocity.x + dx / d * 11, y: p.body.velocity.y + dy / d * 11 });
      }
    }
  }

  // camera
  let target = S.camY;
  const lead = leader();
  if (ph === 'lobby' || ph === 'start' || ph === 'transition' || ph === 'dragon' || ph === 'arena') target = 0;
  else if (ph === 'race' || ph === 'ice' || ph === 'finish' || (ph === 'fork' && !S.fork.voting)) {
    target = lead ? lead.body.position.y - H * 0.42 : S.camY;
    if (ph === 'finish') target = Math.max(target, geo.camMax);
  } else if (ph === 'fork') target = 0;
  else if (ph === 'lava') target = Math.max(S.lava.y - 260, lead ? lead.body.position.y - H * 0.8 : 0);
  else if (ph === 'boss' || ph === 'bossWin') target = geo.camMax;
  target = clamp(target, 0, Math.max(0, geo.camMax ?? 0));
  S.camY += (target - S.camY) * Math.min(1, dt * 4);
  if (ph === 'transition') S.camY = 0;

  uiTimer -= dt;
  if (uiTimer <= 0) { uiTimer = 0.1; updateHud(); }
}

function leader() { let best = null; for (const p of alive()) if (!p.frozen && (!best || p.body.position.y > best.body.position.y)) best = p; return best; }
function finishWith(p) {
  S.winner = p;
  wins[p.id] = (wins[p.id] || 0) + 1; store.set('wins', wins);
  champion = { id: p.id, name: p.name, nick: p.nick, avatar: p.avatar, wins: wins[p.id] }; store.set('champion', champion);
  if (p.body) burst(p.body.position.x, p.body.position.y, COL['accent-2'], 40);
  play('win');
  setPhase('result');
}
function mvp() { let best = null; for (const r of S.dmg.values()) if (!best || r.dmg > best.dmg) best = r; return best; }
function showResult() {
  const r = ui.result, img = r.querySelector('.r-avatar');
  show('result');
  r.className = S.winner ? 'win' : 'lose';
  const towerInfo = S.plan.length > 1 ? `${T.reached} ${S.floorReached}/${S.plan.length} · 🏆 ${T.record} ${bestFloor}` : '';
  if (S.winner) {
    r.querySelector('.r-title').textContent = T.winner;
    r.querySelector('.r-sub').textContent = '';
    img.src = S.winner.avatar || S.winner.sprite.toDataURL(); img.classList.remove('hidden');
    r.querySelector('.r-name').textContent = '@' + S.winner.name;
    r.querySelector('.r-wins').textContent = `${wins[S.winner.id]} ${T.wins}`;
  } else {
    const t = S.failKind === 'boss' ? T.bossWins : S.failKind === 'wipe' ? T.eliminated : T.noWinner;
    r.querySelector('.r-title').textContent = t;
    r.querySelector('.r-sub').textContent = S.failKind === 'boss' ? T.bossWinsSub : S.failKind === 'wipe' ? T.eliminatedSub : '';
    img.classList.add('hidden'); r.querySelector('.r-name').textContent = ''; r.querySelector('.r-wins').textContent = '';
  }
  r.querySelector('.r-floor').textContent = towerInfo;
  const m = mvp();
  r.querySelector('.r-mvp').innerHTML = m ? `⚔ ${esc(T.mvp)}: <b>@${esc(m.user.name)}</b> — ${Math.round(m.dmg)} ${esc(T.damage)}` : '';
  r.querySelector('.r-mvp').style.display = m ? '' : 'none';
  r.querySelector('.r-join').textContent = T.joinNext;
  if (S.winner) say('winner', { name: speakName(S.winner) }, { prio: 3, ttl: 10, interrupt: true });
  else if (S.failKind === 'wipe') say('fail', {}, { prio: 3, ttl: 8, interrupt: true });
  if (m) say('mvp', { name: speakName(m.user) }, { prio: 2, ttl: 10 });
  say('joinNext', {}, { prio: 1, ttl: 15 });
}

let lastTop = '';
function updateHud() {
  const ph = S.phase;
  if (ph === 'lobby') { updateLobby(); rotateLobbyGuide(); }
  ui.floorBadge.innerHTML = floorLabel();
  {
    const hasGift = !!ui.hint.querySelector('.g-gift').innerHTML && C.guide?.guideBar !== false;
    const warn = ui.hint.classList.contains('warn');
    ui.hint.classList.toggle('rot', hasGift);
    ui.hint.classList.toggle('show-gift', hasGift && !warn && Math.floor(S.clock / (C.guide?.rotateSeconds || 5)) % 2 === 1);
  }
  if (RACE_LIKE.includes(ph) || ph === 'arena') {
    const top = alive().sort((a, b) => b.body.position.y - a.body.position.y).slice(0, 3);
    const key = top.map(p => p.id).join('|');
    if (key !== lastTop) {
      lastTop = key; ui.top3.innerHTML = '';
      top.forEach((p, i) => {
        const row = document.createElement('div'); row.className = 'top-row';
        row.innerHTML = `<div class="top-rank">${i + 1}</div>`;
        row.appendChild(avatarEl(p));
        const n = document.createElement('div'); n.className = 'top-name'; n.textContent = '@' + p.name; row.appendChild(n);
        ui.top3.appendChild(row);
      });
    }
    const s = Math.floor(S.raceTime);
    ui.timer.innerHTML = `⏱ ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}${S.plan.length > 1 ? `<small>${esc(T.floor)} ${S.floorIdx + 1}/${S.plan.length}</small>` : ''}`;
  }
  const ev = nextEventName();
  ui.hype.querySelector('.hype-label').textContent = (S.boss && !S.boss.dead) ? `${T.hypeLabel} > MEGA ${T.bossKeyword}` : `${T.hypeLabel} > ${(T.events[ev] || ev || '').toUpperCase()}`;
  ui.hype.querySelector('.hype-fill').style.width = S.hype + '%';
  ui.hype.querySelector('.hype-pct').textContent = S.hype >= 100 ? T.maxHype : Math.floor(S.hype) + '%';
  ui.hype.classList.toggle('full', S.hype >= 100);
}

// =====================================================================
//  VẼ
// =====================================================================
const cv = $('#game'), ctx = cv.getContext('2d');

function drawBody(b) {
  if (b.kind === 'saw') {
    const { x, y } = b.position, r = b.circleRadius;
    ctx.save(); ctx.translate(x, y); ctx.rotate(simT * 9);
    ctx.fillStyle = COL.saw; ctx.beginPath();
    for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2, rr = i % 2 ? r : r * 0.75; ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#ddd'; ctx.beginPath(); ctx.arc(0, 0, r * 0.3, 0, Math.PI * 2); ctx.fill();
    ctx.restore(); return;
  }
  const parts = b.parts.length > 1 ? b.parts.slice(1) : [b];
  ctx.fillStyle = COL[b.color] || b.color || '#888';
  for (const part of parts) {
    if (part.circleRadius && b.kind !== 'champion' && b.kind !== 'boss' && b.kind !== 'dragon') {
      ctx.beginPath(); ctx.arc(part.position.x, part.position.y, part.circleRadius, 0, Math.PI * 2); ctx.fill();
      if (b.kind === 'peg') {
        ctx.lineWidth = 3; ctx.strokeStyle = b.color === 'ice' ? '#5aa9d6' : COL['peg-edge']; ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.beginPath(); ctx.arc(part.position.x - 4, part.position.y - 4, part.circleRadius * 0.35, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = COL[b.color];
      }
      continue;
    }
    const v = part.vertices;
    ctx.beginPath(); ctx.moveTo(v[0].x, v[0].y);
    for (let i = 1; i < v.length; i++) ctx.lineTo(v[i].x, v[i].y);
    ctx.closePath(); ctx.fill();
    if (b.kind === 'ramp') { ctx.lineWidth = 4; ctx.strokeStyle = COL['ramp-edge']; ctx.stroke(); }
    if (b.kind === 'iceRamp') { ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(255,255,255,.8)'; ctx.stroke(); }
    if (b.kind === 'platform') { ctx.save(); ctx.shadowColor = COL['arena-floor']; ctx.shadowBlur = 30; ctx.fill(); ctx.restore(); ctx.lineWidth = 4; ctx.strokeStyle = '#fff'; ctx.stroke(); }
  }
  if (b.kind === 'spinner' || b.kind === 'seesaw') {
    ctx.fillStyle = COL['spinner-hub']; ctx.beginPath(); ctx.arc(b.position.x, b.position.y, 11, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(b.position.x, b.position.y, 4, 0, Math.PI * 2); ctx.fill();
  }
  if (b.kind === 'hammer') { ctx.fillStyle = COL['spinner-hub']; ctx.beginPath(); ctx.arc(b.pivot.x, b.pivot.y, 14, 0, Math.PI * 2); ctx.fill(); }
  if (b.kind === 'bouncer') {
    ctx.save(); ctx.translate(b.position.x, b.position.y); ctx.rotate(b.angle);
    ctx.strokeStyle = 'rgba(255,255,255,.8)'; ctx.lineWidth = 3;
    for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(i * 45 - 12, 24); ctx.lineTo(i * 45, 12); ctx.lineTo(i * 45 + 12, 24); ctx.stroke(); }
    ctx.restore();
  }
}

function dots(y0, y1, color, step = 90) {
  ctx.fillStyle = color;
  for (let y = Math.floor(y0 / step) * step; y < y1; y += step)
    for (let x = (y / step) % 2 ? step / 2 : 0; x < W; x += step) { ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill(); }
}
function drawBackground(y0) {
  const y1 = y0 + H;
  if (S.bg === 'ice') { ctx.fillStyle = COL['ice-bg']; ctx.fillRect(0, y0, W, H); dots(y0, y1, 'rgba(255,255,255,.8)', 70); return; }
  if (S.bg === 'dragon') {
    const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, COL['dragon-bg']); g.addColorStop(1, '#000');
    ctx.fillStyle = g; ctx.fillRect(0, y0, W, H);
    if (imgOk(IMG.bossBg)) { ctx.globalAlpha = 0.8; ctx.drawImage(IMG.bossBg, 0, y0, W, H); ctx.globalAlpha = 1; }
    return;
  }
  if (S.bg === 'arena') {
    ctx.fillStyle = COL['arena-bg']; ctx.fillRect(0, y0, W, H);
    const g = ctx.createRadialGradient(W / 2, y0 + 1100, 50, W / 2, y0 + 1100, 700);
    g.addColorStop(0, 'rgba(255,255,255,.18)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0, y0, W, H); return;
  }
  // khu đua + khu boss (tầng 1)
  const bossTop = geo.barrierY && S.plan[S.floorIdx] === 'race' ? geo.barrierY - 420 : Infinity;
  if (y0 < bossTop) {
    ctx.fillStyle = COL.bg; ctx.fillRect(0, y0, W, Math.min(H, bossTop - y0));
    if (imgOk(IMG.bg)) {
      const ih = IMG.bg.naturalHeight * (W / IMG.bg.naturalWidth);
      for (let y = Math.floor(y0 / ih) * ih; y < Math.min(y1, bossTop); y += ih) ctx.drawImage(IMG.bg, 0, y, W, ih);
    } else dots(y0, Math.min(y1, bossTop), COL['bg-dots']);
  }
  if (y1 > bossTop) {
    const g = ctx.createLinearGradient(0, bossTop, 0, geo.floorY);
    g.addColorStop(0, COL.bg); g.addColorStop(0.18, COL['boss-bg-2']); g.addColorStop(1, COL['boss-bg']);
    ctx.fillStyle = g; ctx.fillRect(0, Math.max(y0, bossTop), W, H);
    if (imgOk(IMG.bossBg)) { ctx.globalAlpha = 0.9; ctx.drawImage(IMG.bossBg, 0, geo.camMax, W, H); ctx.globalAlpha = 1; }
  }
}

function drawDemon() {
  const B = S.boss;
  if (B && B.dead) return;
  if (!geo.bossBody && !(B && B.type === 'demon')) return;
  const r = geo.bossR * (B ? B.scale : 1), sx = (B && B.flash > 0) ? rnd(-6, 6) : 0;
  ctx.save(); ctx.translate(W / 2 + sx, geo.bossY);
  const pulse = 1 + Math.sin(S.t * 5) * 0.05;
  ctx.fillStyle = 'rgba(255,60,40,.18)'; ctx.beginPath(); ctx.arc(0, 0, r * 1.35 * pulse, 0, Math.PI * 2); ctx.fill();
  if (imgOk(IMG.boss)) ctx.drawImage(IMG.boss, -r, -r, r * 2, r * 2);
  else {
    ctx.fillStyle = COL['boss-color'];
    ctx.beginPath(); ctx.moveTo(-r * 0.75, -r * 0.5); ctx.lineTo(-r * 0.95, -r * 1.15); ctx.lineTo(-r * 0.3, -r * 0.85); ctx.fill();
    ctx.beginPath(); ctx.moveTo(r * 0.75, -r * 0.5); ctx.lineTo(r * 0.95, -r * 1.15); ctx.lineTo(r * 0.3, -r * 0.85); ctx.fill();
    ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 8; ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.stroke();
    const happy = S.phase === 'bossWin' || S.phase === 'result';
    ctx.fillStyle = '#ffd23f';
    if (happy) { ctx.lineWidth = 12; ctx.strokeStyle = '#ffd23f'; for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(s * r * 0.35, -r * 0.12, r * 0.16, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); } }
    else for (const s of [-1, 1]) {
      ctx.beginPath(); ctx.ellipse(s * r * 0.35, -r * 0.15, r * 0.17, r * 0.2, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#2a0d10'; ctx.beginPath(); ctx.arc(s * r * 0.33, -r * 0.1, r * 0.08, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#ffd23f';
    }
    ctx.fillStyle = '#2a0d10'; ctx.beginPath(); ctx.ellipse(0, r * 0.35, r * 0.5, happy ? r * 0.32 : r * 0.18, 0, 0, Math.PI); ctx.fill();
    ctx.fillStyle = '#fff';
    for (let i = 0; i < 7; i++) { const x = -r * 0.45 + i * r * 0.9 / 6; ctx.beginPath(); ctx.moveTo(x - 9, r * 0.35); ctx.lineTo(x + 9, r * 0.35); ctx.lineTo(x, r * 0.35 + 18); ctx.fill(); }
  }
  if (B && B.flash > 0) { ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); }
  if (S.phase === 'bossWin' || (S.phase === 'result' && S.failKind === 'boss')) drawCrown(0, -r * 0.95, r);
  ctx.restore();
}
function drawCrown(x, y, r) {
  ctx.fillStyle = COL['accent-2']; ctx.beginPath();
  ctx.moveTo(x - r * 0.5, y); ctx.lineTo(x - r * 0.55, y - r * 0.45); ctx.lineTo(x - r * 0.25, y - r * 0.2); ctx.lineTo(x, y - r * 0.55);
  ctx.lineTo(x + r * 0.25, y - r * 0.2); ctx.lineTo(x + r * 0.55, y - r * 0.45); ctx.lineTo(x + r * 0.5, y); ctx.closePath(); ctx.fill();
}
function drawDragon() {
  const B = S.boss; if (!B || B.type !== 'dragon' || B.dead) return;
  const r = geo.bossR * B.scale, sx = B.flash > 0 ? rnd(-6, 6) : 0;
  ctx.save(); ctx.translate(W / 2 + sx, geo.bossY);
  if (imgOk(IMG.dragon)) ctx.drawImage(IMG.dragon, -r * 1.2, -r * 1.2, r * 2.4, r * 2.4);
  else {
    const c = COL['dragon-color'];
    ctx.fillStyle = c;
    // cánh
    for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * r * 0.6, -r * 0.2); ctx.quadraticCurveTo(s * r * 1.9, -r * 1.2, s * r * 1.7, r * 0.3); ctx.quadraticCurveTo(s * r * 1.2, 0, s * r * 0.7, r * 0.3); ctx.fill(); }
    // sừng
    ctx.fillStyle = '#e8d9a0';
    for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * r * 0.35, -r * 0.75); ctx.quadraticCurveTo(s * r * 0.7, -r * 1.5, s * r * 0.95, -r * 1.35); ctx.quadraticCurveTo(s * r * 0.6, -r * 1.0, s * r * 0.6, -r * 0.6); ctx.fill(); }
    ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.85, r, 0, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 8; ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.stroke();
    // mõm
    ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.beginPath(); ctx.ellipse(0, r * 0.45, r * 0.55, r * 0.38, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#1a0f2e'; for (const s of [-1, 1]) { ctx.beginPath(); ctx.ellipse(s * r * 0.18, r * 0.38, 8, 12, 0, 0, Math.PI * 2); ctx.fill(); }
    // mắt
    for (const s of [-1, 1]) {
      ctx.fillStyle = '#ffcf3a'; ctx.beginPath(); ctx.ellipse(s * r * 0.35, -r * 0.2, r * 0.17, r * 0.12, s * 0.3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#000'; ctx.beginPath(); ctx.ellipse(s * r * 0.35, -r * 0.2, r * 0.04, r * 0.11, 0, 0, Math.PI * 2); ctx.fill();
    }
    ctx.strokeStyle = '#1a0f2e'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(-r * 0.4, r * 0.7); ctx.quadraticCurveTo(0, r * 0.82, r * 0.4, r * 0.7); ctx.stroke();
  }
  if (B.flash > 0) { ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.85, r, 0, 0, Math.PI * 2); ctx.fill(); }
  // khiên
  const sr = r * 1.35;
  if (!B.shieldOpen) {
    ctx.globalAlpha = 0.35 + Math.sin(S.t * 6) * 0.08; ctx.fillStyle = COL['dragon-shield'];
    ctx.beginPath(); ctx.arc(0, 0, sr, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
    ctx.lineWidth = 10; ctx.strokeStyle = COL['dragon-shield']; ctx.stroke();
  } else {
    ctx.setLineDash([18, 22]); ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(95,208,255,.5)';
    ctx.beginPath(); ctx.arc(0, 0, sr, simT, simT + Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    if (B.shieldT < 0.8) { ctx.fillStyle = 'rgba(95,208,255,.25)'; ctx.beginPath(); ctx.arc(0, 0, sr, 0, Math.PI * 2); ctx.fill(); }
  }
  if (S.phase === 'bossWin' || (S.phase === 'result' && S.failKind === 'boss')) drawCrown(0, -r * 1.0, r);
  ctx.restore();
}

function drawBall(p) {
  const b = p.body, x = b.position.x, y = b.position.y, r = p.r;
  if (p.boost > 0) { ctx.fillStyle = 'rgba(255,210,63,.45)'; ctx.beginPath(); ctx.arc(x, y - 8, r * 1.7, 0, Math.PI * 2); ctx.fill(); }
  ctx.save(); ctx.translate(x, y); ctx.rotate(b.angle); ctx.drawImage(p.sprite, -r, -r, r * 2, r * 2); ctx.restore();
  if (p.shieldUntil > S.clock) { ctx.lineWidth = 5; ctx.strokeStyle = COL['accent-2']; ctx.beginPath(); ctx.arc(x, y, r + 7, 0, Math.PI * 2); ctx.stroke(); }
  else if (p.shield) { ctx.lineWidth = 4; ctx.strokeStyle = COL['ball-shield']; ctx.beginPath(); ctx.arc(x, y, r + 6 + Math.sin(S.t * 6) * 2, 0, Math.PI * 2); ctx.stroke(); }
  if (p.lucky && p.shield) { ctx.font = `20px ${COL.font}`; ctx.textAlign = 'center'; ctx.fillText('⭐', x + r * 0.8, y - r * 0.6); }
  if (p.frozen > 0) {
    ctx.fillStyle = 'rgba(180,230,255,.6)'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.roundRect(x - r - 6, y - r - 6, r * 2 + 12, r * 2 + 12, 8); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#1a4a6a'; ctx.font = `800 16px ${COL.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(Math.ceil(p.frozen), x, y + r + 16);
  }
}
function drawNames(list) {
  ctx.font = `700 ${COL['name-size'] || '15px'} ${COL.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
  ctx.lineWidth = 4; ctx.strokeStyle = COL['name-stroke']; ctx.fillStyle = COL['name-color'];
  for (const p of list) {
    const x = p.body.position.x, y = p.body.position.y - p.r - 3, t = '@' + (p.name.length > 14 ? p.name.slice(0, 13) + '…' : p.name);
    ctx.strokeText(t, x, y); ctx.fillText(t, x, y);
  }
}
function checker(y) {
  const sq = 30;
  for (let x = L, i = 0; x < Rr; x += sq, i++) { ctx.fillStyle = i % 2 ? '#222' : COL.finish; ctx.fillRect(x, y - sq / 2, sq, sq / 2); ctx.fillStyle = i % 2 ? COL.finish : '#222'; ctx.fillRect(x, y, sq, sq / 2); }
}

function render() {
  const sx = S.shake > 0.5 ? rnd(-S.shake, S.shake) : 0, sy = S.shake > 0.5 ? rnd(-S.shake, S.shake) : 0;
  const y0 = S.camY;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.save(); ctx.translate(sx, -y0 + sy);
  drawBackground(y0);

  if (curFloor() === 'race' && geo.finishY < y0 + H && (!C.boss.enabled || !geo.barrier) && S.plan.length <= 1) checker(geo.finishY);
  if (geo.exitY && geo.exitY < y0 + H && geo.exitY > y0) checker(geo.exitY);

  const top = y0 - 300, bot = y0 + H + 300;
  for (const b of bodies) {
    if (b.kind === 'champion' || b.kind === 'boss' || b.kind === 'dragon' || b.kind === 'wall') continue;
    if (b.bounds.max.y < top || b.bounds.min.y > bot) continue;
    if (b.kind === 'barrier') {
      ctx.save(); ctx.shadowColor = COL['boss-barrier']; ctx.shadowBlur = 25; drawBody(b); ctx.restore();
      ctx.font = `800 30px ${COL.font}`; ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText(T.bossGate, W / 2, b.position.y + 22);
      continue;
    }
    drawBody(b);
  }
  // nhãn làn ở Ngã Ba
  if (curFloor() === 'fork' && S.fork && geo.laneTop) {
    ctx.font = `800 30px ${COL.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    for (const side of ['left', 'right']) {
      const x = side === 'left' ? W * 0.27 : W * 0.73, danger = side === S.fork.danger;
      ctx.fillStyle = danger ? COL.saw : COL.good;
      ctx.fillText((danger ? '☠ ' : '✔ ') + (danger ? T.laneFast : T.laneSafe), x, geo.laneTop - 26);
    }
  }
  if (geo.walls) {
    ctx.fillStyle = COL.wall; ctx.fillRect(0, y0 - 50, WALL, H + 100); ctx.fillRect(W - WALL, y0 - 50, WALL, H + 100);
    ctx.fillStyle = COL['wall-edge']; ctx.fillRect(WALL - 6, y0 - 50, 6, H + 100); ctx.fillRect(W - WALL, y0 - 50, 6, H + 100);
  }
  if (curFloor() === 'race' && C.boss.enabled) drawDemon();
  drawDragon();

  const vis = [];
  for (const p of players.values()) {
    if (!p.body || p.dead) continue;
    const y = p.body.position.y; if (y < top || y > bot) continue;
    drawBall(p); vis.push(p);
  }
  if (C.players.showNames && S.phase !== 'lobby') drawNames(vis.length > 120 ? vis.slice(0, 120) : vis);

  if (S.champ) {
    const { x, y } = S.champ.body.position, r = C.champion.radius;
    ctx.fillStyle = COL.primary; ctx.beginPath(); ctx.arc(x, y, r + 10, 0, Math.PI * 2); ctx.fill();
    ctx.drawImage(S.champ.sprite, x - r, y - r, r * 2, r * 2);
    drawCrown(x, y - r + 4, r);
    ctx.globalAlpha = 0.92; ctx.fillStyle = COL.primary; ctx.beginPath(); ctx.roundRect(x - 135, y + r + 4, 270, 62, 16); ctx.fill(); ctx.globalAlpha = 1;
    ctx.fillStyle = COL['accent-2']; ctx.font = `800 19px ${COL.font}`; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText(T.previousChampion, x, y + r + 9);
    ctx.fillStyle = '#fff'; ctx.font = `800 23px ${COL.font}`; ctx.fillText('@' + S.champ.user.name, x, y + r + 32);
  }

  // cột băng
  if (S.phase === 'ice' && S.ice) {
    ctx.fillStyle = COL.ice; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
    for (const c of S.ice.icicles) { ctx.beginPath(); ctx.moveTo(c.x - 12, c.y - 40); ctx.lineTo(c.x + 12, c.y - 40); ctx.lineTo(c.x, c.y + 14); ctx.closePath(); ctx.fill(); ctx.stroke(); }
  }
  // dung nham
  if (S.lava && curFloor() === 'lava' && S.lava.y > y0 - 50) {
    const ly = S.lava.y, g = ctx.createLinearGradient(0, ly - 300, 0, ly);
    g.addColorStop(0, '#7a1500'); g.addColorStop(0.8, COL.lava); g.addColorStop(1, COL['lava-glow']);
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(0, y0 - 60);
    ctx.lineTo(W, y0 - 60);
    for (let x = W; x >= 0; x -= 30) ctx.lineTo(x, ly + Math.sin(x * 0.03 + simT * 4) * 12);
    ctx.closePath(); ctx.fill();
    if (S.lava.freeze > 0) { ctx.fillStyle = 'rgba(180,230,255,.5)'; ctx.fillRect(0, ly - 40, W, 50); }
  }
  // tia lửa rồng
  if (S.boss && S.boss.sweep) {
    const sw = S.boss.sweep;
    if (sw.t < sw.warn) {
      ctx.fillStyle = `rgba(255,40,40,${0.15 + 0.15 * Math.sin(S.t * 30)})`; ctx.fillRect(L, sw.y - sw.h / 2, IW, sw.h);
      ctx.strokeStyle = 'rgba(255,60,60,.9)'; ctx.setLineDash([20, 14]); ctx.lineWidth = 4; ctx.strokeRect(L, sw.y - sw.h / 2, IW, sw.h); ctx.setLineDash([]);
    } else {
      const k = (sw.t - sw.warn) / sw.fire, g = ctx.createLinearGradient(0, sw.y - sw.h / 2, 0, sw.y + sw.h / 2);
      g.addColorStop(0, 'rgba(255,207,58,0)'); g.addColorStop(0.5, `rgba(255,120,30,${1 - k})`); g.addColorStop(1, 'rgba(255,207,58,0)');
      ctx.fillStyle = g; ctx.fillRect(0, sw.y - sw.h, W, sw.h * 2);
    }
  }

  for (const e of S.effects) {
    const k = e.t / e.life;
    if (e.type === 'boom') {
      ctx.fillStyle = `rgba(255,170,60,${0.6 * (1 - k)})`; ctx.beginPath(); ctx.arc(e.x, e.y, e.r * (0.3 + k), 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = `rgba(255,240,180,${0.8 * (1 - k)})`; ctx.beginPath(); ctx.arc(e.x, e.y, e.r * 0.5 * (0.3 + k), 0, Math.PI * 2); ctx.fill();
    }
    if (e.type === 'wave') { ctx.lineWidth = 10 * (1 - k); ctx.strokeStyle = `rgba(160,80,220,${1 - k})`; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(e.x, e.y, e.r * k * (1 - i * 0.2), 0, Math.PI * 2); ctx.stroke(); } }
    if (e.type === 'ring') { ctx.lineWidth = 6 * (1 - k); ctx.strokeStyle = e.color; ctx.globalAlpha = 1 - k; ctx.beginPath(); ctx.arc(e.x, e.y, e.r * (0.6 + k), 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1; }
  }
  for (const c of S.crosshairs) {
    if (!c.p.body || c.p.dead) continue;
    const { x, y } = c.p.body.position, r = 34 + c.t * 20;
    ctx.strokeStyle = COL.laser; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x - r - 12, y); ctx.lineTo(x + r + 12, y); ctx.moveTo(x, y - r - 12); ctx.lineTo(x, y + r + 12); ctx.stroke();
  }
  for (const s of S.shots) {
    ctx.fillStyle = s.ghost ? 'rgba(220,220,255,.75)' : COL['bonk-shot']; ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 15;
    ctx.beginPath(); ctx.arc(s.x, s.y, s.dmg > 5 ? 14 : 8, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
  }
  for (const l of S.lasers) {
    const a = 1 - Math.max(0, l.t - l.life) / 0.15;
    ctx.strokeStyle = l.color || COL.laser; ctx.globalAlpha = a; ctx.lineWidth = l.color ? 4 : 8; ctx.shadowColor = ctx.strokeStyle; ctx.shadowBlur = 20;
    ctx.beginPath(); ctx.moveTo(W / 2, geo.bossY - geo.bossR * 0.6); ctx.lineTo(l.x, l.y); ctx.stroke();
    ctx.shadowBlur = 0; ctx.globalAlpha = 1;
  }
  for (const q of S.particles) { ctx.globalAlpha = Math.max(0, 1 - q.t / q.life); ctx.fillStyle = q.color; ctx.fillRect(q.x - q.size / 2, q.y - q.size / 2, q.size, q.size); }
  ctx.globalAlpha = 1;
  for (const x of S.texts) {
    ctx.globalAlpha = Math.max(0, 1 - x.t / x.life); ctx.font = `800 ${x.size}px ${COL.font}`; ctx.textAlign = 'center';
    ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.strokeText(x.text, x.x, x.y); ctx.fillStyle = x.color; ctx.fillText(x.text, x.x, x.y);
  }
  ctx.globalAlpha = 1;
  ctx.restore();

  if (S.wind > 0) {
    ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 4;
    for (let i = 0; i < 18; i++) {
      const y = (i * 113 + S.t * 400) % H, x = ((i * 257 + S.t * 900) % (W + 400)) - 200, dir = Math.sin(simT * 2.2 + (y + S.camY) * 0.004) > 0 ? 1 : -1;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 160 * dir, y); ctx.stroke();
    }
  }
  for (const e of S.effects) if (e.type === 'shove') {
    const k = e.t / e.life; ctx.fillStyle = `rgba(255,255,255,${0.25 * (1 - k)})`;
    ctx.font = `800 160px ${COL.font}`; ctx.textAlign = 'center'; ctx.fillText(e.dir > 0 ? '➡' : '⬅', W / 2 + e.dir * k * 300, 900);
  }
  if (RACE_LIKE.includes(S.phase) && !(S.phase === 'fork' && S.fork?.voting)) {
    const mx = W - WALL / 2, mt = 420, mb = 1500;
    const y0w = curFloor() === 'race' ? geo.courseTop : 720, y1w = curFloor() === 'race' ? geo.barrierY : geo.exitY;
    ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.fillRect(mx - 5, mt, 10, mb - mt);
    if (S.lava && curFloor() === 'lava') { const k = clamp((S.lava.y - y0w) / (y1w - y0w), 0, 1); ctx.fillStyle = COL.lava; ctx.fillRect(mx - 7, mt, 14, k * (mb - mt)); }
    for (const p of alive().sort((a, b) => b.body.position.y - a.body.position.y).slice(0, 25).reverse()) {
      const k = clamp((p.body.position.y - y0w) / (y1w - y0w), 0, 1);
      ctx.drawImage(p.sprite, mx - 13, mt + k * (mb - mt) - 13, 26, 26);
    }
  }
}

let fpsNow = 60;
function frame(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  fpsNow = fpsNow * 0.95 + (dt > 0 ? 1 / dt : 60) * 0.05;
  acc += dt;
  let steps = 0;
  while (acc >= STEP && steps < 8) { physicsStep(); acc -= STEP; steps++; }
  if (steps >= 8) acc = 0;
  update(dt);
  render();
  requestAnimationFrame(frame);
}

// =====================================================================
//  LỆNH ĐIỀU KHIỂN + CHẾ ĐỘ TEST
// =====================================================================
let botN = 0;
function bot() { botN++; const n = pick(['minh', 'lan', 'tuan', 'hoa', 'khoa', 'linh', 'nam', 'thu', 'duc', 'vy', 'an', 'bao']) + '_' + Math.floor(Math.random() * 9999); return { id: 'bot' + botN + n, name: n, nick: n, avatar: '' }; }
const bots = [];
function botUser() { if (!bots.length || Math.random() < 0.3) bots.push(bot()); return pick(bots); }
const anyUser = () => { const pl = [...players.values()]; return pl.length ? pick(pl) : botUser(); };
let autoBots = null;
const COMMANDS = {
  addPlayers(n = 1) { for (let i = 0; i < n; i++) { const u = bot(); bots.push(u); handle({ type: 'chat', user: u, text: 'me' }); } },
  likes(n = 40) { handle({ type: 'like', user: botUser(), count: n }); },
  follow() { handle({ type: 'follow', user: botUser() }); },
  share() { handle({ type: 'share', user: botUser() }); },
  hypeFull() { addHype(100); },
  gift(diamonds = 1, name = 'Rose') { handle({ type: 'gift', user: anyUser(), gift: { name, diamonds, count: 1 } }); },
  bonk(n = 20) { for (let i = 0; i < n; i++) handle({ type: 'chat', user: anyUser(), text: (C.boss.keywords[0] || 'bonk') }); },
  fire(n = 5) { for (let i = 0; i < n; i++) handle({ type: 'chat', user: anyUser(), text: C.floors.ice.keywords[0] || 'fire' }); },
  vote(side = 'left', n = 5) { const kw = side === 'left' ? C.floors.fork.keywordsLeft : C.floors.fork.keywordsRight; for (let i = 0; i < n; i++) handle({ type: 'chat', user: bot(), text: kw[0] }); },
  skip() {
    const ph = S.phase;
    if (['lobby', 'start', 'result', 'transition'].includes(ph)) S.timeLeft = 0;
    else if (ph === 'race') setPhase(C.boss.enabled ? 'boss' : 'result');
    else if (ph === 'boss' || ph === 'dragon') hitBoss(99999);
    else if (ph === 'fork' && S.fork.voting) S.fork.voteLeft = 0;
    else if (['ice', 'fork', 'lava'].includes(ph)) floorClear();
    else if (ph === 'arena') S.arena.t = 9999;
    else S.t = 9999;
  },
  jump(floor) {
    if (!FLOORS[floor] || !alive().length) return;
    if (!S.plan.includes(floor)) S.plan.splice(Math.min(S.floorIdx + 1, S.plan.length), 0, floor);
    S.floorIdx = S.plan.indexOf(floor);
    ['lobby', 'start'].includes(S.phase) && openCage();
    setPhase('transition');
  },
  restart() { setPhase('lobby'); },
  autoBots(on) {
    if (autoBots) { clearInterval(autoBots); autoBots = null; }
    if (!on) return;
    autoBots = setInterval(() => {
      const pl = alive(), all = [...players.values()];
      if (S.phase === 'lobby' && Math.random() < 0.8) handle({ type: 'chat', user: bot(), text: 'me' });
      if (Math.random() < 0.5) handle({ type: 'like', user: botUser(), count: Math.ceil(Math.random() * 15) });
      if ((S.phase === 'boss' || S.phase === 'dragon') && all.length) for (let i = 0; i < 3; i++) if (Math.random() < 0.7) handle({ type: 'chat', user: pick(all), text: C.boss.keywords[0] || 'bonk' });
      if (S.phase === 'ice' && all.length && Math.random() < 0.6) handle({ type: 'chat', user: pick(all), text: C.floors.ice.keywords[0] });
      if (S.phase === 'fork' && Math.random() < 0.6) handle({ type: 'chat', user: botUser(), text: Math.random() < 0.5 ? C.floors.fork.keywordsLeft[0] : C.floors.fork.keywordsRight[0] });
      if (Math.random() < 0.01) handle({ type: 'follow', user: botUser() });
      if (Math.random() < 0.012 && all.length) handle({ type: 'gift', user: pick(all), gift: { name: 'Rose', diamonds: 1, count: 1 } });
      if (Math.random() < 0.003 && all.length) handle({ type: 'gift', user: pick(all), gift: { name: 'Hand Heart', diamonds: 30, count: 1 } });
    }, 150);
  },
  voiceTest() { VO.edgeOk = null; VO.fails = 0; say('test', {}, { prio: 5, ttl: 10, interrupt: true }); },
  voiceStop() { VO.queue = []; stopSpeaking(); },
  resetGiftWidget() { gwLayout = { x: W - GW_BASE * 1.15 - 24, y: 440, s: 1.15 }; store.set('giftWidget', gwLayout); applyGiftWidgetLayout(); },
  resetWins() { wins = {}; champion = null; bestFloor = 0; difficulty = { demon: 1, dragon: 1 }; ['wins', 'champion', 'bestFloor', 'difficulty'].forEach(k => store.set(k, k === 'wins' ? {} : k === 'difficulty' ? difficulty : k === 'bestFloor' ? 0 : null)); },
};

function configDefaultsForPanel() { const d = clone(DEFAULT_CONFIG); d.texts = langPack(C.language); return d; }
function applyConfig(full) {
  const prevLang = C.language;
  const fresh = clone(DEFAULT_CONFIG);
  deepMerge(fresh, full || {});
  for (const k of Object.keys(C)) delete C[k];
  Object.assign(C, fresh);
  buildTexts(); applyTexts(); loadAssets(); loadSounds();
  lastHint = ''; lastGift = '';
  VO.edgeOk = null; VO.fails = 0;
  if (prevLang !== C.language) { VO.queue = []; stopSpeaking(); }
  if (!C.voice?.enabled) { VO.queue = []; stopSpeaking(); }
  if (S.phase === 'lobby') buildLobbyGuide();
  renderGiftWidget();
  if (S.boss) updateBossHud();
  if (APP && prevLang !== C.language) APP.send('config-defaults', configDefaultsForPanel());
}
function applyTheme(vars) {
  const root = document.documentElement;
  for (const n of THEME_VARS) root.style.removeProperty('--' + n);
  for (const [k, v] of Object.entries(vars || {})) if (v) root.style.setProperty('--' + k, v);
  loadColors();
}
function themeDefaults() {
  const root = document.documentElement, saved = root.getAttribute('style');
  root.removeAttribute('style');
  const cs = getComputedStyle(root), out = {};
  for (const n of THEME_VARS) out[n] = cs.getPropertyValue('--' + n).trim();
  if (saved) root.setAttribute('style', saved);
  return out;
}

function setupTest() {
  const p = document.createElement('div'); p.id = 'testPanel';
  const btn = (label, fn) => { const b = document.createElement('button'); b.textContent = label; b.onclick = fn; p.appendChild(b); };
  p.innerHTML = '<b>🧪 TEST MODE</b>';
  btn('+30 người', () => COMMANDS.addPlayers(30));
  btn('Tim x40', () => COMMANDS.likes(40));
  btn('Hype đầy', COMMANDS.hypeFull);
  btn('Quà 1💎', () => COMMANDS.gift(1, 'Rose'));
  btn('Quà 30💎', () => COMMANDS.gift(30, 'Hand Heart'));
  btn('Quà 100💎', () => COMMANDS.gift(100, 'Big Gift'));
  btn('Quà 500💎', () => COMMANDS.gift(500, 'Mega Gift'));
  btn('Bonk x20', () => COMMANDS.bonk(20));
  btn('Lửa x5', () => COMMANDS.fire(5));
  btn('Trái x5', () => COMMANDS.vote('left', 5));
  btn('Phải x5', () => COMMANDS.vote('right', 5));
  btn('Bỏ qua pha', COMMANDS.skip);
  btn('VI / EN', () => applyConfig({ ...clone(C), language: C.language === 'en' ? 'vi' : 'en' }));
  btn('Bot tự chơi', e => { const on = !autoBots; COMMANDS.autoBots(on); e.target.textContent = on ? 'Tắt bot' : 'Bot tự chơi'; });
  document.body.appendChild(p);
}
if (TEST && !APP) setupTest();

window.MarbleGame = { handle, setPhase, S, players, COMMANDS, applyConfig, applyTheme, C, T };

if (APP) {
  APP.on('tiktok', ev => handle(ev));
  APP.on('status', ev => handle(ev));
  APP.on('command', ({ name, args }) => { try { COMMANDS[name]?.(...(args || [])); } catch (e) { console.error(e); } });
  APP.on('config', full => applyConfig(full));
  APP.on('theme', vars => applyTheme(vars));
  APP.on('tts-result', r => onTts(r));
  APP.send('theme-defaults', themeDefaults());
  APP.send('config-defaults', configDefaultsForPanel());
  setInterval(() => {
    const B = S.boss;
    APP.send('state', {
      phase: S.phase, players: players.size, alive: alive().length, queue: queue.size, hype: Math.floor(S.hype),
      timeLeft: Math.max(0, Math.ceil(S.timeLeft)), raceTime: Math.floor(S.raceTime),
      boss: B ? { hp: Math.ceil(B.hp), max: B.max, chat: Math.ceil(B.chat), dead: B.dead, type: B.type } : null,
      champion: champion ? champion.name : null, fps: Math.round(fpsNow),
      voice: vcfg().enabled ? VO.engineUsed : 'off', voiceBusy: !!VO.cur,
      floor: S.floorIdx + 1, floors: S.plan.length, floorName: curFloor(), bestFloor, language: C.language,
    });
  }, 500);
}

setPhase('lobby');
renderGiftWidget();
requestAnimationFrame(frame);
})();
