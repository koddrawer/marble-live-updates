// =====================================================================
//  CẤU HÌNH GAME — luật chơi, tầng, quà, ngôn ngữ
//  (Màu sắc, font ở theme.css · Chữ hiển thị ở texts.js)
//  Trong app: chỉnh tất cả bằng Bảng điều khiển, không cần sửa file này.
// =====================================================================
window.GAME_CONFIG = {

  language: 'vi',        // 'vi' = Tiếng Việt, 'en' = English

  // ---------- THỜI GIAN (giây) ----------
  timing: {
    lobby: 45, lobbyMinPlayers: 1,
    startCountdown: 10,   // màn "Cách chơi" trước khi thả bi
    clear: 4,             // dừng ở màn "Qua tầng" trước khi giới thiệu tầng mới
    raceMax: 75,          // tầng 1: quá giờ thì vào boss luôn
    bossMax: 35,          // thời gian đánh Quỷ Đỏ
    finishMax: 10,        // (chế độ cổ điển) chờ về đích
    result: 12,
  },

  // ---------- NGƯỜI CHƠI ----------
  players: {
    max: 200, joinOnComment: true, joinOnLike: true, joinOnFollow: true, joinOnGift: true,
    joinKeywords: [], queueForNextRace: true, ballRadius: 20, showNames: true,
  },

  // ---------- THÁP NHIỀU TẦNG ----------
  tower: {
    enabled: true,                       // false = chế độ cổ điển (hạ boss -> về đích)
    middlePool: ['ice', 'fork', 'lava'], // các tầng giữa có thể xuất hiện
    middleCount: 2,                      // mỗi vòng bốc ngẫu nhiên bấy nhiêu tầng giữa
    dragon: true,                        // boss cuối Rồng Lửa
    arena: true,                         // đấu trường chung kết
    transition: 9,                       // giây giới thiệu mỗi tầng (có hướng dẫn cách chơi)
  },
  floors: {
    ice:    { length: 3000, icicleEvery: 0.9, frozenMax: 8, keywords: ['lửa', 'lua', 'fire'], likesPerThaw: 30, tail: 10, max: 60 },
    fork:   { voteTime: 10, keywordsLeft: ['trái', 'trai', 'left'], keywordsRight: ['phải', 'phai', 'right'], timeLimit: 40, saws: 5, sawKillChance: 0.3 },
    lava:   { length: 4400, speed: 230, accel: 10, slowPerLike: 0.008, slowMax: 0.45, max: 70 },   // slowPerLike: % chậm mỗi tim/giây · slowMax: chậm tối đa 45%
    dragon: { hpBase: 40, hpPerPlayer: 1.0, chatHp: 100, shieldClosed: 3.5, shieldOpen: 3.5, reflectDamage: 1,
              sweepEvery: 5, sweepKill: 0.1, sweepDamage: 7, max: 50 },
    arena:  { time: 35, startWidth: 900, minWidth: 140, shoveEvery: 3.5, shovePower: 4.5 },
  },

  // ---------- CÂN BẰNG ----------
  balance: {
    ghostDamage: 0.5,        // bi đã chết vẫn bonk được, sát thương x0.5
    luckyPerFloor: 3,        // mỗi tầng tặng khiên miễn phí cho N bi chưa từng tặng quà
    catchUp: 0.06,           // đẩy nhẹ nhóm bi cuối (0 = tắt)
    diminishing: [1, 0.5, 0.25, 0.1],   // cùng 1 loại quà trong 1 tầng: lần 1 100%, lần 2 50%...
    adaptiveBoss: true,      // thua liên tục -> boss yếu đi, thắng dễ -> boss mạnh lên
    roomEventSeconds: 5,     // thời gian hiệu lực sự kiện cả phòng (Mưa Vàng...)
  },

  // ---------- HYPE ----------
  hype: {
    perLike: 0.25, perFollow: 8, perShare: 6, perDiamond: 1, perComment: 0,
    events: ['meteor', 'hurricane', 'antigravity', 'earthquake'],
    bossDamage: 15,
  },

  // ---------- BOSS TẦNG 1 (Quỷ Đỏ) ----------
  boss: {
    enabled: true, keywords: ['bonk', 'đánh', 'danh'],
    hpBase: 40, hpPerPlayer: 1.2, damagePerBonk: 1, userCooldown: 0.25,
    chatHp: 100, attackEvery: 1.1, attackDamage: 5, attackKillsBall: true,
  },

  // ---------- QUÀ ----------
  // action (cho bản thân): boost | big | shield | revive | none
  // room   (cho cả phòng): goldRain (khiên vàng + tan băng + đóng băng dung nham) | mega (bỏ qua tầng / -20% máu boss)
  // voteWeight: số phiếu khi bình chọn ở Ngã Ba
  // icon: emoji (🌹) hoặc đường dẫn ảnh (assets/rose.png, file:///..., https://...)
  gifts: {
    byName: {},   // ví dụ: { 'Rose': { action: 'boost', bossDamage: 5, hype: 5 } }
    tiers: [
      { minDiamonds: 1,   icon: '🌹', action: 'boost',  room: '',         bossDamage: 5,   hype: 5,   voteWeight: 2 },
      { minDiamonds: 5,   icon: '💖', action: 'shield', room: '',         bossDamage: 15,  hype: 10,  voteWeight: 3 },
      { minDiamonds: 30,  icon: '🍩', action: 'revive', room: '',         bossDamage: 40,  hype: 25,  voteWeight: 5 },
      { minDiamonds: 100, icon: '👑', action: 'big',    room: 'goldRain', bossDamage: 100, hype: 50,  voteWeight: 10 },
      { minDiamonds: 500, icon: '🦁', action: 'shield', room: 'mega',     bossDamage: 300, hype: 100, voteWeight: 30 },
    ],
    multiplyByCount: true,
  },

  // ---------- ĐƯỜNG ĐUA TẦNG 1 ----------
  course: {
    shuffle: true,
    sections: [
      { type: 'pegs', height: 1300 }, { type: 'spinners', height: 1300 }, { type: 'bouncers', height: 1100 },
      { type: 'slats', height: 1200 }, { type: 'hammers', height: 1200 }, { type: 'seesaw', height: 1400 },
      { type: 'zigzag', height: 1700 },
    ],
    finalFunnel: true, gravity: 1.0,
  },

  // ---------- HƯỚNG DẪN TRÊN MÀN HÌNH ----------
  guide: { slideSeconds: 8, guideBar: true, rotateSeconds: 5 },   // slideSeconds: mỗi trang hướng dẫn ở lobby hiện bao lâu

  champion: { enabled: true, radius: 80, shockwaveEvery: 5 },

  assets: { background: '', bossBackground: '', boss: '', logo: '' },
  sounds: { volume: 0.6, start: '', hype: '', bonk: '', bossHit: '', win: '', lose: '', join: '' },

  // Ghi đè từng câu chữ (để trống = dùng gói ngôn ngữ trong texts.js)
  texts: {},
};
