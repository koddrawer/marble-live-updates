// Bảng điều khiển song ngữ: Tiếng Việt (gốc) -> English
const PANEL_EN = {
  // chung / tab
  'Marble Live - Bảng điều khiển': 'Marble Live - Control Panel',
  'Điều khiển': 'Control', 'Luật chơi': 'Rules', 'Boss & Hype': 'Boss & Hype', 'Quà': 'Gifts', 'Đường đua': 'Course',
  'Tháp': 'Tower', 'Chữ': 'Texts', 'Giao diện': 'Look', 'Cập nhật': 'Updates', 'Cài đặt': 'Settings',
  // điều khiển
  'Kết nối TikTok LIVE': 'TikTok LIVE connection', 'tên kênh (không cần @)': 'channel name (no @)', 'Kết nối': 'Connect', 'Ngắt': 'Disconnect',
  'Tự kết nối khi mở app': 'Auto-connect on startup', 'Trận đấu': 'Match', 'Pha': 'Phase', 'Người chơi': 'Players', 'Còn bi': 'Alive', 'Giây': 'Seconds',
  '⏭ Bỏ qua pha': '⏭ Skip phase', '🔄 Vòng mới': '🔄 New round', '+1 người': '+1 player', '+30 người': '+30 players', '❤ Tim x40': '❤ Likes x40',
  '⚡ Hype đầy': '⚡ Full hype', '➕ Follow': '➕ Follow', '↗ Share': '↗ Share', '🌹 Quà 1💎': '🌹 Gift 1💎', '🎁 Quà 10💎': '🎁 Gift 10💎',
  '💎 Quà 100💎': '💎 Gift 100💎', '👊 Bonk x20': '👊 Bonk x20', '🎁 Quà 30💎': '🎁 Gift 30💎', '👑 Quà 500💎': '👑 Gift 500💎', '🔥 Lửa x5': '🔥 Fire x5',
  '⬅ Trái x5': '⬅ Left x5', 'Phải x5 ➡': 'Right x5 ➡',
  'Bot tự chơi (để test, nhớ tắt khi live)': 'Auto bots (testing only — turn off when live)',
  'Nhảy tới tầng (test)': 'Jump to floor (test)',
  'Cửa sổ game (9:16)': 'Game window (9:16)', 'Luôn nổi trên cùng': 'Always on top', 'Ẩn viền cửa sổ (kéo bằng chuột trên game)': 'Frameless window (drag on the game)',
  'Hiện cửa sổ game': 'Show game window', 'Tải lại game': 'Reload game', 'Nhật ký': 'Log', 'Hiện tại': 'Current', ' (màn hình không đủ chỗ)': ' (screen too small)',
  'Tầng': 'Floor', 'Kỷ lục': 'Record', 'Chờ vòng sau': 'Queued',
  // pha
  'Chờ người': 'Lobby', 'Đếm ngược': 'Countdown', 'Đang đua': 'Racing', 'Đánh Quỷ': 'Demon fight', 'Về đích': 'Finish', 'Boss thắng': 'Boss wins',
  'Kết quả': 'Result', 'Qua tầng': 'Floor cleared', 'Lên tầng': 'Next floor', 'Hang Băng': 'Ice Cave', 'Ngã Ba': 'The Fork', 'Dung Nham': 'Lava',
  'Đánh Rồng': 'Dragon fight', 'Đấu Trường': 'Arena', 'Dung Nham Đuổi': 'Lava Chase', 'Rồng Lửa': 'Fire Dragon',
  // luật chơi
  'Thời gian (giây)': 'Timing (seconds)', 'Gom người chơi': 'Lobby (gathering players)', 'Số người tối thiểu để bắt đầu': 'Minimum players to start',
  'Đếm ngược thả bi': 'Start countdown', 'Đua tối đa': 'Max race time', 'quá giờ thì vào boss luôn': 'go to the boss when time runs out',
  'Đánh boss tối đa': 'Max boss time', 'Chờ về đích sau khi hạ boss': 'Finish wait after boss (classic)', 'Màn kết quả': 'Result screen',
  'Số bi tối đa': 'Max marbles', 'máy yếu nên để 100–150': 'use 100–150 on slow PCs', 'Kích thước bi': 'Marble size', 'áp dụng từ vòng sau': 'applies next round',
  'Comment để tham gia': 'Comment to join', 'Chỉ nhận comment chứa': 'Only comments containing', 'cách nhau dấu phẩy, để trống = mọi comment': 'comma separated, empty = any comment',
  'Thả tim để tham gia': 'Like to join', 'Follow để tham gia': 'Follow to join', 'Tặng quà để tham gia': 'Gift to join',
  'Comment lúc đang đua → vào vòng sau': 'Comments during a race → join next round', 'Hiện tên trên bi': 'Show names on marbles',
  'Nhà vô địch vòng trước': 'Previous champion', 'Bay trên đường đua làm chướng ngại': 'Flies over the course as an obstacle', 'Kích thước': 'Size',
  'Phát sóng đẩy bi mỗi (giây)': 'Shockwave every (s)',
  // boss & hype
  'Boss': 'Boss', 'Bật boss': 'Enable boss', 'tắt = về đích thẳng': 'off = straight to the finish', 'Từ khoá tấn công': 'Attack keywords', 'cách nhau dấu phẩy': 'comma separated',
  'Chữ hiện trên màn hình': 'Text shown on screen', 'Máu boss cơ bản': 'Base boss HP', 'Máu thêm mỗi người chơi': 'Extra HP per player',
  'Sát thương mỗi comment': 'Damage per comment', 'Giãn cách bonk 1 người (giây)': 'Per-user bonk cooldown (s)', 'Máu phe chat': 'Chat HP',
  'Boss đánh mỗi (giây)': 'Boss attacks every (s)', 'Mỗi đòn trừ máu chat': 'Chat HP lost per attack', 'Đòn boss xoá 1 viên bi': 'Boss attack removes a marble',
  'Hype meter': 'Hype meter', '% mỗi lượt tim': '% per like', '% mỗi follow': '% per follow', '% mỗi share': '% per share',
  '% mỗi kim cương (quà không có luật riêng)': '% per diamond (gifts without a rule)', '% mỗi comment': '% per comment',
  'Sự kiện khi đầy (theo thứ tự)': 'Events when full (in order)', 'Đầy hype lúc đánh boss = trừ máu boss': 'Full hype during a boss = boss damage',
  // tháp
  'Tháp nhiều tầng': 'Multi-floor tower', 'Bật chế độ tháp': 'Enable tower mode', 'tắt = cổ điển: hạ boss rồi về đích': 'off = classic: beat the boss, then finish',
  'Các tầng giữa có thể xuất hiện': 'Middle floors that can appear', 'Số tầng giữa mỗi vòng (bốc ngẫu nhiên)': 'Middle floors per round (random)',
  'Boss cuối Rồng Lửa': 'Final boss: Fire Dragon', 'Chung kết Đấu Trường': 'Arena final', 'Giới thiệu mỗi tầng (giây)': 'Floor intro (s)',
  'Chiều dài (px)': 'Length (px)', 'Cột băng rơi mỗi (giây)': 'Icicle every (s)', 'nhỏ = khó hơn': 'lower = harder', 'Bị đóng băng quá (giây) thì vỡ': 'Frozen longer than (s) = shatter',
  'Từ khoá phá băng': 'Thaw keywords', 'Số tim để phá 1 viên băng': 'Likes to thaw one marble', 'Chờ bi chậm (giây) khi đã về một nửa': 'Wait for stragglers (s) once half arrived',
  'Thời gian tối đa': 'Max time', 'Thời gian bình chọn (giây)': 'Vote time (s)', 'Từ khoá chọn TRÁI': 'LEFT keywords', 'Từ khoá chọn PHẢI': 'RIGHT keywords',
  'Thời gian tối đa sau khi mở': 'Max time after opening', 'Số lưỡi cưa ở làn nguy hiểm': 'Saws in the dangerous lane', 'Tỉ lệ lưỡi cưa loại bi': 'Saw kill chance',
  'Tốc độ dung nham (px/giây)': 'Lava speed (px/s)', 'Tăng tốc mỗi giây': 'Acceleration per second', 'Mỗi tim/giây làm chậm': 'Slowdown per like/second',
  'Làm chậm tối đa': 'Max slowdown', 'Máu cơ bản': 'Base HP', 'Khiên đóng (giây)': 'Shield closed (s)', 'Khiên mở (giây)': 'Shield open (s)',
  'Phản đòn khi đánh lúc khiên đóng': 'Reflect damage on closed shield', 'Phun lửa mỗi (giây)': 'Fire sweep every (s)', 'Mỗi lần phun loại tối đa': 'Max eliminated per sweep',
  'Mỗi lần phun trừ máu chat': 'Chat HP lost per sweep', 'Thời gian sàn co lại (giây)': 'Floor shrink time (s)', 'Độ rộng sàn ban đầu': 'Starting floor width',
  'Độ rộng sàn nhỏ nhất': 'Minimum floor width', 'Sóng đẩy mỗi (giây)': 'Shove every (s)', 'Lực sóng đẩy': 'Shove power',
  'Cân bằng & công bằng': 'Balance & fairness', 'Sát thương của bi đã chết (hồn ma)': 'Ghost damage (eliminated marbles)',
  'Bi may mắn mỗi tầng (khiên miễn phí)': 'Lucky marbles per floor (free shield)', 'chỉ chọn người chưa tặng quà': 'only non-gifters are picked',
  'Đẩy nhẹ nhóm bi cuối': 'Catch-up push for last marbles', 'Hiệu lực quà lặp lại trong 1 tầng': 'Repeat gift strength within a floor', 'lần 1, lần 2, lần 3...': '1st, 2nd, 3rd...',
  'Boss tự cân bằng theo kết quả': 'Adaptive boss difficulty', 'Thời gian sự kiện cả phòng (giây)': 'Room event duration (s)',
  // quà
  'Chung': 'General', 'Nhân theo số lượng combo (x10 → sát thương x10)': 'Multiply by combo count (x10 → 10x damage)', 'Theo số kim cương': 'By diamonds',
  'Quà không có luật theo tên sẽ lấy bậc cao nhất đạt được.': 'Gifts without a name rule use the highest tier reached.',
  'Bản thân': 'Self', 'Cả phòng': 'Room', ': tác dụng lên bi người tặng (Hồi sinh: dùng khi bi đã chết, 1 lần/vòng).': ': effect on the gifter\'s marble (Revive: used when eliminated, once per round).',
  ': Mưa Vàng = mọi bi có khiên vàng, phá băng, đóng băng dung nham · Thần Long = bỏ qua tầng hoặc boss mất 20% máu.': ': Golden Rain = gold shield for all, thaws ice, freezes lava · Dragon God = skip floor or boss loses 20% HP.',
  'Phiếu': 'Votes', ': sức nặng khi bình chọn ở Ngã Ba.': ': vote weight at The Fork.', 'Theo tên quà': 'By gift name', 'Tên quà': 'Gift name', 'Từ 💎': 'From 💎',
  'Sát thương boss': 'Boss damage', '% Hype': '% Hype', '+ Thêm bậc': '+ Add tier', '+ Thêm quà': '+ Add gift',
  'Gõ đúng tên quà tiếng Anh như TikTok gửi về (xem trong Nhật ký khi có người tặng), ví dụ': 'Type the exact English gift name TikTok sends (see the Log when someone gifts), e.g.',
  'Boost': 'Boost', 'Bi khổng lồ': 'Giant marble', 'Khiên': 'Shield', 'Hồi sinh': 'Revive', 'Không': 'None', 'Mưa Vàng': 'Golden Rain', 'Thần Long': 'Dragon God',
  // đường đua
  'Vật lý': 'Physics', 'Trọng lực': 'Gravity', 'cao = bi rơi nhanh, trận ngắn hơn': 'higher = faster, shorter matches', 'Xáo trộn thứ tự đoạn mỗi vòng': 'Shuffle sections each round',
  'Phễu gom cuối đường': 'Final funnel', 'Các đoạn đường đua (từ trên xuống)': 'Course sections (top to bottom)',
  'Áp dụng từ vòng sau. Chiều cao tính theo px trên khung 1080×1920 (1 màn hình ≈ 1900px).': 'Applies next round. Height in px on the 1080×1920 frame (1 screen ≈ 1900px).',
  'Loại': 'Type', 'Chiều cao': 'Height', '+ Thêm đoạn': '+ Add section', 'Tổng chiều dài': 'Total length', 'màn hình': 'screens',
  'Cọc tròn': 'Pegs', 'Thanh xoay': 'Spinners', 'Bệ nhún': 'Bouncers', 'Thanh nghiêng': 'Slats', 'Búa đập': 'Hammers', 'Bập bênh': 'Seesaws', 'Ramp zigzag': 'Zigzag ramps', 'Phễu': 'Funnel',
  // chữ
  'Ngôn ngữ game': 'Game language', 'Ngôn ngữ hiển thị trên game': 'Language shown in the game', 'Chữ hiển thị trên game': 'In-game texts', 'Tiếng Việt': 'Tiếng Việt',
  // giao diện
  'Đang chờ cửa sổ game...': 'Waiting for the game window...', 'Font chữ': 'Font', 'Màu chủ đạo': 'Primary color', 'Chủ đạo (đậm)': 'Primary (dark)', 'Thanh hype': 'Hype bar',
  'Vàng nhấn / số đếm': 'Accent yellow / countdown', 'Phe chat (xanh)': 'Chat side (green)', 'Nền bảng': 'Panel background', 'Chữ trên bảng': 'Panel text', 'Bo góc': 'Corner radius',
  'Chừa phía trên (thanh TikTok)': 'Top margin (TikTok header)', 'Khu đua': 'Race area', 'Nền': 'Background', 'Chấm nền': 'Background dots', 'Tường': 'Walls', 'Viền tường': 'Wall edge',
  'Cọc': 'Pegs', 'Viền cọc': 'Peg edge', 'Trục xoay': 'Pivot', 'Búa': 'Hammer', 'Ramp': 'Ramp', 'Viền ramp': 'Ramp edge', 'Thanh gỗ': 'Wooden bars',
  'Khu boss': 'Boss area', 'Nền dưới': 'Bottom background', 'Nền trên': 'Top background', 'Thân boss': 'Boss body', 'Cổng chặn': 'Gate', 'Laser': 'Laser', 'Đạn bonk': 'Bonk shot',
  'Vạch đích': 'Finish line', 'Các tầng': 'Floors', 'Nền Hang Băng': 'Ice Cave background', 'Băng': 'Ice', 'Viền dung nham': 'Lava glow', 'Lưỡi cưa': 'Saw',
  'Nền khu Rồng': 'Dragon background', 'Thân Rồng': 'Dragon body', 'Khiên Rồng': 'Dragon shield', 'Nền Đấu Trường': 'Arena background', 'Sàn Đấu Trường': 'Arena floor',
  'Bi': 'Marbles', 'Viền bi': 'Marble border', 'Màu tên': 'Name color', 'Viền tên': 'Name outline', 'Cỡ tên': 'Name size',
  'Hình ảnh': 'Images', 'Nền khu đua (rộng 1080)': 'Race background (1080 wide)', 'Nền khu boss': 'Boss background', 'Ảnh boss Quỷ Đỏ (PNG vuông, nền trong)': 'Red Demon image (square PNG, transparent)',
  'Ảnh Rồng (PNG vuông, nền trong)': 'Dragon image (square PNG, transparent)', 'Logo': 'Logo', 'Âm thanh': 'Sounds', 'Âm lượng': 'Volume', 'Bắt đầu đua': 'Race start',
  'Có người vào': 'Player joined', 'Kích hoạt hype': 'Hype triggered', 'Bonk trúng boss': 'Bonk hit', 'Boss đánh': 'Boss attack', 'Chiến thắng': 'Victory',
  'Chọn': 'Pick', '— mặc định —': '— default —',
  // cập nhật
  'Cập nhật nóng từ xa': 'Remote hot updates', 'Dán link tới file': 'Paste the link to', 'Link manifest': 'Manifest link', 'Kiểm tra mỗi (phút)': 'Check every (minutes)',
  '(GitHub raw, Cloudflare Pages, host bất kỳ). App tự kiểm tra định kỳ: có bản game mới thì tải về và nạp lại khi hết vòng đua; có': '(GitHub raw, Cloudflare Pages, any host). The app checks periodically: a new game version is downloaded and loaded after the current round; a new',
  'mới thì áp thông số từ xa ngay.': 'applies remote settings immediately.',
  'Tự áp dụng bản mới khi hết vòng': 'Auto-apply new versions after a round', 'Nhận thông số đẩy từ xa': 'Accept remotely pushed settings',
  'Kiểm tra ngay': 'Check now', 'Áp dụng ngay': 'Apply now', 'Quay về bản gốc': 'Revert to bundled', 'Game đang chạy': 'Running game', 'Trên mạng': 'Online', 'Kiểm tra lúc': 'Checked at', 'Ghi chú': 'Notes',
  // cài đặt
  'Kết nối nâng cao': 'Advanced connection', 'Euler Stream API key (không bắt buộc)': 'Euler Stream API key (optional)', 'để trống nếu kết nối bình thường': 'leave empty if connecting works',
  'Hiển thị': 'Display', 'Tăng tốc phần cứng (tắt nếu LIVE Studio capture ra màn đen)': 'Hardware acceleration (turn off if LIVE Studio captures black)',
  'Khởi động lại app': 'Restart app', 'Sao lưu / chia sẻ thông số': 'Backup / share settings',
  'Xuất file để chép sang máy khác, hoặc dán nội dung vào trường': 'Export to copy to another PC, or paste the contents into the',
  'của manifest để đẩy từ xa.': 'fields of the manifest to push remotely.', 'Xuất file': 'Export', 'Nhập file': 'Import', 'Mở thư mục dữ liệu': 'Open data folder',
  'Khôi phục': 'Reset', 'Xoá bảng thắng / champion': 'Clear wins / champion', 'Đưa mọi thông số về mặc định': 'Reset all settings to default',
  'Ngôn ngữ bảng điều khiển': 'Control panel language',
  'Thời gian chờ — để người xem kịp đọc (giây)': 'Wait times — so viewers can read (seconds)', 'Chọn nhanh': 'Quick preset',
  'Nhanh': 'Fast', 'Vừa': 'Normal', 'Chậm': 'Slow', 'Đã áp dụng': 'Applied',
  'Chờ người vào (lobby)': 'Lobby (waiting for players)', 'màn có bảng hướng dẫn lật trang': 'screen with the flipping guide',
  'Mỗi trang hướng dẫn ở lobby hiện': 'Each lobby guide page shows for', 'có 3 trang: tham gia · quà · các tầng': '3 pages: join · gifts · floors',
  'Màn "Cách chơi" trước khi thả bi': '"How to play" screen before release', 'Giới thiệu mỗi tầng mới': 'Intro of each new floor',
  'màn có 3 bước chơi + quà ở tầng đó': 'shows 3 play steps + gifts on that floor', 'Dừng ở màn "Qua tầng"': 'Pause on "Floor cleared"',
  'Màn kết quả (nhà vô địch)': 'Result screen (champion)', 'Giới hạn thời gian mỗi màn (giây)': 'Time limit per stage (seconds)',
  'Chờ về đích sau khi hạ boss (cổ điển)': 'Finish wait after boss (classic)',
  'emoji hoặc ảnh': 'emoji or image', 'Chọn ảnh icon': 'Pick icon image', 'Xoá': 'Delete',
  'Cập nhật app (phần lõi)': 'App updates (core)',
  'Game và bảng điều khiển được cập nhật nóng ở trên. Khi phần lõi của app thay đổi, app tự tải bản mới, cài đè và khởi động lại (mất khoảng 5 giây) ở màn kết quả. Thông số đã chỉnh luôn được giữ.': 'The game and this control panel hot-update above. When the app core changes, the app downloads the new version, installs it and restarts (about 5 seconds) on the result screen. Your settings are always kept.',
  'Tự cài bản app mới khi hết vòng': 'Auto-install new app versions after a round', 'Cài app ngay': 'Install app now', 'Mở link tải app': 'Open app download link',
  'App đang chạy': 'Running app', 'mới nhất': 'up to date', 'Cài app mới và khởi động lại ngay?': 'Install the new app and restart now?',
  'Hướng dẫn trên màn hình': 'On-screen guide', 'Hiện dòng quà khi đang chơi': 'Show the gift line while playing',
  'tắt = chỉ hiện dòng việc cần làm': 'off = only the what-to-do line', 'Đổi dòng hướng dẫn mỗi (giây)': 'Switch guide line every (s)',
  'xoay giữa việc cần làm ↔ bảng quà': 'alternates what-to-do ↔ gift list',
  // thông báo
  'Khởi động lại app để áp dụng': 'Restart the app to apply', 'Đã xuất file': 'Exported', 'Đã nhập thông số': 'Settings imported', 'Đã xoá': 'Cleared',
  'Đã khôi phục mặc định': 'Defaults restored', 'Đã nhận thông số từ xa': 'Remote settings received',
  'Quay về bản game gốc đi kèm app?': 'Revert to the game version bundled with the app?', 'Xoá toàn bộ số trận thắng và champion?': 'Clear all wins and the champion?',
  'Đưa MỌI thông số và màu về mặc định?': 'Reset ALL settings and colors to default?',
};
let PANEL_LANG = 'vi';
function tr(s) { return PANEL_LANG === 'en' ? (PANEL_EN[s] ?? s) : s; }
const _orig = new WeakMap();
function translateDom(root) {
  if (!root) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = walker.nextNode())) {
    if (!_orig.has(n)) _orig.set(n, n.nodeValue);
    const o = _orig.get(n), t = o.trim();
    if (!t) continue;
    const en = PANEL_EN[t];
    n.nodeValue = (PANEL_LANG === 'en' && en != null) ? o.replace(t, en) : o;
  }
  root.querySelectorAll('[placeholder],[title]').forEach(e => {
    for (const a of ['placeholder', 'title']) {
      if (!e.hasAttribute(a)) continue;
      const k = 'data-orig-' + a;
      if (!e.hasAttribute(k)) e.setAttribute(k, e.getAttribute(a));
      const o = e.getAttribute(k);
      e.setAttribute(a, PANEL_LANG === 'en' ? (PANEL_EN[o] ?? o) : o);
    }
  });
}
function setPanelLang(lang) {
  PANEL_LANG = lang === 'en' ? 'en' : 'vi';
  document.documentElement.lang = PANEL_LANG;
  document.title = tr('Marble Live - Bảng điều khiển');
  translateDom(document.body);
}

// Thông báo động từ app (trạng thái kết nối, cập nhật, nhật ký)
const DYN = [
  [/^Đang tải app (\S+)\.\.\. (\d+)%$/, 'Downloading app $1... $2%'],
  [/^Đang tải app (\S+)\.\.\.$/, 'Downloading app $1...'],
  [/^Đang giải nén app (\S+)\.\.\.$/, 'Extracting app $1...'],
  [/^App (\S+) sẵn sàng — sẽ cài khi hết vòng \(app tự khởi động lại\)$/, 'App $1 ready — installs after this round (auto restart)'],
  [/^App (\S+) sẵn sàng — bấm "Cài app ngay"$/, 'App $1 ready — press "Install app now"'],
  [/^Đang cài app (\S+) — app sẽ khởi động lại\.\.\.$/, 'Installing app $1 — restarting...'],
  [/^Có app (\S+)$/, 'App $1 available'],
  [/^Lỗi tải app: (.*)$/, 'App download error: $1'],
  [/^Bản (\S+) cần app ≥ (\S+) — đang chờ cập nhật app$/, 'Version $1 needs app ≥ $2 — waiting for the app update'],
  [/☁ Đã tải app (.+)/, '☁ Downloaded app $1'],
  [/^Nhập tên kênh TikTok để kết nối$/, 'Enter a TikTok channel name to connect'],
  [/^Chưa nhập tên kênh TikTok$/, 'No TikTok channel name entered'],
  [/^Chưa kết nối \(bấm Kết nối\)$/, 'Not connected (press Connect)'],
  [/^Đang kết nối (@\S+)\.\.\.$/, 'Connecting $1...'],
  [/^Đã kết nối (@\S+) \(room (\S+)\)$/, 'Connected $1 (room $2)'],
  [/^Không kết nối được (@\S+): (.*)\. Thử lại sau 15s$/, 'Could not connect $1: $2. Retrying in 15s'],
  [/^Mất kết nối — đang thử lại$/, 'Connection lost — retrying'],
  [/^Live đã kết thúc — sẽ thử lại$/, 'LIVE ended — will retry'],
  [/^Đã ngắt kết nối TikTok$/, 'Disconnected from TikTok'],
  [/^Đang kiểm tra\.\.\.$/, 'Checking...'],
  [/^Chưa nhập link cập nhật$/, 'No update link set'],
  [/^Đang dùng bản mới nhất \((.+)\)$/, 'Up to date ($1)'],
  [/^Đang tải bản (.+)\.\.\.$/, 'Downloading $1...'],
  [/^Bản (\S+) sẵn sàng — sẽ áp dụng khi hết vòng$/, 'Version $1 ready — applies after this round'],
  [/^Bản (\S+) sẵn sàng — bấm "Áp dụng"$/, 'Version $1 ready — press "Apply"'],
  [/^Đang nạp bản (.+)\.\.\.$/, 'Loading version $1...'],
  [/^Đã cập nhật lên bản (.+)$/, 'Updated to version $1'],
  [/^Bản (\S+) lỗi, đã quay lại bản trước$/, 'Version $1 failed, reverted to the previous one'],
  [/^Đã quay về bản gốc$/, 'Reverted to the bundled version'],
  [/^Bản (\S+) cần app ≥ (\S+)\. Hãy tải app mới\.$/, 'Version $1 needs app ≥ $2. Please download the new app.'],
  [/^Lỗi cập nhật: (.*)$/, 'Update error: $1'],
  [/☁ Đã nhận thông số từ xa \(rev (.+)\)/, '☁ Remote settings received (rev $1)'],
  [/☁ Đã tải bản game (.+)/, '☁ Downloaded game version $1'],
  [/✅ Đang chạy game bản (.+)/, '✅ Running game version $1'],
  [/⚠ Bản (\S+) không khởi động được — quay lại bản trước/, '⚠ Version $1 failed to start — reverting'],
];
function trDyn(s) {
  if (PANEL_LANG !== 'en' || !s) return s;
  for (const [re, en] of DYN) if (re.test(s)) return s.replace(re, en);
  return PANEL_EN[s] ?? s;
}
